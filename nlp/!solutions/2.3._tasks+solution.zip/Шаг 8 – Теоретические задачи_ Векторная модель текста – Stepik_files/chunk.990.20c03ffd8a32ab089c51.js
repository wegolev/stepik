/*! For license information please see chunk.990.20c03ffd8a32ab089c51.js.LICENSE.txt */
(self.webpackChunk_ember_auto_import_=self.webpackChunk_ember_auto_import_||[]).push([[990],{3069:(t,e,n)=>{"use strict";(e=t.exports=n(5152).default).default=e},5152:(t,e)=>{"use strict"
e.default=function(){function t(e,n,r,o){this.message=e,this.expected=n,this.found=r,this.location=o,this.name="SyntaxError","function"==typeof Error.captureStackTrace&&Error.captureStackTrace(this,t)}return function(t,e){function n(){this.constructor=t}n.prototype=e.prototype,t.prototype=new n}(t,Error),{SyntaxError:t,parse:function(e){var n,r=arguments.length>1?arguments[1]:{},o={},i={start:Dt},s=Dt,a=function(t){return{type:"messageFormatPattern",elements:t,location:Tt()}},c=function(t){var e,n,r,o,i,s=""
for(e=0,r=t.length;e<r;e+=1)for(n=0,i=(o=t[e]).length;n<i;n+=1)s+=o[n]
return s},u=function(t){return{type:"messageTextElement",value:t,location:Tt()}},l=/^[^ \t\n\r,.+={}#]/,p={type:"class",value:"[^ \\t\\n\\r,.+={}#]",description:"[^ \\t\\n\\r,.+={}#]"},f="{",h={type:"literal",value:"{",description:'"{"'},d=",",v={type:"literal",value:",",description:'","'},m="}",_={type:"literal",value:"}",description:'"}"'},g=function(t,e){return{type:"argumentElement",id:t,format:e&&e[2],location:Tt()}},y="number",b={type:"literal",value:"number",description:'"number"'},w="date",E={type:"literal",value:"date",description:'"date"'},S="time",x={type:"literal",value:"time",description:'"time"'},O="shortNumber",k={type:"literal",value:"shortNumber",description:'"shortNumber"'},T=function(t,e){return{type:t+"Format",style:e&&e[2],location:Tt()}},C="plural",j={type:"literal",value:"plural",description:'"plural"'},R=function(t){return{type:t.type,ordinal:!1,offset:t.offset||0,options:t.options,location:Tt()}},P="selectordinal",D={type:"literal",value:"selectordinal",description:'"selectordinal"'},A=function(t){return{type:t.type,ordinal:!0,offset:t.offset||0,options:t.options,location:Tt()}},L="select",M={type:"literal",value:"select",description:'"select"'},I=function(t){return{type:"selectFormat",options:t,location:Tt()}},N="=",F={type:"literal",value:"=",description:'"="'},U=function(t,e){return{type:"optionalFormatPattern",selector:t,value:e,location:Tt()}},W="offset:",H={type:"literal",value:"offset:",description:'"offset:"'},B=function(t){return t},q=function(t,e){return{type:"pluralFormat",offset:t,options:e,location:Tt()}},z={type:"other",description:"whitespace"},Z=/^[ \t\n\r]/,V={type:"class",value:"[ \\t\\n\\r]",description:"[ \\t\\n\\r]"},G={type:"other",description:"optionalWhitespace"},J=/^[0-9]/,$={type:"class",value:"[0-9]",description:"[0-9]"},Y=/^[0-9a-f]/i,K={type:"class",value:"[0-9a-f]i",description:"[0-9a-f]i"},X="0",Q={type:"literal",value:"0",description:'"0"'},tt=/^[1-9]/,et={type:"class",value:"[1-9]",description:"[1-9]"},nt=function(t){return parseInt(t,10)},rt=/^[^{}\\\0-\x1F \t\n\r]/,ot={type:"class",value:"[^{}\\\\\\0-\\x1F\\x7f \\t\\n\\r]",description:"[^{}\\\\\\0-\\x1F\\x7f \\t\\n\\r]"},it="\\\\",st={type:"literal",value:"\\\\",description:'"\\\\\\\\"'},at=function(){return"\\"},ct="\\#",ut={type:"literal",value:"\\#",description:'"\\\\#"'},lt=function(){return"\\#"},pt="\\{",ft={type:"literal",value:"\\{",description:'"\\\\{"'},ht=function(){return"{"},dt="\\}",vt={type:"literal",value:"\\}",description:'"\\\\}"'},mt=function(){return"}"},_t="\\u",gt={type:"literal",value:"\\u",description:'"\\\\u"'},yt=function(t){return String.fromCharCode(parseInt(t,16))},bt=function(t){return t.join("")},wt=0,Et=0,St=[{line:1,column:1,seenCR:!1}],xt=0,Ot=[],kt=0
if("startRule"in r){if(!(r.startRule in i))throw new Error("Can't start parsing from rule \""+r.startRule+'".')
s=i[r.startRule]}function Tt(){return jt(Et,wt)}function Ct(t){var n,r,o=St[t]
if(o)return o
for(n=t-1;!St[n];)n--
for(o={line:(o=St[n]).line,column:o.column,seenCR:o.seenCR};n<t;)"\n"===(r=e.charAt(n))?(o.seenCR||o.line++,o.column=1,o.seenCR=!1):"\r"===r||"\u2028"===r||"\u2029"===r?(o.line++,o.column=1,o.seenCR=!0):(o.column++,o.seenCR=!1),n++
return St[t]=o,o}function jt(t,e){var n=Ct(t),r=Ct(e)
return{start:{offset:t,line:n.line,column:n.column},end:{offset:e,line:r.line,column:r.column}}}function Rt(t){wt<xt||(wt>xt&&(xt=wt,Ot=[]),Ot.push(t))}function Pt(e,n,r,o){return null!==n&&function(t){var e=1
for(t.sort((function(t,e){return t.description<e.description?-1:t.description>e.description?1:0}));e<t.length;)t[e-1]===t[e]?t.splice(e,1):e++}(n),new t(null!==e?e:function(t,e){var n,r=new Array(t.length)
for(n=0;n<t.length;n++)r[n]=t[n].description
return"Expected "+(t.length>1?r.slice(0,-1).join(", ")+" or "+r[t.length-1]:r[0])+" but "+(e?'"'+function(t){function e(t){return t.charCodeAt(0).toString(16).toUpperCase()}return t.replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\x08/g,"\\b").replace(/\t/g,"\\t").replace(/\n/g,"\\n").replace(/\f/g,"\\f").replace(/\r/g,"\\r").replace(/[\x00-\x07\x0B\x0E\x0F]/g,(function(t){return"\\x0"+e(t)})).replace(/[\x10-\x1F\x80-\xFF]/g,(function(t){return"\\x"+e(t)})).replace(/[\u0100-\u0FFF]/g,(function(t){return"\\u0"+e(t)})).replace(/[\u1000-\uFFFF]/g,(function(t){return"\\u"+e(t)}))}(e)+'"':"end of input")+" found."}(n,r),n,r,o)}function Dt(){return At()}function At(){var t,e,n
for(t=wt,e=[],n=Lt();n!==o;)e.push(n),n=Lt()
return e!==o&&(Et=t,e=a(e)),e}function Lt(){var t
return(t=It())===o&&(t=Ft()),t}function Mt(){var t,n,r,i,s,a
if(t=wt,n=[],r=wt,(i=$t())!==o&&(s=te())!==o&&(a=$t())!==o?r=i=[i,s,a]:(wt=r,r=o),r!==o)for(;r!==o;)n.push(r),r=wt,(i=$t())!==o&&(s=te())!==o&&(a=$t())!==o?r=i=[i,s,a]:(wt=r,r=o)
else n=o
return n!==o&&(Et=t,n=c(n)),(t=n)===o&&(t=wt,t=(n=Jt())!==o?e.substring(t,wt):n),t}function It(){var t,e
return t=wt,(e=Mt())!==o&&(Et=t,e=u(e)),e}function Nt(){var t,n,r
if((t=Xt())===o){if(t=wt,n=[],l.test(e.charAt(wt))?(r=e.charAt(wt),wt++):(r=o,0===kt&&Rt(p)),r!==o)for(;r!==o;)n.push(r),l.test(e.charAt(wt))?(r=e.charAt(wt),wt++):(r=o,0===kt&&Rt(p))
else n=o
t=n!==o?e.substring(t,wt):n}return t}function Ft(){var t,n,r,i,s,a,c
return t=wt,123===e.charCodeAt(wt)?(n=f,wt++):(n=o,0===kt&&Rt(h)),n!==o&&$t()!==o&&(r=Nt())!==o&&$t()!==o?(i=wt,44===e.charCodeAt(wt)?(s=d,wt++):(s=o,0===kt&&Rt(v)),s!==o&&(a=$t())!==o&&(c=Ut())!==o?i=s=[s,a,c]:(wt=i,i=o),i===o&&(i=null),i!==o&&(s=$t())!==o?(125===e.charCodeAt(wt)?(a=m,wt++):(a=o,0===kt&&Rt(_)),a!==o?(Et=t,t=n=g(r,i)):(wt=t,t=o)):(wt=t,t=o)):(wt=t,t=o),t}function Ut(){var t
return(t=Wt())===o&&(t=Ht())===o&&(t=Bt())===o&&(t=qt()),t}function Wt(){var t,n,r,i,s,a
return t=wt,e.substr(wt,6)===y?(n=y,wt+=6):(n=o,0===kt&&Rt(b)),n===o&&(e.substr(wt,4)===w?(n=w,wt+=4):(n=o,0===kt&&Rt(E)),n===o&&(e.substr(wt,4)===S?(n=S,wt+=4):(n=o,0===kt&&Rt(x)),n===o&&(e.substr(wt,11)===O?(n=O,wt+=11):(n=o,0===kt&&Rt(k))))),n!==o&&$t()!==o?(r=wt,44===e.charCodeAt(wt)?(i=d,wt++):(i=o,0===kt&&Rt(v)),i!==o&&(s=$t())!==o&&(a=te())!==o?r=i=[i,s,a]:(wt=r,r=o),r===o&&(r=null),r!==o?(Et=t,t=n=T(n,r)):(wt=t,t=o)):(wt=t,t=o),t}function Ht(){var t,n,r,i
return t=wt,e.substr(wt,6)===C?(n=C,wt+=6):(n=o,0===kt&&Rt(j)),n!==o&&$t()!==o?(44===e.charCodeAt(wt)?(r=d,wt++):(r=o,0===kt&&Rt(v)),r!==o&&$t()!==o&&(i=Gt())!==o?(Et=t,t=n=R(i)):(wt=t,t=o)):(wt=t,t=o),t}function Bt(){var t,n,r,i
return t=wt,e.substr(wt,13)===P?(n=P,wt+=13):(n=o,0===kt&&Rt(D)),n!==o&&$t()!==o?(44===e.charCodeAt(wt)?(r=d,wt++):(r=o,0===kt&&Rt(v)),r!==o&&$t()!==o&&(i=Gt())!==o?(Et=t,t=n=A(i)):(wt=t,t=o)):(wt=t,t=o),t}function qt(){var t,n,r,i,s
if(t=wt,e.substr(wt,6)===L?(n=L,wt+=6):(n=o,0===kt&&Rt(M)),n!==o)if($t()!==o)if(44===e.charCodeAt(wt)?(r=d,wt++):(r=o,0===kt&&Rt(v)),r!==o)if($t()!==o){if(i=[],(s=Zt())!==o)for(;s!==o;)i.push(s),s=Zt()
else i=o
i!==o?(Et=t,t=n=I(i)):(wt=t,t=o)}else wt=t,t=o
else wt=t,t=o
else wt=t,t=o
else wt=t,t=o
return t}function zt(){var t,n,r,i
return t=wt,n=wt,61===e.charCodeAt(wt)?(r=N,wt++):(r=o,0===kt&&Rt(F)),r!==o&&(i=Xt())!==o?n=r=[r,i]:(wt=n,n=o),(t=n!==o?e.substring(t,wt):n)===o&&(t=te()),t}function Zt(){var t,n,r,i,s
return t=wt,$t()!==o&&(n=zt())!==o&&$t()!==o?(123===e.charCodeAt(wt)?(r=f,wt++):(r=o,0===kt&&Rt(h)),r!==o&&$t()!==o&&(i=At())!==o&&$t()!==o?(125===e.charCodeAt(wt)?(s=m,wt++):(s=o,0===kt&&Rt(_)),s!==o?(Et=t,t=U(n,i)):(wt=t,t=o)):(wt=t,t=o)):(wt=t,t=o),t}function Vt(){var t,n,r
return t=wt,e.substr(wt,7)===W?(n=W,wt+=7):(n=o,0===kt&&Rt(H)),n!==o&&$t()!==o&&(r=Xt())!==o?(Et=t,t=n=B(r)):(wt=t,t=o),t}function Gt(){var t,e,n,r
if(t=wt,(e=Vt())===o&&(e=null),e!==o)if($t()!==o){if(n=[],(r=Zt())!==o)for(;r!==o;)n.push(r),r=Zt()
else n=o
n!==o?(Et=t,t=e=q(e,n)):(wt=t,t=o)}else wt=t,t=o
else wt=t,t=o
return t}function Jt(){var t,n
if(kt++,t=[],Z.test(e.charAt(wt))?(n=e.charAt(wt),wt++):(n=o,0===kt&&Rt(V)),n!==o)for(;n!==o;)t.push(n),Z.test(e.charAt(wt))?(n=e.charAt(wt),wt++):(n=o,0===kt&&Rt(V))
else t=o
return kt--,t===o&&(n=o,0===kt&&Rt(z)),t}function $t(){var t,n,r
for(kt++,t=wt,n=[],r=Jt();r!==o;)n.push(r),r=Jt()
return t=n!==o?e.substring(t,wt):n,kt--,t===o&&(n=o,0===kt&&Rt(G)),t}function Yt(){var t
return J.test(e.charAt(wt))?(t=e.charAt(wt),wt++):(t=o,0===kt&&Rt($)),t}function Kt(){var t
return Y.test(e.charAt(wt))?(t=e.charAt(wt),wt++):(t=o,0===kt&&Rt(K)),t}function Xt(){var t,n,r,i,s,a
if(t=wt,48===e.charCodeAt(wt)?(n=X,wt++):(n=o,0===kt&&Rt(Q)),n===o){if(n=wt,r=wt,tt.test(e.charAt(wt))?(i=e.charAt(wt),wt++):(i=o,0===kt&&Rt(et)),i!==o){for(s=[],a=Yt();a!==o;)s.push(a),a=Yt()
s!==o?r=i=[i,s]:(wt=r,r=o)}else wt=r,r=o
n=r!==o?e.substring(n,wt):r}return n!==o&&(Et=t,n=nt(n)),n}function Qt(){var t,n,r,i,s,a,c,u
return rt.test(e.charAt(wt))?(t=e.charAt(wt),wt++):(t=o,0===kt&&Rt(ot)),t===o&&(t=wt,e.substr(wt,2)===it?(n=it,wt+=2):(n=o,0===kt&&Rt(st)),n!==o&&(Et=t,n=at()),(t=n)===o&&(t=wt,e.substr(wt,2)===ct?(n=ct,wt+=2):(n=o,0===kt&&Rt(ut)),n!==o&&(Et=t,n=lt()),(t=n)===o&&(t=wt,e.substr(wt,2)===pt?(n=pt,wt+=2):(n=o,0===kt&&Rt(ft)),n!==o&&(Et=t,n=ht()),(t=n)===o&&(t=wt,e.substr(wt,2)===dt?(n=dt,wt+=2):(n=o,0===kt&&Rt(vt)),n!==o&&(Et=t,n=mt()),(t=n)===o&&(t=wt,e.substr(wt,2)===_t?(n=_t,wt+=2):(n=o,0===kt&&Rt(gt)),n!==o?(r=wt,i=wt,(s=Kt())!==o&&(a=Kt())!==o&&(c=Kt())!==o&&(u=Kt())!==o?i=s=[s,a,c,u]:(wt=i,i=o),(r=i!==o?e.substring(r,wt):i)!==o?(Et=t,t=n=yt(r)):(wt=t,t=o)):(wt=t,t=o)))))),t}function te(){var t,e,n
if(t=wt,e=[],(n=Qt())!==o)for(;n!==o;)e.push(n),n=Qt()
else e=o
return e!==o&&(Et=t,e=bt(e)),e}if((n=s())!==o&&wt===e.length)return n
throw n!==o&&wt<e.length&&Rt({type:"end",description:"end of input"}),Pt(null,Ot,xt<e.length?e.charAt(xt):null,xt<e.length?jt(xt,xt+1):jt(xt,xt))}}}()},6236:(t,e,n)=>{"use strict"
var r=n(1561).Z
n(5559),(e=t.exports=r).default=e},3691:(t,e,n)=>{"use strict"
var r=n(297),o=n(2059)
function i(t,e,n){this.locales=t,this.formats=e,this.pluralFn=n}function s(t){this.id=t}function a(t,e,n,r,o){this.id=t,this.useOrdinal=e,this.offset=n,this.options=r,this.pluralFn=o}function c(t,e,n,r){this.id=t,this.offset=e,this.numberFormat=n,this.string=r}function u(t,e){this.id=t,this.options=e}function l(t,e){this.__locales__=t,this.__options__=e,this.__localeData__=r.default.__localeData__}e.default=i,i.prototype.compile=function(t){return this.pluralStack=[],this.currentPlural=null,this.pluralNumberFormat=null,this.compileMessage(t)},i.prototype.compileMessage=function(t){if(!t||"messageFormatPattern"!==t.type)throw new Error('Message AST is not of type: "messageFormatPattern"')
var e,n,r,o=t.elements,i=[]
for(e=0,n=o.length;e<n;e+=1)switch((r=o[e]).type){case"messageTextElement":i.push(this.compileMessageText(r))
break
case"argumentElement":i.push(this.compileArgument(r))
break
default:throw new Error("Message element does not have a valid type")}return i},i.prototype.compileMessageText=function(t){return this.currentPlural&&/(^|[^\\])#/g.test(t.value)?(this.pluralNumberFormat||(this.pluralNumberFormat=new Intl.NumberFormat(this.locales)),new c(this.currentPlural.id,this.currentPlural.format.offset,this.pluralNumberFormat,t.value)):t.value.replace(/\\#/g,"#")},i.prototype.compileArgument=function(t){var e=t.format
if(!e)return new s(t.id)
var n,r=this.formats,o=this.locales,i=this.pluralFn
switch(e.type){case"numberFormat":return n=r.number[e.style],{id:t.id,format:new Intl.NumberFormat(o,n).format}
case"shortNumberFormat":var c=new l(o,n=r.shortNumber[e.style])
return{id:t.id,format:c.format.bind(c)}
case"dateFormat":return n=r.date[e.style],{id:t.id,format:new Intl.DateTimeFormat(o,n).format}
case"timeFormat":return n=r.time[e.style],{id:t.id,format:new Intl.DateTimeFormat(o,n).format}
case"pluralFormat":return n=this.compileOptions(t),new a(t.id,e.ordinal,e.offset,n,i)
case"selectFormat":return n=this.compileOptions(t),new u(t.id,n)
default:throw new Error("Message element does not have a valid format type")}},i.prototype.compileOptions=function(t){var e,n,r,o=t.format,i=o.options,s={}
for(this.pluralStack.push(this.currentPlural),this.currentPlural="pluralFormat"===o.type?t:null,e=0,n=i.length;e<n;e+=1)s[(r=i[e]).selector]=this.compileMessage(r.value)
return this.currentPlural=this.pluralStack.pop(),s},s.prototype.format=function(t){return t||"number"==typeof t?"string"==typeof t?t:String(t):""},a.prototype.getOption=function(t){var e=this.options
return e["="+t]||e[this.pluralFn(t-this.offset,this.useOrdinal)]||e.other},c.prototype.format=function(t){var e=this.numberFormat.format(t-this.offset)
return this.string.replace(/(^|[^\\])#/g,"$1"+e).replace(/\\#/g,"#")},u.prototype.getOption=function(t){var e=this.options
return e[t]||e.other},l.prototype.format=function(t,e){return o.compactFormat(t,this.__locales__,this.__localeData__,this.__options__)}},297:(t,e,n)=>{"use strict"
var r=n(8224),o=n(6187),i=n(3691),s=n(3069)
function a(t,e,n){var r="string"==typeof t?a.__parse(t):t
if(!r||"messageFormatPattern"!==r.type)throw new TypeError("A message must be provided as a String or AST.")
n=this._mergeFormats(a.formats,n),o.defineProperty(this,"_locale",{value:this._resolveLocale(e)})
var i=this._findPluralRuleFunction(this._locale),s=this._compilePattern(r,e,n,i),c=this
this.format=function(e){try{return c._format(s,e)}catch(e){throw e.variableId?new Error("The intl string context variable '"+e.variableId+"' was not provided to the string '"+t+"'"):e}}}e.default=a,o.defineProperty(a,"formats",{enumerable:!0,value:{number:{currency:{style:"currency"},percent:{style:"percent"}},shortNumber:{},date:{short:{month:"numeric",day:"numeric",year:"2-digit"},medium:{month:"short",day:"numeric",year:"numeric"},long:{month:"long",day:"numeric",year:"numeric"},full:{weekday:"long",month:"long",day:"numeric",year:"numeric"}},time:{short:{hour:"numeric",minute:"numeric"},medium:{hour:"numeric",minute:"numeric",second:"numeric"},long:{hour:"numeric",minute:"numeric",second:"numeric",timeZoneName:"short"},full:{hour:"numeric",minute:"numeric",second:"numeric",timeZoneName:"short"}}}}),o.defineProperty(a,"__localeData__",{value:o.objCreate(null)}),o.defineProperty(a,"__addLocaleData",{value:function(t){if(!t||!t.locale)throw new Error("Locale data provided to IntlMessageFormat is missing a `locale` property")
a.__localeData__[t.locale.toLowerCase()]=t}}),o.defineProperty(a,"__parse",{value:s.default.parse}),o.defineProperty(a,"defaultLocale",{enumerable:!0,writable:!0,value:void 0}),a.prototype.resolvedOptions=function(){return{locale:this._locale}},a.prototype._compilePattern=function(t,e,n,r){return new i.default(e,n,r).compile(t)},a.prototype._findPluralRuleFunction=function(t){for(var e=a.__localeData__,n=e[t.toLowerCase()];n;){if(n.pluralRuleFunction)return n.pluralRuleFunction
n=n.parentLocale&&e[n.parentLocale.toLowerCase()]}throw new Error("Locale data added to IntlMessageFormat is missing a `pluralRuleFunction` for :"+t)},a.prototype._format=function(t,e){var n,o,i,s,a,c,u=""
for(n=0,o=t.length;n<o;n+=1)if("string"!=typeof(i=t[n])){if(s=i.id,!e||!r.hop.call(e,s))throw(c=new Error("A value must be provided for: "+s)).variableId=s,c
a=e[s],i.options?u+=this._format(i.getOption(a),e):u+=i.format(a)}else u+=i
return u},a.prototype._mergeFormats=function(t,e){var n,i,s={}
for(n in t)r.hop.call(t,n)&&(s[n]=i=o.objCreate(t[n]),e&&r.hop.call(e,n)&&r.extend(i,e[n]))
return s},a.prototype._resolveLocale=function(t){"string"==typeof t&&(t=[t]),t=(t||[]).concat(a.defaultLocale)
var e,n,r,o,i=a.__localeData__
for(e=0,n=t.length;e<n;e+=1)for(r=t[e].toLowerCase().split("-");r.length;){if(o=i[r.join("-")])return o.locale
r.pop()}var s=t.pop()
throw new Error("No locale data has been added to IntlMessageFormat for: "+t.join(", ")+", or the default locale: "+s)}},3885:(t,e)=>{"use strict"
e.default={locale:"en",pluralRuleFunction:function(t,e){var n=String(t).split("."),r=!n[1],o=Number(n[0])==t,i=o&&n[0].slice(-1),s=o&&n[0].slice(-2)
return e?1==i&&11!=s?"one":2==i&&12!=s?"two":3==i&&13!=s?"few":"other":1==t&&r?"one":"other"},numbers:{decimal:{long:[[1e3,{one:["0 thousand",1],other:["0 thousand",1]}],[1e4,{one:["00 thousand",2],other:["00 thousand",2]}],[1e5,{one:["000 thousand",3],other:["000 thousand",3]}],[1e6,{one:["0 million",1],other:["0 million",1]}],[1e7,{one:["00 million",2],other:["00 million",2]}],[1e8,{one:["000 million",3],other:["000 million",3]}],[1e9,{one:["0 billion",1],other:["0 billion",1]}],[1e10,{one:["00 billion",2],other:["00 billion",2]}],[1e11,{one:["000 billion",3],other:["000 billion",3]}],[1e12,{one:["0 trillion",1],other:["0 trillion",1]}],[1e13,{one:["00 trillion",2],other:["00 trillion",2]}],[1e14,{one:["000 trillion",3],other:["000 trillion",3]}]],short:[[1e3,{one:["0K",1],other:["0K",1]}],[1e4,{one:["00K",2],other:["00K",2]}],[1e5,{one:["000K",3],other:["000K",3]}],[1e6,{one:["0M",1],other:["0M",1]}],[1e7,{one:["00M",2],other:["00M",2]}],[1e8,{one:["000M",3],other:["000M",3]}],[1e9,{one:["0B",1],other:["0B",1]}],[1e10,{one:["00B",2],other:["00B",2]}],[1e11,{one:["000B",3],other:["000B",3]}],[1e12,{one:["0T",1],other:["0T",1]}],[1e13,{one:["00T",2],other:["00T",2]}],[1e14,{one:["000T",3],other:["000T",3]}]]}}}},6187:(t,e,n)=>{"use strict"
var r=n(8224),o=function(){try{return!!Object.defineProperty({},"a",{})}catch(t){return!1}}(),i=(!o&&Object.prototype.__defineGetter__,o?Object.defineProperty:function(t,e,n){"get"in n&&t.__defineGetter__?t.__defineGetter__(e,n.get):r.hop.call(t,e)&&!("value"in n)||(t[e]=n.value)}),s=Object.create||function(t,e){var n,o
function s(){}for(o in s.prototype=t,n=new s,e)r.hop.call(e,o)&&i(n,o,e[o])
return n}
e.defineProperty=i,e.objCreate=s},1561:(t,e,n)=>{"use strict"
var r=n(297),o=n(3885)
r.default.__addLocaleData(o.default),r.default.defaultLocale="en",e.Z=r.default},8224:(t,e)=>{"use strict"
e.extend=function(t){var e,r,o,i,s=Array.prototype.slice.call(arguments,1)
for(e=0,r=s.length;e<r;e+=1)if(o=s[e])for(i in o)n.call(o,i)&&(t[i]=o[i])
return t}
var n=Object.prototype.hasOwnProperty
e.hop=n},871:(t,e,n)=>{"use strict"
var r=n(8488).Z
n(5918),(e=t.exports=r).default=e},520:(t,e,n)=>{"use strict"
var r=n(6236),o=n(3395),i=n(2367)
e.default=c
var s=["second","second-short","minute","minute-short","hour","hour-short","day","day-short","month","month-short","year","year-short"],a=["best fit","numeric"]
function c(t,e){e=e||{},i.isArray(t)&&(t=t.concat()),i.defineProperty(this,"_locale",{value:this._resolveLocale(t)}),i.defineProperty(this,"_options",{value:{style:this._resolveStyle(e.style),units:this._isValidUnits(e.units)&&e.units}}),i.defineProperty(this,"_locales",{value:t}),i.defineProperty(this,"_fields",{value:this._findFields(this._locale)}),i.defineProperty(this,"_messages",{value:i.objCreate(null)})
var n=this
this.format=function(t,e){return n._format(t,e)}}i.defineProperty(c,"__localeData__",{value:i.objCreate(null)}),i.defineProperty(c,"__addLocaleData",{value:function(t){if(!t||!t.locale)throw new Error("Locale data provided to IntlRelativeFormat is missing a `locale` property value")
c.__localeData__[t.locale.toLowerCase()]=t,r.default.__addLocaleData(t)}}),i.defineProperty(c,"defaultLocale",{enumerable:!0,writable:!0,value:void 0}),i.defineProperty(c,"thresholds",{enumerable:!0,value:{second:45,"second-short":45,minute:45,"minute-short":45,hour:22,"hour-short":22,day:26,"day-short":26,month:11,"month-short":11}}),c.prototype.resolvedOptions=function(){return{locale:this._locale,style:this._options.style,units:this._options.units}},c.prototype._compileMessage=function(t){var e,n=this._locales,o=(this._locale,this._fields[t].relativeTime),i="",s=""
for(e in o.future)o.future.hasOwnProperty(e)&&(i+=" "+e+" {"+o.future[e].replace("{0}","#")+"}")
for(e in o.past)o.past.hasOwnProperty(e)&&(s+=" "+e+" {"+o.past[e].replace("{0}","#")+"}")
var a="{when, select, future {{0, plural, "+i+"}}past {{0, plural, "+s+"}}}"
return new r.default(a,n)},c.prototype._getMessage=function(t){var e=this._messages
return e[t]||(e[t]=this._compileMessage(t)),e[t]},c.prototype._getRelativeUnits=function(t,e){var n=this._fields[e]
if(n.relative)return n.relative[t]},c.prototype._findFields=function(t){for(var e=c.__localeData__,n=e[t.toLowerCase()];n;){if(n.fields)return n.fields
n=n.parentLocale&&e[n.parentLocale.toLowerCase()]}throw new Error("Locale data added to IntlRelativeFormat is missing `fields` for :"+t)},c.prototype._format=function(t,e){var n=e&&void 0!==e.now?e.now:i.dateNow()
if(void 0===t&&(t=n),!isFinite(n))throw new RangeError("The `now` option provided to IntlRelativeFormat#format() is not in valid range.")
if(!isFinite(t))throw new RangeError("The date value provided to IntlRelativeFormat#format() is not in valid range.")
var r=o.default(n,t),s=this._options.units||this._selectUnits(r),a=r[s]
if("numeric"!==this._options.style){var c=this._getRelativeUnits(a,s)
if(c)return c}return this._getMessage(s).format({0:Math.abs(a),when:a<0?"past":"future"})},c.prototype._isValidUnits=function(t){if(!t||i.arrIndexOf.call(s,t)>=0)return!0
if("string"==typeof t){var e=/s$/.test(t)&&t.substr(0,t.length-1)
if(e&&i.arrIndexOf.call(s,e)>=0)throw new Error('"'+t+'" is not a valid IntlRelativeFormat `units` value, did you mean: '+e)}throw new Error('"'+t+'" is not a valid IntlRelativeFormat `units` value, it must be one of: "'+s.join('", "')+'"')},c.prototype._resolveLocale=function(t){"string"==typeof t&&(t=[t]),t=(t||[]).concat(c.defaultLocale)
var e,n,r,o,i=c.__localeData__
for(e=0,n=t.length;e<n;e+=1)for(r=t[e].toLowerCase().split("-");r.length;){if(o=i[r.join("-")])return o.locale
r.pop()}var s=t.pop()
throw new Error("No locale data has been added to IntlRelativeFormat for: "+t.join(", ")+", or the default locale: "+s)},c.prototype._resolveStyle=function(t){if(!t)return a[0]
if(i.arrIndexOf.call(a,t)>=0)return t
throw new Error('"'+t+'" is not a valid IntlRelativeFormat `style` value, it must be one of: "'+a.join('", "')+'"')},c.prototype._selectUnits=function(t){var e,n,r,o=s.filter((function(t){return t.indexOf("-short")<1}))
for(e=0,n=o.length;e<n&&(r=o[e],!(Math.abs(t[r])<c.thresholds[r]));e+=1);return r}},3395:(t,e)=>{"use strict"
var n=Math.round
e.default=function(t,e){var r=n((e=+e)-(t=+t)),o=n(r/1e3),i=n(o/60),s=n(i/60),a=n(s/24),c=n(a/7),u=400*a/146097,l=n(12*u),p=n(u)
return{millisecond:r,second:o,"second-short":o,minute:i,"minute-short":i,hour:s,"hour-short":s,day:a,"day-short":a,week:c,"week-short":c,month:l,"month-short":l,year:p,"year-short":p}}},4046:(t,e)=>{"use strict"
e.default={locale:"en",pluralRuleFunction:function(t,e){var n=String(t).split("."),r=!n[1],o=Number(n[0])==t,i=o&&n[0].slice(-1),s=o&&n[0].slice(-2)
return e?1==i&&11!=s?"one":2==i&&12!=s?"two":3==i&&13!=s?"few":"other":1==t&&r?"one":"other"},fields:{year:{displayName:"year",relative:{0:"this year",1:"next year","-1":"last year"},relativeTime:{future:{one:"in {0} year",other:"in {0} years"},past:{one:"{0} year ago",other:"{0} years ago"}}},"year-short":{displayName:"yr.",relative:{0:"this yr.",1:"next yr.","-1":"last yr."},relativeTime:{future:{one:"in {0} yr.",other:"in {0} yr."},past:{one:"{0} yr. ago",other:"{0} yr. ago"}}},month:{displayName:"month",relative:{0:"this month",1:"next month","-1":"last month"},relativeTime:{future:{one:"in {0} month",other:"in {0} months"},past:{one:"{0} month ago",other:"{0} months ago"}}},"month-short":{displayName:"mo.",relative:{0:"this mo.",1:"next mo.","-1":"last mo."},relativeTime:{future:{one:"in {0} mo.",other:"in {0} mo."},past:{one:"{0} mo. ago",other:"{0} mo. ago"}}},day:{displayName:"day",relative:{0:"today",1:"tomorrow","-1":"yesterday"},relativeTime:{future:{one:"in {0} day",other:"in {0} days"},past:{one:"{0} day ago",other:"{0} days ago"}}},"day-short":{displayName:"day",relative:{0:"today",1:"tomorrow","-1":"yesterday"},relativeTime:{future:{one:"in {0} day",other:"in {0} days"},past:{one:"{0} day ago",other:"{0} days ago"}}},hour:{displayName:"hour",relative:{0:"this hour"},relativeTime:{future:{one:"in {0} hour",other:"in {0} hours"},past:{one:"{0} hour ago",other:"{0} hours ago"}}},"hour-short":{displayName:"hr.",relative:{0:"this hour"},relativeTime:{future:{one:"in {0} hr.",other:"in {0} hr."},past:{one:"{0} hr. ago",other:"{0} hr. ago"}}},minute:{displayName:"minute",relative:{0:"this minute"},relativeTime:{future:{one:"in {0} minute",other:"in {0} minutes"},past:{one:"{0} minute ago",other:"{0} minutes ago"}}},"minute-short":{displayName:"min.",relative:{0:"this minute"},relativeTime:{future:{one:"in {0} min.",other:"in {0} min."},past:{one:"{0} min. ago",other:"{0} min. ago"}}},second:{displayName:"second",relative:{0:"now"},relativeTime:{future:{one:"in {0} second",other:"in {0} seconds"},past:{one:"{0} second ago",other:"{0} seconds ago"}}},"second-short":{displayName:"sec.",relative:{0:"now"},relativeTime:{future:{one:"in {0} sec.",other:"in {0} sec."},past:{one:"{0} sec. ago",other:"{0} sec. ago"}}}}}},2367:(t,e)=>{"use strict"
var n=Object.prototype.hasOwnProperty,r=Object.prototype.toString,o=function(){try{return!!Object.defineProperty({},"a",{})}catch(t){return!1}}(),i=(!o&&Object.prototype.__defineGetter__,o?Object.defineProperty:function(t,e,r){"get"in r&&t.__defineGetter__?t.__defineGetter__(e,r.get):n.call(t,e)&&!("value"in r)||(t[e]=r.value)}),s=Object.create||function(t,e){var r,o
function s(){}for(o in s.prototype=t,r=new s,e)n.call(e,o)&&i(r,o,e[o])
return r},a=Array.prototype.indexOf||function(t,e){var n=this
if(!n.length)return-1
for(var r=e||0,o=n.length;r<o;r++)if(n[r]===t)return r
return-1},c=Array.isArray||function(t){return"[object Array]"===r.call(t)},u=Date.now||function(){return(new Date).getTime()}
e.defineProperty=i,e.objCreate=s,e.arrIndexOf=a,e.isArray=c,e.dateNow=u},8488:(t,e,n)=>{"use strict"
var r=n(520),o=n(4046)
r.default.__addLocaleData(o.default),r.default.defaultLocale="en",e.Z=r.default},7155:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{BrowserClient:()=>Mt,Hub:()=>l.Xb,Integrations:()=>ie,SDK_NAME:()=>ne,SDK_VERSION:()=>O,Scope:()=>u.s,Severity:()=>s,Status:()=>a,Transports:()=>i,addBreadcrumb:()=>m,addGlobalEventProcessor:()=>u.c,captureEvent:()=>d,captureException:()=>f,captureMessage:()=>h,close:()=>te,configureScope:()=>v,defaultIntegrations:()=>Gt,eventFromException:()=>it,eventFromMessage:()=>st,flush:()=>Qt,forceLoad:()=>Kt,getCurrentHub:()=>l.Gd,getHubFromCarrier:()=>l.vi,init:()=>Jt,injectReportDialog:()=>Rt,lastEventId:()=>Yt,makeMain:()=>l.pj,onLoad:()=>Xt,setContext:()=>_,setExtra:()=>b,setExtras:()=>g,setTag:()=>w,setTags:()=>y,setUser:()=>E,showReportDialog:()=>$t,startTransaction:()=>x,withScope:()=>S,wrap:()=>ee})
var r={}
n.r(r),n.d(r,{FunctionToString:()=>Ft,InboundFilters:()=>Nt})
var o={}
n.r(o),n.d(o,{Breadcrumbs:()=>Lt,Dedupe:()=>zt,GlobalHandlers:()=>Bt,LinkedErrors:()=>qt,TryCatch:()=>Ht,UserAgent:()=>Vt})
var i={}
n.r(i),n.d(i,{BaseTransport:()=>wt,FetchTransport:()=>Et,XHRTransport:()=>St})
var s,a,c=n(7480)
!function(t){t.Fatal="fatal",t.Error="error",t.Warning="warning",t.Log="log",t.Info="info",t.Debug="debug",t.Critical="critical"}(s||(s={})),function(t){t.fromString=function(e){switch(e){case"debug":return t.Debug
case"info":return t.Info
case"warn":case"warning":return t.Warning
case"error":return t.Error
case"fatal":return t.Fatal
case"critical":return t.Critical
default:return t.Log}}}(s||(s={})),function(t){t.Unknown="unknown",t.Skipped="skipped",t.Success="success",t.RateLimit="rate_limit",t.Invalid="invalid",t.Failed="failed"}(a||(a={})),function(t){t.fromHttpCode=function(e){return e>=200&&e<300?t.Success:429===e?t.RateLimit:e>=400&&e<500?t.Invalid:e>=500?t.Failed:t.Unknown}}(a||(a={}))
var u=n(1911),l=n(6599)
function p(t){for(var e=[],n=1;n<arguments.length;n++)e[n-1]=arguments[n]
var r=(0,l.Gd)()
if(r&&r[t])return r[t].apply(r,(0,c.fl)(e))
throw new Error("No hub defined or "+t+" was not found on the hub, please open a bug report.")}function f(t,e){var n
try{throw new Error("Sentry syntheticException")}catch(t){n=t}return p("captureException",t,{captureContext:e,originalException:t,syntheticException:n})}function h(t,e){var n
try{throw new Error(t)}catch(t){n=t}var r="string"!=typeof e?{captureContext:e}:void 0
return p("captureMessage",t,"string"==typeof e?e:void 0,(0,c.pi)({originalException:t,syntheticException:n},r))}function d(t){return p("captureEvent",t)}function v(t){p("configureScope",t)}function m(t){p("addBreadcrumb",t)}function _(t,e){p("setContext",t,e)}function g(t){p("setExtras",t)}function y(t){p("setTags",t)}function b(t,e){p("setExtra",t,e)}function w(t,e){p("setTag",t,e)}function E(t){p("setUser",t)}function S(t){p("withScope",t)}function x(t,e){return p("startTransaction",(0,c.pi)({},t),e)}var O="6.16.1",k=n(9531),T=n(2967),C=n(84),j=n(6438),R=n(190),P=n(8146),D=n(6612),A=n(8505),L=n(7927),M=n(9399),I=n(6589),N=[]
function F(t){return t.reduce((function(t,e){return t.every((function(t){return e.name!==t.name}))&&t.push(e),t}),[])}var U="Not capturing exception because it's already been captured.",W=function(){function t(t,e){this._integrations={},this._numProcessing=0,this._backend=new t(e),this._options=e,e.dsn&&(this._dsn=new C.l(e.dsn))}return t.prototype.captureException=function(t,e,n){var r=this
if(!(0,j.YO)(t)){var o=e&&e.event_id
return this._process(this._getBackend().eventFromException(t,e).then((function(t){return r._captureEvent(t,e,n)})).then((function(t){o=t}))),o}R.k.log(U)},t.prototype.captureMessage=function(t,e,n,r){var o=this,i=n&&n.event_id,s=(0,P.pt)(t)?this._getBackend().eventFromMessage(String(t),e,n):this._getBackend().eventFromException(t,n)
return this._process(s.then((function(t){return o._captureEvent(t,n,r)})).then((function(t){i=t}))),i},t.prototype.captureEvent=function(t,e,n){var r
if(!(null===(r=e)||void 0===r?void 0:r.originalException)||!(0,j.YO)(e.originalException)){var o=e&&e.event_id
return this._process(this._captureEvent(t,e,n).then((function(t){o=t}))),o}R.k.log(U)},t.prototype.captureSession=function(t){this._isEnabled()?"string"!=typeof t.release?R.k.warn("Discarded session because of missing or non-string release"):(this._sendSession(t),t.update({init:!1})):R.k.warn("SDK not enabled, will not capture session.")},t.prototype.getDsn=function(){return this._dsn},t.prototype.getOptions=function(){return this._options},t.prototype.getTransport=function(){return this._getBackend().getTransport()},t.prototype.flush=function(t){var e=this
return this._isClientDoneProcessing(t).then((function(n){return e.getTransport().close(t).then((function(t){return n&&t}))}))},t.prototype.close=function(t){var e=this
return this.flush(t).then((function(t){return e.getOptions().enabled=!1,t}))},t.prototype.setupIntegrations=function(){var t,e
this._isEnabled()&&!this._integrations.initialized&&(this._integrations=(t=this._options,e={},function(t){var e=t.defaultIntegrations&&(0,c.fl)(t.defaultIntegrations)||[],n=t.integrations,r=(0,c.fl)(F(e))
Array.isArray(n)?r=(0,c.fl)(r.filter((function(t){return n.every((function(e){return e.name!==t.name}))})),F(n)):"function"==typeof n&&(r=n(r),r=Array.isArray(r)?r:[r])
var o=r.map((function(t){return t.name})),i="Debug"
return-1!==o.indexOf(i)&&r.push.apply(r,(0,c.fl)(r.splice(o.indexOf(i),1))),r}(t).forEach((function(t){e[t.name]=t,function(t){-1===N.indexOf(t.name)&&(t.setupOnce(u.c,l.Gd),N.push(t.name),R.k.log("Integration installed: "+t.name))}(t)})),Object.defineProperty(e,"initialized",{value:!0}),e))},t.prototype.getIntegration=function(t){try{return this._integrations[t.id]||null}catch(e){return R.k.warn("Cannot retrieve integration "+t.id+" from the current Client"),null}},t.prototype._updateSessionFromEvent=function(t,e){var n,r,o=!1,i=!1,s=e.exception&&e.exception.values
if(s){i=!0
try{for(var a=(0,c.XA)(s),u=a.next();!u.done;u=a.next()){var l=u.value.mechanism
if(l&&!1===l.handled){o=!0
break}}}catch(t){n={error:t}}finally{try{u&&!u.done&&(r=a.return)&&r.call(a)}finally{if(n)throw n.error}}}var p=t.status===k.$.Ok;(p&&0===t.errors||p&&o)&&(t.update((0,c.pi)((0,c.pi)({},o&&{status:k.$.Crashed}),{errors:t.errors||Number(i||o)})),this.captureSession(t))},t.prototype._sendSession=function(t){this._getBackend().sendSession(t)},t.prototype._isClientDoneProcessing=function(t){var e=this
return new D.c((function(n){var r=0,o=setInterval((function(){0==e._numProcessing?(clearInterval(o),n(!0)):(r+=1,t&&r>=t&&(clearInterval(o),n(!1)))}),1)}))},t.prototype._getBackend=function(){return this._backend},t.prototype._isEnabled=function(){return!1!==this.getOptions().enabled&&void 0!==this._dsn},t.prototype._prepareEvent=function(t,e,n){var r=this,o=this.getOptions().normalizeDepth,i=void 0===o?3:o,s=(0,c.pi)((0,c.pi)({},t),{event_id:t.event_id||(n&&n.event_id?n.event_id:(0,j.DM)()),timestamp:t.timestamp||(0,A.yW)()})
this._applyClientOptions(s),this._applyIntegrationsMetadata(s)
var a=e
n&&n.captureContext&&(a=u.s.clone(a).update(n.captureContext))
var l=D.c.resolve(s)
return a&&(l=a.applyToEvent(s,n)),l.then((function(t){return"number"==typeof i&&i>0?r._normalizeEvent(t,i):t}))},t.prototype._normalizeEvent=function(t,e){if(!t)return null
var n=(0,c.pi)((0,c.pi)((0,c.pi)((0,c.pi)((0,c.pi)({},t),t.breadcrumbs&&{breadcrumbs:t.breadcrumbs.map((function(t){return(0,c.pi)((0,c.pi)({},t),t.data&&{data:(0,L.Fv)(t.data,e)})}))}),t.user&&{user:(0,L.Fv)(t.user,e)}),t.contexts&&{contexts:(0,L.Fv)(t.contexts,e)}),t.extra&&{extra:(0,L.Fv)(t.extra,e)})
t.contexts&&t.contexts.trace&&(n.contexts.trace=t.contexts.trace)
var r=this.getOptions()._experiments
return(void 0===r?{}:r).ensureNoCircularStructures?(0,L.Fv)(n):n},t.prototype._applyClientOptions=function(t){var e=this.getOptions(),n=e.environment,r=e.release,o=e.dist,i=e.maxValueLength,s=void 0===i?250:i
"environment"in t||(t.environment="environment"in e?n:"production"),void 0===t.release&&void 0!==r&&(t.release=r),void 0===t.dist&&void 0!==o&&(t.dist=o),t.message&&(t.message=(0,M.$G)(t.message,s))
var a=t.exception&&t.exception.values&&t.exception.values[0]
a&&a.value&&(a.value=(0,M.$G)(a.value,s))
var c=t.request
c&&c.url&&(c.url=(0,M.$G)(c.url,s))},t.prototype._applyIntegrationsMetadata=function(t){var e=Object.keys(this._integrations)
e.length>0&&(t.sdk=t.sdk||{},t.sdk.integrations=(0,c.fl)(t.sdk.integrations||[],e))},t.prototype._sendEvent=function(t){this._getBackend().sendEvent(t)},t.prototype._captureEvent=function(t,e,n){return this._processEvent(t,e,n).then((function(t){return t.event_id}),(function(t){R.k.error(t)}))},t.prototype._processEvent=function(t,e,n){var r,o,i=this,s=this.getOptions(),a=s.beforeSend,c=s.sampleRate,u=this.getTransport()
if(!this._isEnabled())return D.c.reject(new I.b("SDK not enabled, will not capture event."))
var l="transaction"===t.type
return!l&&"number"==typeof c&&Math.random()>c?(null===(o=(r=u).recordLostEvent)||void 0===o||o.call(r,T.k.SampleRate,"event"),D.c.reject(new I.b("Discarding event because it's not included in the random sample (sampling rate = "+c+")"))):this._prepareEvent(t,n,e).then((function(n){var r,o
if(null===n)throw null===(o=(r=u).recordLostEvent)||void 0===o||o.call(r,T.k.EventProcessor,t.type||"event"),new I.b("An event processor returned null, will not send event.")
if(e&&e.data&&!0===e.data.__sentry__||l||!a)return n
var s=a(n,e)
return i._ensureBeforeSendRv(s)})).then((function(e){var r,o
if(null===e)throw null===(o=(r=u).recordLostEvent)||void 0===o||o.call(r,T.k.BeforeSend,t.type||"event"),new I.b("`beforeSend` returned `null`, will not send event.")
var s=n&&n.getSession&&n.getSession()
return!l&&s&&i._updateSessionFromEvent(s,e),i._sendEvent(e),e})).then(null,(function(t){if(t instanceof I.b)throw t
throw i.captureException(t,{data:{__sentry__:!0},originalException:t}),new I.b("Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: "+t)}))},t.prototype._process=function(t){var e=this
this._numProcessing+=1,t.then((function(t){return e._numProcessing-=1,t}),(function(t){return e._numProcessing-=1,t}))},t.prototype._ensureBeforeSendRv=function(t){var e="`beforeSend` method has to return `null` or a valid event."
if((0,P.J8)(t))return t.then((function(t){if(!(0,P.PO)(t)&&null!==t)throw new I.b(e)
return t}),(function(t){throw new I.b("beforeSend rejected with "+t)}))
if(!(0,P.PO)(t)&&null!==t)throw new I.b(e)
return t},t}(),H=n(4387),B=function(){function t(){}return t.prototype.sendEvent=function(t){return D.c.resolve({reason:"NoopTransport: Event has been skipped because no Dsn is configured.",status:a.Skipped})},t.prototype.close=function(t){return D.c.resolve(!0)},t}(),q=function(){function t(t){this._options=t,this._options.dsn||R.k.warn("No DSN provided, backend will not do anything."),this._transport=this._setupTransport()}return t.prototype.eventFromException=function(t,e){throw new I.b("Backend has to implement `eventFromException` method")},t.prototype.eventFromMessage=function(t,e,n){throw new I.b("Backend has to implement `eventFromMessage` method")},t.prototype.sendEvent=function(t){this._transport.sendEvent(t).then(null,(function(t){R.k.error("Error while sending event: "+t)}))},t.prototype.sendSession=function(t){this._transport.sendSession?this._transport.sendSession(t).then(null,(function(t){R.k.error("Error while sending session: "+t)})):R.k.warn("Dropping session because custom transport doesn't implement sendSession")},t.prototype.getTransport=function(){return this._transport},t.prototype._setupTransport=function(){return new B},t}(),z=n(2651),Z="?",V=/^\s*at (?:(.*?) ?\()?((?:file|https?|blob|chrome-extension|address|native|eval|webpack|<anonymous>|[-a-z]+:|.*bundle|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,G=/^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:file|https?|blob|chrome|webpack|resource|moz-extension|capacitor).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,J=/^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,$=/(\S+) line (\d+)(?: > eval line \d+)* > eval/i,Y=/\((\S*)(?::(\d+))(?::(\d+))\)/,K=/Minified React error #\d+;/i
function X(t){var e=null,n=0
t&&("number"==typeof t.framesToPop?n=t.framesToPop:K.test(t.message)&&(n=1))
try{if(e=function(t){if(!t||!t.stacktrace)return null
for(var e,n=/ line (\d+).*script (?:in )?(\S+)(?:: in function (\S+))?$/i,r=/ line (\d+), column (\d+)\s*(?:in (?:<anonymous function: ([^>]+)>|([^)]+))\((.*)\))? in (.*):\s*$/i,o=t.stacktrace.split("\n"),i=[],s=0;s<o.length;s+=2){var a=null;(e=n.exec(o[s]))?a={url:e[2],func:e[3],args:[],line:+e[1],column:null}:(e=r.exec(o[s]))&&(a={url:e[6],func:e[3]||e[4],args:e[5]?e[5].split(","):[],line:+e[1],column:+e[2]}),a&&(!a.func&&a.line&&(a.func=Z),i.push(a))}return i.length?{message:et(t),name:t.name,stack:i}:null}(t))return tt(e,n)}catch(t){}try{if(e=function(t){var e,n
if(!t||!t.stack)return null
for(var r,o,i,s=[],a=t.stack.split("\n"),u=0;u<a.length;++u){if(o=V.exec(a[u])){var l=o[2]&&0===o[2].indexOf("native")
o[2]&&0===o[2].indexOf("eval")&&(r=Y.exec(o[2]))&&(o[2]=r[1],o[3]=r[2],o[4]=r[3])
var p=o[2]&&0===o[2].indexOf("address at ")?o[2].substr("address at ".length):o[2],f=o[1]||Z
f=(e=(0,c.CR)(Q(f,p),2))[0],i={url:p=e[1],func:f,args:l?[o[2]]:[],line:o[3]?+o[3]:null,column:o[4]?+o[4]:null}}else if(o=J.exec(a[u]))i={url:o[2],func:o[1]||Z,args:[],line:+o[3],column:o[4]?+o[4]:null}
else{if(!(o=G.exec(a[u])))continue
o[3]&&o[3].indexOf(" > eval")>-1&&(r=$.exec(o[3]))?(o[1]=o[1]||"eval",o[3]=r[1],o[4]=r[2],o[5]=""):0!==u||o[5]||void 0===t.columnNumber||(s[0].column=t.columnNumber+1),p=o[3],f=o[1]||Z,f=(n=(0,c.CR)(Q(f,p),2))[0],i={url:p=n[1],func:f,args:o[2]?o[2].split(","):[],line:o[4]?+o[4]:null,column:o[5]?+o[5]:null}}!i.func&&i.line&&(i.func=Z),s.push(i)}return s.length?{message:et(t),name:t.name,stack:s}:null}(t))return tt(e,n)}catch(t){}return{message:et(t),name:t&&t.name,stack:[],failed:!0}}var Q=function(t,e){var n=-1!==t.indexOf("safari-extension"),r=-1!==t.indexOf("safari-web-extension")
return n||r?[-1!==t.indexOf("@")?t.split("@")[0]:Z,n?"safari-extension:"+e:"safari-web-extension:"+e]:[t,e]}
function tt(t,e){try{return(0,c.pi)((0,c.pi)({},t),{stack:t.stack.slice(e)})}catch(e){return t}}function et(t){var e=t&&t.message
return e?e.error&&"string"==typeof e.error.message?e.error.message:e:"No error message"}function nt(t){var e=ot(t.stack),n={type:t.name,value:t.message}
return e&&e.length&&(n.stacktrace={frames:e}),void 0===n.type&&""===n.value&&(n.value="Unrecoverable error caught"),n}function rt(t){return{exception:{values:[nt(t)]}}}function ot(t){if(!t||!t.length)return[]
var e=t,n=e[0].func||"",r=e[e.length-1].func||""
return-1===n.indexOf("captureMessage")&&-1===n.indexOf("captureException")||(e=e.slice(1)),-1!==r.indexOf("sentryWrapped")&&(e=e.slice(0,-1)),e.slice(0,50).map((function(t){return{colno:null===t.column?void 0:t.column,filename:t.url||e[0].url,function:t.func||"?",in_app:!0,lineno:null===t.line?void 0:t.line}})).reverse()}function it(t,e,n){var r=at(e,n&&n.syntheticException||void 0,{attachStacktrace:t.attachStacktrace})
return(0,j.EG)(r),r.level=s.Error,n&&n.event_id&&(r.event_id=n.event_id),D.c.resolve(r)}function st(t,e,n,r){void 0===n&&(n=s.Info)
var o=ct(e,r&&r.syntheticException||void 0,{attachStacktrace:t.attachStacktrace})
return o.level=n,r&&r.event_id&&(o.event_id=r.event_id),D.c.resolve(o)}function at(t,e,n){var r
if(void 0===n&&(n={}),(0,P.VW)(t)&&t.error)return rt(X(t=t.error))
if((0,P.TX)(t)||(0,P.fm)(t)){var o=t
if("stack"in t)r=rt(X(t))
else{var i=o.name||((0,P.TX)(o)?"DOMError":"DOMException"),s=o.message?i+": "+o.message:i
r=ct(s,e,n),(0,j.Db)(r,s)}return"code"in o&&(r.tags=(0,c.pi)((0,c.pi)({},r.tags),{"DOMException.code":""+o.code})),r}return(0,P.VZ)(t)?r=rt(X(t)):(0,P.PO)(t)||(0,P.cO)(t)?(r=function(t,e,n){var r={exception:{values:[{type:(0,P.cO)(t)?t.constructor.name:n?"UnhandledRejection":"Error",value:"Non-Error "+(n?"promise rejection":"exception")+" captured with keys: "+(0,L.zf)(t)}]},extra:{__serialized__:(0,L.Qy)(t)}}
if(e){var o=ot(X(e).stack)
r.stacktrace={frames:o}}return r}(t,e,n.rejection),(0,j.EG)(r,{synthetic:!0}),r):(r=ct(t,e,n),(0,j.Db)(r,""+t,void 0),(0,j.EG)(r,{synthetic:!0}),r)}function ct(t,e,n){void 0===n&&(n={})
var r={message:t}
if(n.attachStacktrace&&e){var o=ot(X(e).stack)
r.stacktrace={frames:o}}return r}function ut(t){if(t.metadata&&t.metadata.sdk){var e=t.metadata.sdk
return{name:e.name,version:e.version}}}function lt(t,e){return e?(t.sdk=t.sdk||{},t.sdk.name=t.sdk.name||e.name,t.sdk.version=t.sdk.version||e.version,t.sdk.integrations=(0,c.fl)(t.sdk.integrations||[],e.integrations||[]),t.sdk.packages=(0,c.fl)(t.sdk.packages||[],e.packages||[]),t):t}function pt(t,e){var n=ut(e),r="aggregates"in t?"sessions":"session"
return{body:JSON.stringify((0,c.pi)((0,c.pi)({sent_at:(new Date).toISOString()},n&&{sdk:n}),e.forceEnvelope()&&{dsn:e.getDsn().toString()}))+"\n"+JSON.stringify({type:r})+"\n"+JSON.stringify(t),type:r,url:e.getEnvelopeEndpointWithUrlEncodedAuth()}}function ft(t,e){var n=ut(e),r=t.type||"event",o="transaction"===r||e.forceEnvelope(),i=t.debug_meta||{},s=i.transactionSampling,a=(0,c._T)(i,["transactionSampling"]),u=s||{},l=u.method,p=u.rate
0===Object.keys(a).length?delete t.debug_meta:t.debug_meta=a
var f={body:JSON.stringify(n?lt(t,e.metadata.sdk):t),type:r,url:o?e.getEnvelopeEndpointWithUrlEncodedAuth():e.getStoreEndpointWithUrlEncodedAuth()}
if(o){var h=JSON.stringify((0,c.pi)((0,c.pi)({event_id:t.event_id,sent_at:(new Date).toISOString()},n&&{sdk:n}),e.forceEnvelope()&&{dsn:e.getDsn().toString()}))+"\n"+JSON.stringify({type:r,sample_rates:[{id:l,rate:p}]})+"\n"+f.body
f.body=h}return f}var ht,dt=function(){function t(t,e,n){void 0===e&&(e={}),this.dsn=t,this._dsnObject=new C.l(t),this.metadata=e,this._tunnel=n}return t.prototype.getDsn=function(){return this._dsnObject},t.prototype.forceEnvelope=function(){return!!this._tunnel},t.prototype.getBaseApiEndpoint=function(){var t=this.getDsn(),e=t.protocol?t.protocol+":":"",n=t.port?":"+t.port:""
return e+"//"+t.host+n+(t.path?"/"+t.path:"")+"/api/"},t.prototype.getStoreEndpoint=function(){return this._getIngestEndpoint("store")},t.prototype.getStoreEndpointWithUrlEncodedAuth=function(){return this.getStoreEndpoint()+"?"+this._encodedAuth()},t.prototype.getEnvelopeEndpointWithUrlEncodedAuth=function(){return this.forceEnvelope()?this._tunnel:this._getEnvelopeEndpoint()+"?"+this._encodedAuth()},t.prototype.getStoreEndpointPath=function(){var t=this.getDsn()
return(t.path?"/"+t.path:"")+"/api/"+t.projectId+"/store/"},t.prototype.getRequestHeaders=function(t,e){var n=this.getDsn(),r=["Sentry sentry_version=7"]
return r.push("sentry_client="+t+"/"+e),r.push("sentry_key="+n.publicKey),n.pass&&r.push("sentry_secret="+n.pass),{"Content-Type":"application/json","X-Sentry-Auth":r.join(", ")}},t.prototype.getReportDialogEndpoint=function(t){void 0===t&&(t={})
var e=this.getDsn(),n=this.getBaseApiEndpoint()+"embed/error-page/",r=[]
for(var o in r.push("dsn="+e.toString()),t)if("dsn"!==o)if("user"===o){if(!t.user)continue
t.user.name&&r.push("name="+encodeURIComponent(t.user.name)),t.user.email&&r.push("email="+encodeURIComponent(t.user.email))}else r.push(encodeURIComponent(o)+"="+encodeURIComponent(t[o]))
return r.length?n+"?"+r.join("&"):n},t.prototype._getEnvelopeEndpoint=function(){return this._getIngestEndpoint("envelope")},t.prototype._getIngestEndpoint=function(t){return this._tunnel?this._tunnel:""+this.getBaseApiEndpoint()+this.getDsn().projectId+"/"+t+"/"},t.prototype._encodedAuth=function(){var t={sentry_key:this.getDsn().publicKey,sentry_version:"7"}
return(0,L._j)(t)},t}(),vt=n(5473),mt=n(6995),_t=(0,H.R)()
function gt(){var t,e
if(ht)return ht
if((0,z.Du)(_t.fetch))return ht=_t.fetch.bind(_t)
var n=_t.document,r=_t.fetch
if("function"==typeof(null===(t=n)||void 0===t?void 0:t.createElement))try{var o=n.createElement("iframe")
o.hidden=!0,n.head.appendChild(o),(null===(e=o.contentWindow)||void 0===e?void 0:e.fetch)&&(r=o.contentWindow.fetch),n.head.removeChild(o)}catch(t){R.k.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ",t)}return ht=r.bind(_t)}var yt={event:"error",transaction:"transaction",session:"session",attachment:"attachment"},bt=(0,H.R)(),wt=function(){function t(t){var e=this
this.options=t,this._buffer=new vt.D(30),this._rateLimits={},this._outcomes={},this._api=new dt(t.dsn,t._metadata,t.tunnel),this.url=this._api.getStoreEndpointWithUrlEncodedAuth(),this.options.sendClientReports&&bt.document&&bt.document.addEventListener("visibilitychange",(function(){"hidden"===bt.document.visibilityState&&e._flushOutcomes()}))}return t.prototype.sendEvent=function(t){throw new I.b("Transport Class has to implement `sendEvent` method")},t.prototype.close=function(t){return this._buffer.drain(t)},t.prototype.recordLostEvent=function(t,e){var n
if(this.options.sendClientReports){var r=yt[e]+":"+t
R.k.log("Adding outcome: "+r),this._outcomes[r]=(null!=(n=this._outcomes[r])?n:0)+1}},t.prototype._flushOutcomes=function(){if(this.options.sendClientReports){var t=this._outcomes
if(this._outcomes={},Object.keys(t).length){R.k.log("Flushing outcomes:\n"+JSON.stringify(t,null,2))
var e=this._api.getEnvelopeEndpointWithUrlEncodedAuth(),n=JSON.stringify((0,c.pi)({},this.options.tunnel&&{dsn:this._api.getDsn().toString()}))+"\n"+JSON.stringify({type:"client_report"})+"\n"+JSON.stringify({timestamp:(0,A.yW)(),discarded_events:Object.keys(t).map((function(e){var n=(0,c.CR)(e.split(":"),2),r=n[0]
return{reason:n[1],category:r,quantity:t[e]}}))})
try{!function(t,e){if("[object Navigator]"===Object.prototype.toString.call(_t&&_t.navigator)&&"function"==typeof _t.navigator.sendBeacon)return _t.navigator.sendBeacon.bind(_t.navigator)(t,e)
if((0,z.Ak)()){var n=gt();(0,mt.I)(n(t,{body:e,method:"POST",credentials:"omit",keepalive:!0}))}}(e,n)}catch(t){R.k.error(t)}}else R.k.log("No outcomes to flush")}},t.prototype._handleResponse=function(t){var e=t.requestType,n=t.response,r=t.headers,o=t.resolve,i=t.reject,s=a.fromHttpCode(n.status)
this._handleRateLimit(r)&&R.k.warn("Too many "+e+" requests, backing off until: "+this._disabledUntil(e)),s!==a.Success?i(n):o({status:s})},t.prototype._disabledUntil=function(t){var e=yt[t]
return this._rateLimits[e]||this._rateLimits.all},t.prototype._isRateLimited=function(t){return this._disabledUntil(t)>new Date(Date.now())},t.prototype._handleRateLimit=function(t){var e,n,r,o,i=Date.now(),s=t["x-sentry-rate-limits"],a=t["retry-after"]
if(s){try{for(var u=(0,c.XA)(s.trim().split(",")),l=u.next();!l.done;l=u.next()){var p=l.value.split(":",2),f=parseInt(p[0],10),h=1e3*(isNaN(f)?60:f)
try{for(var d=(r=void 0,(0,c.XA)(p[1].split(";"))),v=d.next();!v.done;v=d.next()){var m=v.value
this._rateLimits[m||"all"]=new Date(i+h)}}catch(t){r={error:t}}finally{try{v&&!v.done&&(o=d.return)&&o.call(d)}finally{if(r)throw r.error}}}}catch(t){e={error:t}}finally{try{l&&!l.done&&(n=u.return)&&n.call(u)}finally{if(e)throw e.error}}return!0}return!!a&&(this._rateLimits.all=new Date(i+(0,j.JY)(i,a)),!0)},t}(),Et=function(t){function e(e,n){void 0===n&&(n=gt())
var r=t.call(this,e)||this
return r._fetch=n,r}return(0,c.ZT)(e,t),e.prototype.sendEvent=function(t){return this._sendRequest(ft(t,this._api),t)},e.prototype.sendSession=function(t){return this._sendRequest(pt(t,this._api),t)},e.prototype._sendRequest=function(t,e){var n=this
if(this._isRateLimited(t.type))return this.recordLostEvent(T.k.RateLimitBackoff,t.type),Promise.reject({event:e,type:t.type,reason:"Transport for "+t.type+" requests locked till "+this._disabledUntil(t.type)+" due to too many requests.",status:429})
var r={body:t.body,method:"POST",referrerPolicy:(0,z.hv)()?"origin":""}
return void 0!==this.options.fetchParameters&&Object.assign(r,this.options.fetchParameters),void 0!==this.options.headers&&(r.headers=this.options.headers),this._buffer.add((function(){return new D.c((function(e,o){n._fetch(t.url,r).then((function(r){var i={"x-sentry-rate-limits":r.headers.get("X-Sentry-Rate-Limits"),"retry-after":r.headers.get("Retry-After")}
n._handleResponse({requestType:t.type,response:r,headers:i,resolve:e,reject:o})})).catch(o)}))})).then(void 0,(function(e){throw e instanceof I.b?n.recordLostEvent(T.k.QueueOverflow,t.type):n.recordLostEvent(T.k.NetworkError,t.type),e}))},e}(wt),St=function(t){function e(){return null!==t&&t.apply(this,arguments)||this}return(0,c.ZT)(e,t),e.prototype.sendEvent=function(t){return this._sendRequest(ft(t,this._api),t)},e.prototype.sendSession=function(t){return this._sendRequest(pt(t,this._api),t)},e.prototype._sendRequest=function(t,e){var n=this
return this._isRateLimited(t.type)?(this.recordLostEvent(T.k.RateLimitBackoff,t.type),Promise.reject({event:e,type:t.type,reason:"Transport for "+t.type+" requests locked till "+this._disabledUntil(t.type)+" due to too many requests.",status:429})):this._buffer.add((function(){return new D.c((function(e,r){var o=new XMLHttpRequest
for(var i in o.onreadystatechange=function(){if(4===o.readyState){var i={"x-sentry-rate-limits":o.getResponseHeader("X-Sentry-Rate-Limits"),"retry-after":o.getResponseHeader("Retry-After")}
n._handleResponse({requestType:t.type,response:o,headers:i,resolve:e,reject:r})}},o.open("POST",t.url),n.options.headers)Object.prototype.hasOwnProperty.call(n.options.headers,i)&&o.setRequestHeader(i,n.options.headers[i])
o.send(t.body)}))})).then(void 0,(function(e){throw e instanceof I.b?n.recordLostEvent(T.k.QueueOverflow,t.type):n.recordLostEvent(T.k.NetworkError,t.type),e}))},e}(wt),xt=function(t){function e(){return null!==t&&t.apply(this,arguments)||this}return(0,c.ZT)(e,t),e.prototype.eventFromException=function(t,e){return it(this._options,t,e)},e.prototype.eventFromMessage=function(t,e,n){return void 0===e&&(e=s.Info),st(this._options,t,e,n)},e.prototype._setupTransport=function(){if(!this._options.dsn)return t.prototype._setupTransport.call(this)
var e=(0,c.pi)((0,c.pi)({},this._options.transportOptions),{dsn:this._options.dsn,tunnel:this._options.tunnel,sendClientReports:this._options.sendClientReports,_metadata:this._options._metadata})
return this._options.transport?new this._options.transport(e):(0,z.Ak)()?new Et(e):new St(e)},e}(q),Ot=(0,H.R)(),kt=0
function Tt(){return kt>0}function Ct(){kt+=1,setTimeout((function(){kt-=1}))}function jt(t,e,n){if(void 0===e&&(e={}),"function"!=typeof t)return t
try{if(t.__sentry__)return t
if(t.__sentry_wrapped__)return t.__sentry_wrapped__}catch(e){return t}var r=function(){var r=Array.prototype.slice.call(arguments)
try{n&&"function"==typeof n&&n.apply(this,arguments)
var o=r.map((function(t){return jt(t,e)}))
return t.handleEvent?t.handleEvent.apply(this,o):t.apply(this,o)}catch(t){throw Ct(),S((function(o){o.addEventProcessor((function(t){var n=(0,c.pi)({},t)
return e.mechanism&&((0,j.Db)(n,void 0,void 0),(0,j.EG)(n,e.mechanism)),n.extra=(0,c.pi)((0,c.pi)({},n.extra),{arguments:r}),n})),f(t)})),t}}
try{for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&(r[o]=t[o])}catch(t){}t.prototype=t.prototype||{},r.prototype=t.prototype,Object.defineProperty(t,"__sentry_wrapped__",{enumerable:!1,value:r}),Object.defineProperties(r,{__sentry__:{enumerable:!1,value:!0},__sentry_original__:{enumerable:!1,value:t}})
try{Object.getOwnPropertyDescriptor(r,"name").configurable&&Object.defineProperty(r,"name",{get:function(){return t.name}})}catch(t){}return r}function Rt(t){if(void 0===t&&(t={}),Ot.document)if(t.eventId)if(t.dsn){var e=Ot.document.createElement("script")
e.async=!0,e.src=new dt(t.dsn).getReportDialogEndpoint(t),t.onLoad&&(e.onload=t.onLoad)
var n=Ot.document.head||Ot.document.body
n&&n.appendChild(e)}else R.k.error("Missing dsn option in showReportDialog call")
else R.k.error("Missing eventId option in showReportDialog call")}var Pt,Dt=n(5670),At=n(7809),Lt=function(){function t(e){this.name=t.id,this._options=(0,c.pi)({console:!0,dom:!0,fetch:!0,history:!0,sentry:!0,xhr:!0},e)}return t.prototype.addSentryBreadcrumb=function(t){this._options.sentry&&(0,l.Gd)().addBreadcrumb({category:"sentry."+("transaction"===t.type?"transaction":"event"),event_id:t.event_id,level:t.level,message:(0,j.jH)(t)},{event:t})},t.prototype.setupOnce=function(){var t=this
this._options.console&&(0,Dt.o)({callback:function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
t._consoleBreadcrumb.apply(t,(0,c.fl)(e))},type:"console"}),this._options.dom&&(0,Dt.o)({callback:function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
t._domBreadcrumb.apply(t,(0,c.fl)(e))},type:"dom"}),this._options.xhr&&(0,Dt.o)({callback:function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
t._xhrBreadcrumb.apply(t,(0,c.fl)(e))},type:"xhr"}),this._options.fetch&&(0,Dt.o)({callback:function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
t._fetchBreadcrumb.apply(t,(0,c.fl)(e))},type:"fetch"}),this._options.history&&(0,Dt.o)({callback:function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
t._historyBreadcrumb.apply(t,(0,c.fl)(e))},type:"history"})},t.prototype._consoleBreadcrumb=function(t){var e={category:"console",data:{arguments:t.args,logger:"console"},level:s.fromString(t.level),message:(0,M.nK)(t.args," ")}
if("assert"===t.level){if(!1!==t.args[0])return
e.message="Assertion failed: "+((0,M.nK)(t.args.slice(1)," ")||"console.assert"),e.data.arguments=t.args.slice(1)}(0,l.Gd)().addBreadcrumb(e,{input:t.args,level:t.level})},t.prototype._domBreadcrumb=function(t){var e,n="object"==typeof this._options.dom?this._options.dom.serializeAttribute:void 0
"string"==typeof n&&(n=[n])
try{e=t.event.target?(0,At.R)(t.event.target,n):(0,At.R)(t.event,n)}catch(t){e="<unknown>"}0!==e.length&&(0,l.Gd)().addBreadcrumb({category:"ui."+t.name,message:e},{event:t.event,name:t.name,global:t.global})},t.prototype._xhrBreadcrumb=function(t){if(t.endTimestamp){if(t.xhr.__sentry_own_request__)return
var e=t.xhr.__sentry_xhr__||{},n=e.method,r=e.url,o=e.status_code,i=e.body;(0,l.Gd)().addBreadcrumb({category:"xhr",data:{method:n,url:r,status_code:o},type:"http"},{xhr:t.xhr,input:i})}},t.prototype._fetchBreadcrumb=function(t){t.endTimestamp&&(t.fetchData.url.match(/sentry_key/)&&"POST"===t.fetchData.method||(t.error?(0,l.Gd)().addBreadcrumb({category:"fetch",data:t.fetchData,level:s.Error,type:"http"},{data:t.error,input:t.args}):(0,l.Gd)().addBreadcrumb({category:"fetch",data:(0,c.pi)((0,c.pi)({},t.fetchData),{status_code:t.response.status}),type:"http"},{input:t.args,response:t.response})))},t.prototype._historyBreadcrumb=function(t){var e=(0,H.R)(),n=t.from,r=t.to,o=(0,j.en)(e.location.href),i=(0,j.en)(n),s=(0,j.en)(r)
i.path||(i=o),o.protocol===s.protocol&&o.host===s.host&&(r=s.relative),o.protocol===i.protocol&&o.host===i.host&&(n=i.relative),(0,l.Gd)().addBreadcrumb({category:"navigation",data:{from:n,to:r}})},t.id="Breadcrumbs",t}(),Mt=function(t){function e(e){return void 0===e&&(e={}),e._metadata=e._metadata||{},e._metadata.sdk=e._metadata.sdk||{name:"sentry.javascript.browser",packages:[{name:"npm:@sentry/browser",version:O}],version:O},t.call(this,xt,e)||this}return(0,c.ZT)(e,t),e.prototype.showReportDialog=function(t){void 0===t&&(t={}),(0,H.R)().document&&(this._isEnabled()?Rt((0,c.pi)((0,c.pi)({},t),{dsn:t.dsn||this.getDsn()})):R.k.error("Trying to call showReportDialog with Sentry Client disabled"))},e.prototype._prepareEvent=function(e,n,r){return e.platform=e.platform||"javascript",t.prototype._prepareEvent.call(this,e,n,r)},e.prototype._sendEvent=function(e){var n=this.getIntegration(Lt)
n&&n.addSentryBreadcrumb(e),t.prototype._sendEvent.call(this,e)},e}(W),It=[/^Script error\.?$/,/^Javascript error: Script error\.? on line 0$/],Nt=function(){function t(e){void 0===e&&(e={}),this._options=e,this.name=t.id}return t.prototype.setupOnce=function(){(0,u.c)((function(e){var n=(0,l.Gd)()
if(!n)return e
var r=n.getIntegration(t)
if(r){var o=n.getClient(),i=o?o.getOptions():{},s="function"==typeof r._mergeOptions?r._mergeOptions(i):{}
return"function"!=typeof r._shouldDropEvent?e:r._shouldDropEvent(e,s)?null:e}return e}))},t.prototype._shouldDropEvent=function(t,e){return this._isSentryError(t,e)?(R.k.warn("Event dropped due to being internal Sentry Error.\nEvent: "+(0,j.jH)(t)),!0):this._isIgnoredError(t,e)?(R.k.warn("Event dropped due to being matched by `ignoreErrors` option.\nEvent: "+(0,j.jH)(t)),!0):this._isDeniedUrl(t,e)?(R.k.warn("Event dropped due to being matched by `denyUrls` option.\nEvent: "+(0,j.jH)(t)+".\nUrl: "+this._getEventFilterUrl(t)),!0):!this._isAllowedUrl(t,e)&&(R.k.warn("Event dropped due to not being matched by `allowUrls` option.\nEvent: "+(0,j.jH)(t)+".\nUrl: "+this._getEventFilterUrl(t)),!0)},t.prototype._isSentryError=function(t,e){if(!e.ignoreInternal)return!1
try{return t&&t.exception&&t.exception.values&&t.exception.values[0]&&"SentryError"===t.exception.values[0].type||!1}catch(t){return!1}},t.prototype._isIgnoredError=function(t,e){return!(!e.ignoreErrors||!e.ignoreErrors.length)&&this._getPossibleEventMessages(t).some((function(t){return e.ignoreErrors.some((function(e){return(0,M.zC)(t,e)}))}))},t.prototype._isDeniedUrl=function(t,e){if(!e.denyUrls||!e.denyUrls.length)return!1
var n=this._getEventFilterUrl(t)
return!!n&&e.denyUrls.some((function(t){return(0,M.zC)(n,t)}))},t.prototype._isAllowedUrl=function(t,e){if(!e.allowUrls||!e.allowUrls.length)return!0
var n=this._getEventFilterUrl(t)
return!n||e.allowUrls.some((function(t){return(0,M.zC)(n,t)}))},t.prototype._mergeOptions=function(t){return void 0===t&&(t={}),{allowUrls:(0,c.fl)(this._options.whitelistUrls||[],this._options.allowUrls||[],t.whitelistUrls||[],t.allowUrls||[]),denyUrls:(0,c.fl)(this._options.blacklistUrls||[],this._options.denyUrls||[],t.blacklistUrls||[],t.denyUrls||[]),ignoreErrors:(0,c.fl)(this._options.ignoreErrors||[],t.ignoreErrors||[],It),ignoreInternal:void 0===this._options.ignoreInternal||this._options.ignoreInternal}},t.prototype._getPossibleEventMessages=function(t){if(t.message)return[t.message]
if(t.exception)try{var e=t.exception.values&&t.exception.values[0]||{},n=e.type,r=void 0===n?"":n,o=e.value,i=void 0===o?"":o
return[""+i,r+": "+i]}catch(e){return R.k.error("Cannot extract message for event "+(0,j.jH)(t)),[]}return[]},t.prototype._getLastValidUrl=function(t){var e,n
void 0===t&&(t=[])
for(var r=t.length-1;r>=0;r--){var o=t[r]
if("<anonymous>"!==(null===(e=o)||void 0===e?void 0:e.filename)&&"[native code]"!==(null===(n=o)||void 0===n?void 0:n.filename))return o.filename||null}return null},t.prototype._getEventFilterUrl=function(t){try{if(t.stacktrace){var e=t.stacktrace.frames
return this._getLastValidUrl(e)}if(t.exception){var n=t.exception.values&&t.exception.values[0].stacktrace&&t.exception.values[0].stacktrace.frames
return this._getLastValidUrl(n)}return null}catch(e){return R.k.error("Cannot extract url for event "+(0,j.jH)(t)),null}},t.id="InboundFilters",t}(),Ft=function(){function t(){this.name=t.id}return t.prototype.setupOnce=function(){Pt=Function.prototype.toString,Function.prototype.toString=function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e]
var n=this.__sentry_original__||this
return Pt.apply(n,t)}},t.id="FunctionToString",t}(),Ut=n(7879),Wt=["EventTarget","Window","Node","ApplicationCache","AudioTrackList","ChannelMergerNode","CryptoOperation","EventSource","FileReader","HTMLUnknownElement","IDBDatabase","IDBRequest","IDBTransaction","KeyOperation","MediaController","MessagePort","ModalWindow","Notification","SVGElementInstance","Screen","TextTrack","TextTrackCue","TextTrackList","WebSocket","WebSocketWorker","Worker","XMLHttpRequest","XMLHttpRequestEventTarget","XMLHttpRequestUpload"],Ht=function(){function t(e){this.name=t.id,this._options=(0,c.pi)({XMLHttpRequest:!0,eventTarget:!0,requestAnimationFrame:!0,setInterval:!0,setTimeout:!0},e)}return t.prototype.setupOnce=function(){var t=(0,H.R)()
this._options.setTimeout&&(0,L.hl)(t,"setTimeout",this._wrapTimeFunction.bind(this)),this._options.setInterval&&(0,L.hl)(t,"setInterval",this._wrapTimeFunction.bind(this)),this._options.requestAnimationFrame&&(0,L.hl)(t,"requestAnimationFrame",this._wrapRAF.bind(this)),this._options.XMLHttpRequest&&"XMLHttpRequest"in t&&(0,L.hl)(XMLHttpRequest.prototype,"send",this._wrapXHR.bind(this)),this._options.eventTarget&&(Array.isArray(this._options.eventTarget)?this._options.eventTarget:Wt).forEach(this._wrapEventTarget.bind(this))},t.prototype._wrapTimeFunction=function(t){return function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
var r=e[0]
return e[0]=jt(r,{mechanism:{data:{function:(0,Ut.$)(t)},handled:!0,type:"instrument"}}),t.apply(this,e)}},t.prototype._wrapRAF=function(t){return function(e){return t.call(this,jt(e,{mechanism:{data:{function:"requestAnimationFrame",handler:(0,Ut.$)(t)},handled:!0,type:"instrument"}}))}},t.prototype._wrapEventTarget=function(t){var e=(0,H.R)(),n=e[t]&&e[t].prototype
n&&n.hasOwnProperty&&n.hasOwnProperty("addEventListener")&&((0,L.hl)(n,"addEventListener",(function(e){return function(n,r,o){try{"function"==typeof r.handleEvent&&(r.handleEvent=jt(r.handleEvent.bind(r),{mechanism:{data:{function:"handleEvent",handler:(0,Ut.$)(r),target:t},handled:!0,type:"instrument"}}))}catch(t){}return e.call(this,n,jt(r,{mechanism:{data:{function:"addEventListener",handler:(0,Ut.$)(r),target:t},handled:!0,type:"instrument"}}),o)}})),(0,L.hl)(n,"removeEventListener",(function(t){return function(e,n,r){var o,i=n
try{var s=null===(o=i)||void 0===o?void 0:o.__sentry_wrapped__
s&&t.call(this,e,s,r)}catch(t){}return t.call(this,e,i,r)}})))},t.prototype._wrapXHR=function(t){return function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
var r=this,o=["onload","onerror","onprogress","onreadystatechange"]
return o.forEach((function(t){t in r&&"function"==typeof r[t]&&(0,L.hl)(r,t,(function(e){var n={mechanism:{data:{function:t,handler:(0,Ut.$)(e)},handled:!0,type:"instrument"}}
return e.__sentry_original__&&(n.mechanism.data.handler=(0,Ut.$)(e.__sentry_original__)),jt(e,n)}))})),t.apply(this,e)}},t.id="TryCatch",t}(),Bt=function(){function t(e){this.name=t.id,this._onErrorHandlerInstalled=!1,this._onUnhandledRejectionHandlerInstalled=!1,this._options=(0,c.pi)({onerror:!0,onunhandledrejection:!0},e)}return t.prototype.setupOnce=function(){Error.stackTraceLimit=50,this._options.onerror&&(R.k.log("Global Handler attached: onerror"),this._installGlobalOnErrorHandler()),this._options.onunhandledrejection&&(R.k.log("Global Handler attached: onunhandledrejection"),this._installGlobalOnUnhandledRejectionHandler())},t.prototype._installGlobalOnErrorHandler=function(){var e=this
this._onErrorHandlerInstalled||((0,Dt.o)({callback:function(n){var r=n.error,o=(0,l.Gd)(),i=o.getIntegration(t),s=r&&!0===r.__sentry_own_request__
if(i&&!Tt()&&!s){var a=o.getClient(),c=void 0===r&&(0,P.HD)(n.msg)?e._eventFromIncompleteOnError(n.msg,n.url,n.line,n.column):e._enhanceEventWithInitialFrame(at(r||n.msg,void 0,{attachStacktrace:a&&a.getOptions().attachStacktrace,rejection:!1}),n.url,n.line,n.column);(0,j.EG)(c,{handled:!1,type:"onerror"}),o.captureEvent(c,{originalException:r})}},type:"error"}),this._onErrorHandlerInstalled=!0)},t.prototype._installGlobalOnUnhandledRejectionHandler=function(){var e=this
this._onUnhandledRejectionHandlerInstalled||((0,Dt.o)({callback:function(n){var r=n
try{"reason"in n?r=n.reason:"detail"in n&&"reason"in n.detail&&(r=n.detail.reason)}catch(t){}var o=(0,l.Gd)(),i=o.getIntegration(t),a=r&&!0===r.__sentry_own_request__
if(!i||Tt()||a)return!0
var c=o.getClient(),u=(0,P.pt)(r)?e._eventFromRejectionWithPrimitive(r):at(r,void 0,{attachStacktrace:c&&c.getOptions().attachStacktrace,rejection:!0})
u.level=s.Error,(0,j.EG)(u,{handled:!1,type:"onunhandledrejection"}),o.captureEvent(u,{originalException:r})},type:"unhandledrejection"}),this._onUnhandledRejectionHandlerInstalled=!0)},t.prototype._eventFromIncompleteOnError=function(t,e,n,r){var o,i=(0,P.VW)(t)?t.message:t,s=i.match(/^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i)
s&&(o=s[1],i=s[2])
var a={exception:{values:[{type:o||"Error",value:i}]}}
return this._enhanceEventWithInitialFrame(a,e,n,r)},t.prototype._eventFromRejectionWithPrimitive=function(t){return{exception:{values:[{type:"UnhandledRejection",value:"Non-Error promise rejection captured with value: "+String(t)}]}}},t.prototype._enhanceEventWithInitialFrame=function(t,e,n,r){t.exception=t.exception||{},t.exception.values=t.exception.values||[],t.exception.values[0]=t.exception.values[0]||{},t.exception.values[0].stacktrace=t.exception.values[0].stacktrace||{},t.exception.values[0].stacktrace.frames=t.exception.values[0].stacktrace.frames||[]
var o=isNaN(parseInt(r,10))?void 0:r,i=isNaN(parseInt(n,10))?void 0:n,s=(0,P.HD)(e)&&e.length>0?e:(0,At.l)()
return 0===t.exception.values[0].stacktrace.frames.length&&t.exception.values[0].stacktrace.frames.push({colno:o,filename:s,function:"?",in_app:!0,lineno:i}),t},t.id="GlobalHandlers",t}(),qt=function(){function t(e){void 0===e&&(e={}),this.name=t.id,this._key=e.key||"cause",this._limit=e.limit||5}return t.prototype.setupOnce=function(){(0,u.c)((function(e,n){var r=(0,l.Gd)().getIntegration(t)
if(r){var o=r._handler&&r._handler.bind(r)
return"function"==typeof o?o(e,n):e}return e}))},t.prototype._handler=function(t,e){if(!(t.exception&&t.exception.values&&e&&(0,P.V9)(e.originalException,Error)))return t
var n=this._walkErrorTree(e.originalException,this._key)
return t.exception.values=(0,c.fl)(n,t.exception.values),t},t.prototype._walkErrorTree=function(t,e,n){if(void 0===n&&(n=[]),!(0,P.V9)(t[e],Error)||n.length+1>=this._limit)return n
var r=nt(X(t[e]))
return this._walkErrorTree(t[e],e,(0,c.fl)([r],n))},t.id="LinkedErrors",t}(),zt=function(){function t(){this.name=t.id}return t.prototype.setupOnce=function(e,n){e((function(e){var r=n().getIntegration(t)
if(r){try{if(r._shouldDropEvent(e,r._previousEvent))return R.k.warn("Event dropped due to being a duplicate of previously captured event."),null}catch(t){return r._previousEvent=e}return r._previousEvent=e}return e}))},t.prototype._shouldDropEvent=function(t,e){return!(!e||!this._isSameMessageEvent(t,e)&&!this._isSameExceptionEvent(t,e))},t.prototype._isSameMessageEvent=function(t,e){var n=t.message,r=e.message
return!(!n&&!r||n&&!r||!n&&r||n!==r||!this._isSameFingerprint(t,e)||!this._isSameStacktrace(t,e))},t.prototype._getFramesFromEvent=function(t){var e=t.exception
if(e)try{return e.values[0].stacktrace.frames}catch(t){return}else if(t.stacktrace)return t.stacktrace.frames},t.prototype._isSameStacktrace=function(t,e){var n=this._getFramesFromEvent(t),r=this._getFramesFromEvent(e)
if(!n&&!r)return!0
if(n&&!r||!n&&r)return!1
if(n=n,(r=r).length!==n.length)return!1
for(var o=0;o<r.length;o++){var i=r[o],s=n[o]
if(i.filename!==s.filename||i.lineno!==s.lineno||i.colno!==s.colno||i.function!==s.function)return!1}return!0},t.prototype._getExceptionFromEvent=function(t){return t.exception&&t.exception.values&&t.exception.values[0]},t.prototype._isSameExceptionEvent=function(t,e){var n=this._getExceptionFromEvent(e),r=this._getExceptionFromEvent(t)
return!!(n&&r&&n.type===r.type&&n.value===r.value&&this._isSameFingerprint(t,e)&&this._isSameStacktrace(t,e))},t.prototype._isSameFingerprint=function(t,e){var n=t.fingerprint,r=e.fingerprint
if(!n&&!r)return!0
if(n&&!r||!n&&r)return!1
n=n,r=r
try{return!(n.join("")!==r.join(""))}catch(t){return!1}},t.id="Dedupe",t}(),Zt=(0,H.R)(),Vt=function(){function t(){this.name=t.id}return t.prototype.setupOnce=function(){(0,u.c)((function(e){var n,r,o
if((0,l.Gd)().getIntegration(t)){if(!Zt.navigator&&!Zt.location&&!Zt.document)return e
var i=(null===(n=e.request)||void 0===n?void 0:n.url)||(null===(r=Zt.location)||void 0===r?void 0:r.href),s=(Zt.document||{}).referrer,a=(Zt.navigator||{}).userAgent,u=(0,c.pi)((0,c.pi)((0,c.pi)({},null===(o=e.request)||void 0===o?void 0:o.headers),s&&{Referer:s}),a&&{"User-Agent":a}),p=(0,c.pi)((0,c.pi)({},i&&{url:i}),{headers:u})
return(0,c.pi)((0,c.pi)({},e),{request:p})}return e}))},t.id="UserAgent",t}(),Gt=[new Nt,new Ft,new Ht,new Lt,new Bt,new qt,new zt,new Vt]
function Jt(t){if(void 0===t&&(t={}),void 0===t.defaultIntegrations&&(t.defaultIntegrations=Gt),void 0===t.release){var e=(0,H.R)()
e.SENTRY_RELEASE&&e.SENTRY_RELEASE.id&&(t.release=e.SENTRY_RELEASE.id)}void 0===t.autoSessionTracking&&(t.autoSessionTracking=!0),void 0===t.sendClientReports&&(t.sendClientReports=!0),function(t,e){var n
!0===e.debug&&R.k.enable()
var r=(0,l.Gd)()
null===(n=r.getScope())||void 0===n||n.update(e.initialScope)
var o=new t(e)
r.bindClient(o)}(Mt,t),t.autoSessionTracking&&function(){if(void 0!==(0,H.R)().document){var t=(0,l.Gd)()
"function"==typeof t.startSession&&"function"==typeof t.captureSession&&(t.startSession({ignoreDuration:!0}),t.captureSession(),(0,Dt.o)({callback:function(e){var n=e.from,r=e.to
void 0!==n&&n!==r&&(t.startSession({ignoreDuration:!0}),t.captureSession())},type:"history"}))}else R.k.warn("Session tracking in non-browser environment with @sentry/browser is not supported.")}()}function $t(t){void 0===t&&(t={})
var e=(0,l.Gd)(),n=e.getScope()
n&&(t.user=(0,c.pi)((0,c.pi)({},n.getUser()),t.user)),t.eventId||(t.eventId=e.lastEventId())
var r=e.getClient()
r&&r.showReportDialog(t)}function Yt(){return(0,l.Gd)().lastEventId()}function Kt(){}function Xt(t){t()}function Qt(t){var e=(0,l.Gd)().getClient()
return e?e.flush(t):(R.k.warn("Cannot flush events. No client defined."),D.c.resolve(!1))}function te(t){var e=(0,l.Gd)().getClient()
return e?e.close(t):(R.k.warn("Cannot flush events and disable SDK. No client defined."),D.c.resolve(!1))}function ee(t){return jt(t)()}var ne="sentry.javascript.browser",re={},oe=(0,H.R)()
oe.Sentry&&oe.Sentry.Integrations&&(re=oe.Sentry.Integrations)
var ie=(0,c.pi)((0,c.pi)((0,c.pi)({},re),r),o)},6599:(t,e,n)=>{"use strict"
n.d(e,{Xb:()=>h,Gd:()=>m,vi:()=>g,cu:()=>d,pj:()=>v})
var r=n(7480),o=n(9531),i=n(6438),s=n(8505),a=n(190),c=n(4387),u=n(8029),l=n(1911),p=n(7927),f=function(){function t(t){this.errors=0,this.sid=(0,i.DM)(),this.duration=0,this.status=o.$.Ok,this.init=!0,this.ignoreDuration=!1
var e=(0,s.ph)()
this.timestamp=e,this.started=e,t&&this.update(t)}return t.prototype.update=function(t){if(void 0===t&&(t={}),t.user&&(!this.ipAddress&&t.user.ip_address&&(this.ipAddress=t.user.ip_address),this.did||t.did||(this.did=t.user.id||t.user.email||t.user.username)),this.timestamp=t.timestamp||(0,s.ph)(),t.ignoreDuration&&(this.ignoreDuration=t.ignoreDuration),t.sid&&(this.sid=32===t.sid.length?t.sid:(0,i.DM)()),void 0!==t.init&&(this.init=t.init),!this.did&&t.did&&(this.did=""+t.did),"number"==typeof t.started&&(this.started=t.started),this.ignoreDuration)this.duration=void 0
else if("number"==typeof t.duration)this.duration=t.duration
else{var e=this.timestamp-this.started
this.duration=e>=0?e:0}t.release&&(this.release=t.release),t.environment&&(this.environment=t.environment),!this.ipAddress&&t.ipAddress&&(this.ipAddress=t.ipAddress),!this.userAgent&&t.userAgent&&(this.userAgent=t.userAgent),"number"==typeof t.errors&&(this.errors=t.errors),t.status&&(this.status=t.status)},t.prototype.close=function(t){t?this.update({status:t}):this.status===o.$.Ok?this.update({status:o.$.Exited}):this.update()},t.prototype.toJSON=function(){return(0,p.Jr)({sid:""+this.sid,init:this.init,started:new Date(1e3*this.started).toISOString(),timestamp:new Date(1e3*this.timestamp).toISOString(),status:this.status,errors:this.errors,did:"number"==typeof this.did||"string"==typeof this.did?""+this.did:void 0,duration:this.duration,attrs:(0,p.Jr)({release:this.release,environment:this.environment,ip_address:this.ipAddress,user_agent:this.userAgent})})},t}(),h=function(){function t(t,e,n){void 0===e&&(e=new l.s),void 0===n&&(n=4),this._version=n,this._stack=[{}],this.getStackTop().scope=e,t&&this.bindClient(t)}return t.prototype.isOlderThan=function(t){return this._version<t},t.prototype.bindClient=function(t){this.getStackTop().client=t,t&&t.setupIntegrations&&t.setupIntegrations()},t.prototype.pushScope=function(){var t=l.s.clone(this.getScope())
return this.getStack().push({client:this.getClient(),scope:t}),t},t.prototype.popScope=function(){return!(this.getStack().length<=1||!this.getStack().pop())},t.prototype.withScope=function(t){var e=this.pushScope()
try{t(e)}finally{this.popScope()}},t.prototype.getClient=function(){return this.getStackTop().client},t.prototype.getScope=function(){return this.getStackTop().scope},t.prototype.getStack=function(){return this._stack},t.prototype.getStackTop=function(){return this._stack[this._stack.length-1]},t.prototype.captureException=function(t,e){var n=this._lastEventId=(0,i.DM)(),o=e
if(!e){var s=void 0
try{throw new Error("Sentry syntheticException")}catch(t){s=t}o={originalException:t,syntheticException:s}}return this._invokeClient("captureException",t,(0,r.pi)((0,r.pi)({},o),{event_id:n})),n},t.prototype.captureMessage=function(t,e,n){var o=this._lastEventId=(0,i.DM)(),s=n
if(!n){var a=void 0
try{throw new Error(t)}catch(t){a=t}s={originalException:t,syntheticException:a}}return this._invokeClient("captureMessage",t,e,(0,r.pi)((0,r.pi)({},s),{event_id:o})),o},t.prototype.captureEvent=function(t,e){var n=(0,i.DM)()
return"transaction"!==t.type&&(this._lastEventId=n),this._invokeClient("captureEvent",t,(0,r.pi)((0,r.pi)({},e),{event_id:n})),n},t.prototype.lastEventId=function(){return this._lastEventId},t.prototype.addBreadcrumb=function(t,e){var n=this.getStackTop(),o=n.scope,i=n.client
if(o&&i){var c=i.getOptions&&i.getOptions()||{},u=c.beforeBreadcrumb,l=void 0===u?null:u,p=c.maxBreadcrumbs,f=void 0===p?100:p
if(!(f<=0)){var h=(0,s.yW)(),d=(0,r.pi)({timestamp:h},t),v=l?(0,a.C)((function(){return l(d,e)})):d
null!==v&&o.addBreadcrumb(v,f)}}},t.prototype.setUser=function(t){var e=this.getScope()
e&&e.setUser(t)},t.prototype.setTags=function(t){var e=this.getScope()
e&&e.setTags(t)},t.prototype.setExtras=function(t){var e=this.getScope()
e&&e.setExtras(t)},t.prototype.setTag=function(t,e){var n=this.getScope()
n&&n.setTag(t,e)},t.prototype.setExtra=function(t,e){var n=this.getScope()
n&&n.setExtra(t,e)},t.prototype.setContext=function(t,e){var n=this.getScope()
n&&n.setContext(t,e)},t.prototype.configureScope=function(t){var e=this.getStackTop(),n=e.scope,r=e.client
n&&r&&t(n)},t.prototype.run=function(t){var e=v(this)
try{t(this)}finally{v(e)}},t.prototype.getIntegration=function(t){var e=this.getClient()
if(!e)return null
try{return e.getIntegration(t)}catch(e){return a.k.warn("Cannot retrieve integration "+t.id+" from the current Hub"),null}},t.prototype.startSpan=function(t){return this._callExtensionMethod("startSpan",t)},t.prototype.startTransaction=function(t,e){return this._callExtensionMethod("startTransaction",t,e)},t.prototype.traceHeaders=function(){return this._callExtensionMethod("traceHeaders")},t.prototype.captureSession=function(t){if(void 0===t&&(t=!1),t)return this.endSession()
this._sendSessionUpdate()},t.prototype.endSession=function(){var t,e,n,r,o
null===(n=null===(e=null===(t=this.getStackTop())||void 0===t?void 0:t.scope)||void 0===e?void 0:e.getSession())||void 0===n||n.close(),this._sendSessionUpdate(),null===(o=null===(r=this.getStackTop())||void 0===r?void 0:r.scope)||void 0===o||o.setSession()},t.prototype.startSession=function(t){var e=this.getStackTop(),n=e.scope,i=e.client,s=i&&i.getOptions()||{},a=s.release,u=s.environment,l=((0,c.R)().navigator||{}).userAgent,p=new f((0,r.pi)((0,r.pi)((0,r.pi)({release:a,environment:u},n&&{user:n.getUser()}),l&&{userAgent:l}),t))
if(n){var h=n.getSession&&n.getSession()
h&&h.status===o.$.Ok&&h.update({status:o.$.Exited}),this.endSession(),n.setSession(p)}return p},t.prototype._sendSessionUpdate=function(){var t=this.getStackTop(),e=t.scope,n=t.client
if(e){var r=e.getSession&&e.getSession()
r&&n&&n.captureSession&&n.captureSession(r)}},t.prototype._invokeClient=function(t){for(var e,n=[],o=1;o<arguments.length;o++)n[o-1]=arguments[o]
var i=this.getStackTop(),s=i.scope,a=i.client
a&&a[t]&&(e=a)[t].apply(e,(0,r.fl)(n,[s]))},t.prototype._callExtensionMethod=function(t){for(var e=[],n=1;n<arguments.length;n++)e[n-1]=arguments[n]
var r=d(),o=r.__SENTRY__
if(o&&o.extensions&&"function"==typeof o.extensions[t])return o.extensions[t].apply(this,e)
a.k.warn("Extension method "+t+" couldn't be found, doing nothing.")},t}()
function d(){var t=(0,c.R)()
return t.__SENTRY__=t.__SENTRY__||{extensions:{},hub:void 0},t}function v(t){var e=d(),n=g(e)
return y(e,t),n}function m(){var t=d()
return _(t)&&!g(t).isOlderThan(4)||y(t,new h),(0,u.KV)()?function(t){var e,n,r
try{var o=null===(r=null===(n=null===(e=d().__SENTRY__)||void 0===e?void 0:e.extensions)||void 0===n?void 0:n.domain)||void 0===r?void 0:r.active
if(!o)return g(t)
if(!_(o)||g(o).isOlderThan(4)){var i=g(t).getStackTop()
y(o,new h(i.client,l.s.clone(i.scope)))}return g(o)}catch(e){return g(t)}}(t):g(t)}function _(t){return!!(t&&t.__SENTRY__&&t.__SENTRY__.hub)}function g(t){return t&&t.__SENTRY__&&t.__SENTRY__.hub||(t.__SENTRY__=t.__SENTRY__||{},t.__SENTRY__.hub=new h),t.__SENTRY__.hub}function y(t,e){return!!t&&(t.__SENTRY__=t.__SENTRY__||{},t.__SENTRY__.hub=e,!0)}},1911:(t,e,n)=>{"use strict"
n.d(e,{s:()=>c,c:()=>l})
var r=n(7480),o=n(8146),i=n(8505),s=n(6612),a=n(4387),c=function(){function t(){this._notifyingListeners=!1,this._scopeListeners=[],this._eventProcessors=[],this._breadcrumbs=[],this._user={},this._tags={},this._extra={},this._contexts={}}return t.clone=function(e){var n=new t
return e&&(n._breadcrumbs=(0,r.fl)(e._breadcrumbs),n._tags=(0,r.pi)({},e._tags),n._extra=(0,r.pi)({},e._extra),n._contexts=(0,r.pi)({},e._contexts),n._user=e._user,n._level=e._level,n._span=e._span,n._session=e._session,n._transactionName=e._transactionName,n._fingerprint=e._fingerprint,n._eventProcessors=(0,r.fl)(e._eventProcessors),n._requestSession=e._requestSession),n},t.prototype.addScopeListener=function(t){this._scopeListeners.push(t)},t.prototype.addEventProcessor=function(t){return this._eventProcessors.push(t),this},t.prototype.setUser=function(t){return this._user=t||{},this._session&&this._session.update({user:t}),this._notifyScopeListeners(),this},t.prototype.getUser=function(){return this._user},t.prototype.getRequestSession=function(){return this._requestSession},t.prototype.setRequestSession=function(t){return this._requestSession=t,this},t.prototype.setTags=function(t){return this._tags=(0,r.pi)((0,r.pi)({},this._tags),t),this._notifyScopeListeners(),this},t.prototype.setTag=function(t,e){var n
return this._tags=(0,r.pi)((0,r.pi)({},this._tags),((n={})[t]=e,n)),this._notifyScopeListeners(),this},t.prototype.setExtras=function(t){return this._extra=(0,r.pi)((0,r.pi)({},this._extra),t),this._notifyScopeListeners(),this},t.prototype.setExtra=function(t,e){var n
return this._extra=(0,r.pi)((0,r.pi)({},this._extra),((n={})[t]=e,n)),this._notifyScopeListeners(),this},t.prototype.setFingerprint=function(t){return this._fingerprint=t,this._notifyScopeListeners(),this},t.prototype.setLevel=function(t){return this._level=t,this._notifyScopeListeners(),this},t.prototype.setTransactionName=function(t){return this._transactionName=t,this._notifyScopeListeners(),this},t.prototype.setTransaction=function(t){return this.setTransactionName(t)},t.prototype.setContext=function(t,e){var n
return null===e?delete this._contexts[t]:this._contexts=(0,r.pi)((0,r.pi)({},this._contexts),((n={})[t]=e,n)),this._notifyScopeListeners(),this},t.prototype.setSpan=function(t){return this._span=t,this._notifyScopeListeners(),this},t.prototype.getSpan=function(){return this._span},t.prototype.getTransaction=function(){var t,e,n,r,o=this.getSpan()
return(null===(t=o)||void 0===t?void 0:t.transaction)?null===(e=o)||void 0===e?void 0:e.transaction:(null===(r=null===(n=o)||void 0===n?void 0:n.spanRecorder)||void 0===r?void 0:r.spans[0])?o.spanRecorder.spans[0]:void 0},t.prototype.setSession=function(t){return t?this._session=t:delete this._session,this._notifyScopeListeners(),this},t.prototype.getSession=function(){return this._session},t.prototype.update=function(e){if(!e)return this
if("function"==typeof e){var n=e(this)
return n instanceof t?n:this}return e instanceof t?(this._tags=(0,r.pi)((0,r.pi)({},this._tags),e._tags),this._extra=(0,r.pi)((0,r.pi)({},this._extra),e._extra),this._contexts=(0,r.pi)((0,r.pi)({},this._contexts),e._contexts),e._user&&Object.keys(e._user).length&&(this._user=e._user),e._level&&(this._level=e._level),e._fingerprint&&(this._fingerprint=e._fingerprint),e._requestSession&&(this._requestSession=e._requestSession)):(0,o.PO)(e)&&(e=e,this._tags=(0,r.pi)((0,r.pi)({},this._tags),e.tags),this._extra=(0,r.pi)((0,r.pi)({},this._extra),e.extra),this._contexts=(0,r.pi)((0,r.pi)({},this._contexts),e.contexts),e.user&&(this._user=e.user),e.level&&(this._level=e.level),e.fingerprint&&(this._fingerprint=e.fingerprint),e.requestSession&&(this._requestSession=e.requestSession)),this},t.prototype.clear=function(){return this._breadcrumbs=[],this._tags={},this._extra={},this._user={},this._contexts={},this._level=void 0,this._transactionName=void 0,this._fingerprint=void 0,this._requestSession=void 0,this._span=void 0,this._session=void 0,this._notifyScopeListeners(),this},t.prototype.addBreadcrumb=function(t,e){var n="number"==typeof e?Math.min(e,100):100
if(n<=0)return this
var o=(0,r.pi)({timestamp:(0,i.yW)()},t)
return this._breadcrumbs=(0,r.fl)(this._breadcrumbs,[o]).slice(-n),this._notifyScopeListeners(),this},t.prototype.clearBreadcrumbs=function(){return this._breadcrumbs=[],this._notifyScopeListeners(),this},t.prototype.applyToEvent=function(t,e){var n
if(this._extra&&Object.keys(this._extra).length&&(t.extra=(0,r.pi)((0,r.pi)({},this._extra),t.extra)),this._tags&&Object.keys(this._tags).length&&(t.tags=(0,r.pi)((0,r.pi)({},this._tags),t.tags)),this._user&&Object.keys(this._user).length&&(t.user=(0,r.pi)((0,r.pi)({},this._user),t.user)),this._contexts&&Object.keys(this._contexts).length&&(t.contexts=(0,r.pi)((0,r.pi)({},this._contexts),t.contexts)),this._level&&(t.level=this._level),this._transactionName&&(t.transaction=this._transactionName),this._span){t.contexts=(0,r.pi)({trace:this._span.getTraceContext()},t.contexts)
var o=null===(n=this._span.transaction)||void 0===n?void 0:n.name
o&&(t.tags=(0,r.pi)({transaction:o},t.tags))}return this._applyFingerprint(t),t.breadcrumbs=(0,r.fl)(t.breadcrumbs||[],this._breadcrumbs),t.breadcrumbs=t.breadcrumbs.length>0?t.breadcrumbs:void 0,this._notifyEventProcessors((0,r.fl)(u(),this._eventProcessors),t,e)},t.prototype._notifyEventProcessors=function(t,e,n,i){var a=this
return void 0===i&&(i=0),new s.c((function(s,c){var u=t[i]
if(null===e||"function"!=typeof u)s(e)
else{var l=u((0,r.pi)({},e),n);(0,o.J8)(l)?l.then((function(e){return a._notifyEventProcessors(t,e,n,i+1).then(s)})).then(null,c):a._notifyEventProcessors(t,l,n,i+1).then(s).then(null,c)}}))},t.prototype._notifyScopeListeners=function(){var t=this
this._notifyingListeners||(this._notifyingListeners=!0,this._scopeListeners.forEach((function(e){e(t)})),this._notifyingListeners=!1)},t.prototype._applyFingerprint=function(t){t.fingerprint=t.fingerprint?Array.isArray(t.fingerprint)?t.fingerprint:[t.fingerprint]:[],this._fingerprint&&(t.fingerprint=t.fingerprint.concat(this._fingerprint)),t.fingerprint&&!t.fingerprint.length&&delete t.fingerprint},t}()
function u(){var t=(0,a.R)()
return t.__SENTRY__=t.__SENTRY__||{},t.__SENTRY__.globalEventProcessors=t.__SENTRY__.globalEventProcessors||[],t.__SENTRY__.globalEventProcessors}function l(t){u().push(t)}},9531:(t,e,n)=>{"use strict"
var r,o
n.d(e,{$:()=>r}),function(t){t.Ok="ok",t.Exited="exited",t.Crashed="crashed",t.Abnormal="abnormal"}(r||(r={})),function(t){t.Ok="ok",t.Errored="errored",t.Crashed="crashed"}(o||(o={}))},2967:(t,e,n)=>{"use strict"
var r
n.d(e,{k:()=>r}),function(t){t.BeforeSend="before_send",t.EventProcessor="event_processor",t.NetworkError="network_error",t.QueueOverflow="queue_overflow",t.RateLimitBackoff="ratelimit_backoff",t.SampleRate="sample_rate"}(r||(r={}))},6995:(t,e,n)=>{"use strict"
function r(t){t.then(null,(function(t){console.error(t)}))}n.d(e,{I:()=>r})},7809:(t,e,n)=>{"use strict"
n.d(e,{R:()=>i,l:()=>a})
var r=n(4387),o=n(8146)
function i(t,e){try{for(var n=t,r=[],o=0,i=0,a=" > ".length,c=void 0;n&&o++<5&&!("html"===(c=s(n,e))||o>1&&i+r.length*a+c.length>=80);)r.push(c),i+=c.length,n=n.parentNode
return r.reverse().join(" > ")}catch(t){return"<unknown>"}}function s(t,e){var n,r,i,s,a,c,u,l=t,p=[]
if(!l||!l.tagName)return""
p.push(l.tagName.toLowerCase())
var f=(null===(n=e)||void 0===n?void 0:n.length)?e.filter((function(t){return l.getAttribute(t)})).map((function(t){return[t,l.getAttribute(t)]})):null
if(null===(r=f)||void 0===r?void 0:r.length)f.forEach((function(t){p.push("["+t[0]+'="'+t[1]+'"]')}))
else if(l.id&&p.push("#"+l.id),(i=l.className)&&(0,o.HD)(i))for(s=i.split(/\s+/),u=0;u<s.length;u++)p.push("."+s[u])
var h=["type","name","title","alt"]
for(u=0;u<h.length;u++)a=h[u],(c=l.getAttribute(a))&&p.push("["+a+'="'+c+'"]')
return p.join("")}function a(){var t=(0,r.R)()
try{return t.document.location.href}catch(t){return""}}},84:(t,e,n)=>{"use strict"
n.d(e,{l:()=>s})
var r=n(7480),o=n(6589),i=/^(?:(\w+):)\/\/(?:(\w+)(?::(\w+))?@)([\w.-]+)(?::(\d+))?\/(.+)/,s=function(){function t(t){"string"==typeof t?this._fromString(t):this._fromComponents(t),this._validate()}return t.prototype.toString=function(t){void 0===t&&(t=!1)
var e=this,n=e.host,r=e.path,o=e.pass,i=e.port,s=e.projectId
return e.protocol+"://"+e.publicKey+(t&&o?":"+o:"")+"@"+n+(i?":"+i:"")+"/"+(r?r+"/":r)+s},t.prototype._fromString=function(t){var e=i.exec(t)
if(!e)throw new o.b("Invalid Dsn")
var n=(0,r.CR)(e.slice(1),6),s=n[0],a=n[1],c=n[2],u=void 0===c?"":c,l=n[3],p=n[4],f=void 0===p?"":p,h="",d=n[5],v=d.split("/")
if(v.length>1&&(h=v.slice(0,-1).join("/"),d=v.pop()),d){var m=d.match(/^\d+/)
m&&(d=m[0])}this._fromComponents({host:l,pass:u,path:h,projectId:d,port:f,protocol:s,publicKey:a})},t.prototype._fromComponents=function(t){"user"in t&&!("publicKey"in t)&&(t.publicKey=t.user),this.user=t.publicKey||"",this.protocol=t.protocol,this.publicKey=t.publicKey||"",this.pass=t.pass||"",this.host=t.host,this.port=t.port||"",this.path=t.path||"",this.projectId=t.projectId},t.prototype._validate=function(){var t=this
if(["protocol","publicKey","host","projectId"].forEach((function(e){if(!t[e])throw new o.b("Invalid Dsn: "+e+" missing")})),!this.projectId.match(/^\d+$/))throw new o.b("Invalid Dsn: Invalid projectId "+this.projectId)
if("http"!==this.protocol&&"https"!==this.protocol)throw new o.b("Invalid Dsn: Invalid protocol "+this.protocol)
if(this.port&&isNaN(parseInt(this.port,10)))throw new o.b("Invalid Dsn: Invalid port "+this.port)},t}()},6589:(t,e,n)=>{"use strict"
n.d(e,{b:()=>i})
var r=n(7480),o=Object.setPrototypeOf||({__proto__:[]}instanceof Array?function(t,e){return t.__proto__=e,t}:function(t,e){for(var n in e)Object.prototype.hasOwnProperty.call(t,n)||(t[n]=e[n])
return t}),i=function(t){function e(e){var n=this.constructor,r=t.call(this,e)||this
return r.message=e,r.name=n.prototype.constructor.name,o(r,n.prototype),r}return(0,r.ZT)(e,t),e}(Error)},4387:(t,e,n)=>{"use strict"
n.d(e,{R:()=>i})
var r=n(8029),o={}
function i(){return(0,r.KV)()?n.g:"undefined"!=typeof window?window:"undefined"!=typeof self?self:o}},4245:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{Dsn:()=>i.l,Memo:()=>p._,PromiseBuffer:()=>k.D,SentryError:()=>s.b,SyncPromise:()=>R.c,_browserPerformanceTimeOriginMode:()=>P.mL,addContextToFrame:()=>f.go,addExceptionMechanism:()=>f.EG,addExceptionTypeValue:()=>f.Db,addInstrumentationHandler:()=>c.o,basename:()=>O,browserPerformanceTimeOrigin:()=>P.Z1,checkOrSetAlreadyCaught:()=>f.YO,consoleSandbox:()=>l.C,dateTimestampInSeconds:()=>P.yW,dirname:()=>x,dropUndefinedKeys:()=>d.Jr,dynamicRequire:()=>h.l$,escapeStringForRegex:()=>C.GE,extractExceptionKeysForMessage:()=>d.zf,fill:()=>d.hl,forget:()=>r.I,getEventDescription:()=>f.jH,getFunctionName:()=>T.$,getGlobalObject:()=>a.R,getLocationHref:()=>o.l,htmlTreeAsString:()=>o.R,isAbsolute:()=>E,isDOMError:()=>u.TX,isDOMException:()=>u.fm,isElement:()=>u.kK,isError:()=>u.VZ,isErrorEvent:()=>u.VW,isEvent:()=>u.cO,isInstanceOf:()=>u.V9,isMatchingPattern:()=>C.zC,isNativeFetch:()=>j.Du,isNodeEnv:()=>h.KV,isPlainObject:()=>u.PO,isPrimitive:()=>u.pt,isRegExp:()=>u.Kj,isString:()=>u.HD,isSyntheticEvent:()=>u.Cy,isThenable:()=>u.J8,join:()=>S,loadModule:()=>h.$y,logger:()=>l.k,normalize:()=>d.Fv,normalizePath:()=>w,normalizeToSize:()=>d.Qy,objectify:()=>d.mz,parseRetryAfterHeader:()=>f.JY,parseSemver:()=>f.J4,parseUrl:()=>f.en,relative:()=>b,resolve:()=>g,safeJoin:()=>C.nK,snipLine:()=>C.JM,stripUrlQueryAndFragment:()=>f.rt,supportsDOMError:()=>j.zO,supportsDOMException:()=>j.fL,supportsErrorEvent:()=>j.S$,supportsFetch:()=>j.Ak,supportsHistory:()=>j.Bf,supportsNativeFetch:()=>j.t$,supportsReferrerPolicy:()=>j.hv,supportsReportingObserver:()=>j.zb,timestampInSeconds:()=>P.ph,timestampWithMs:()=>P._I,truncate:()=>C.$G,urlEncode:()=>d._j,usingPerformanceAPI:()=>P.sV,uuid4:()=>f.DM,walk:()=>d._p})
var r=n(6995),o=n(7809),i=n(84),s=n(6589),a=n(4387),c=n(5670),u=n(8146),l=n(190),p=n(6082),f=n(6438),h=n(8029),d=n(7927)
function v(t,e){for(var n=0,r=t.length-1;r>=0;r--){var o=t[r]
"."===o?t.splice(r,1):".."===o?(t.splice(r,1),n++):n&&(t.splice(r,1),n--)}if(e)for(;n--;n)t.unshift("..")
return t}var m=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^/]+?|)(\.[^./]*|))(?:[/]*)$/
function _(t){var e=m.exec(t)
return e?e.slice(1):[]}function g(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e]
for(var n="",r=!1,o=t.length-1;o>=-1&&!r;o--){var i=o>=0?t[o]:"/"
i&&(n=i+"/"+n,r="/"===i.charAt(0))}return(r?"/":"")+(n=v(n.split("/").filter((function(t){return!!t})),!r).join("/"))||"."}function y(t){for(var e=0;e<t.length&&""===t[e];e++);for(var n=t.length-1;n>=0&&""===t[n];n--);return e>n?[]:t.slice(e,n-e+1)}function b(t,e){t=g(t).substr(1),e=g(e).substr(1)
for(var n=y(t.split("/")),r=y(e.split("/")),o=Math.min(n.length,r.length),i=o,s=0;s<o;s++)if(n[s]!==r[s]){i=s
break}var a=[]
for(s=i;s<n.length;s++)a.push("..")
return(a=a.concat(r.slice(i))).join("/")}function w(t){var e=E(t),n="/"===t.substr(-1),r=v(t.split("/").filter((function(t){return!!t})),!e).join("/")
return r||e||(r="."),r&&n&&(r+="/"),(e?"/":"")+r}function E(t){return"/"===t.charAt(0)}function S(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e]
return w(t.join("/"))}function x(t){var e=_(t),n=e[0],r=e[1]
return n||r?(r&&(r=r.substr(0,r.length-1)),n+r):"."}function O(t,e){var n=_(t)[2]
return e&&n.substr(-1*e.length)===e&&(n=n.substr(0,n.length-e.length)),n}var k=n(5473),T=n(7879),C=n(9399),j=n(2651),R=n(6612),P=n(8505)},5670:(t,e,n)=>{"use strict"
n.d(e,{o:()=>m})
var r,o,i,s=n(7480),a=n(4387),c=n(8146),u=n(190),l=n(7927),p=n(7879),f=n(2651),h=(0,a.R)(),d={},v={}
function m(t){t&&"string"==typeof t.type&&"function"==typeof t.callback&&(d[t.type]=d[t.type]||[],d[t.type].push(t.callback),function(t){if(!v[t])switch(v[t]=!0,t){case"console":"console"in h&&["debug","info","warn","error","log","assert"].forEach((function(t){t in h.console&&(0,l.hl)(h.console,t,(function(e){return function(){for(var n=[],r=0;r<arguments.length;r++)n[r]=arguments[r]
_("console",{args:n,level:t}),e&&Function.prototype.apply.call(e,h.console,n)}}))}))
break
case"dom":!function(){if("document"in h){var t=_.bind(null,"dom"),e=b(t,!0)
h.document.addEventListener("click",e,!1),h.document.addEventListener("keypress",e,!1),["EventTarget","Node"].forEach((function(e){var n=h[e]&&h[e].prototype
n&&n.hasOwnProperty&&n.hasOwnProperty("addEventListener")&&((0,l.hl)(n,"addEventListener",(function(e){return function(n,r,o){if("click"===n||"keypress"==n)try{var i=this.__sentry_instrumentation_handlers__=this.__sentry_instrumentation_handlers__||{},s=i[n]=i[n]||{refCount:0}
if(!s.handler){var a=b(t)
s.handler=a,e.call(this,n,a,o)}s.refCount+=1}catch(t){}return e.call(this,n,r,o)}})),(0,l.hl)(n,"removeEventListener",(function(t){return function(e,n,r){if("click"===e||"keypress"==e)try{var o=this.__sentry_instrumentation_handlers__||{},i=o[e]
i&&(i.refCount-=1,i.refCount<=0&&(t.call(this,e,i.handler,r),i.handler=void 0,delete o[e]),0===Object.keys(o).length&&delete this.__sentry_instrumentation_handlers__)}catch(t){}return t.call(this,e,n,r)}})))}))}}()
break
case"xhr":!function(){if("XMLHttpRequest"in h){var t=[],e=[],n=XMLHttpRequest.prototype;(0,l.hl)(n,"open",(function(n){return function(){for(var r=[],o=0;o<arguments.length;o++)r[o]=arguments[o]
var i=this,s=r[1]
i.__sentry_xhr__={method:(0,c.HD)(r[0])?r[0].toUpperCase():r[0],url:r[1]},(0,c.HD)(s)&&"POST"===i.__sentry_xhr__.method&&s.match(/sentry_key/)&&(i.__sentry_own_request__=!0)
var a=function(){if(4===i.readyState){try{i.__sentry_xhr__&&(i.__sentry_xhr__.status_code=i.status)}catch(t){}try{var n=t.indexOf(i)
if(-1!==n){t.splice(n)
var o=e.splice(n)[0]
i.__sentry_xhr__&&void 0!==o[0]&&(i.__sentry_xhr__.body=o[0])}}catch(t){}_("xhr",{args:r,endTimestamp:Date.now(),startTimestamp:Date.now(),xhr:i})}}
return"onreadystatechange"in i&&"function"==typeof i.onreadystatechange?(0,l.hl)(i,"onreadystatechange",(function(t){return function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
return a(),t.apply(i,e)}})):i.addEventListener("readystatechange",a),n.apply(i,r)}})),(0,l.hl)(n,"send",(function(n){return function(){for(var r=[],o=0;o<arguments.length;o++)r[o]=arguments[o]
return t.push(this),e.push(r),_("xhr",{args:r,startTimestamp:Date.now(),xhr:this}),n.apply(this,r)}}))}}()
break
case"fetch":(0,f.t$)()&&(0,l.hl)(h,"fetch",(function(t){return function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
var r={args:e,fetchData:{method:g(e),url:y(e)},startTimestamp:Date.now()}
return _("fetch",(0,s.pi)({},r)),t.apply(h,e).then((function(t){return _("fetch",(0,s.pi)((0,s.pi)({},r),{endTimestamp:Date.now(),response:t})),t}),(function(t){throw _("fetch",(0,s.pi)((0,s.pi)({},r),{endTimestamp:Date.now(),error:t})),t}))}}))
break
case"history":!function(){if((0,f.Bf)()){var t=h.onpopstate
h.onpopstate=function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
var o=h.location.href,i=r
if(r=o,_("history",{from:i,to:o}),t)try{return t.apply(this,e)}catch(t){}},(0,l.hl)(h.history,"pushState",e),(0,l.hl)(h.history,"replaceState",e)}function e(t){return function(){for(var e=[],n=0;n<arguments.length;n++)e[n]=arguments[n]
var o=e.length>2?e[2]:void 0
if(o){var i=r,s=String(o)
r=s,_("history",{from:i,to:s})}return t.apply(this,e)}}}()
break
case"error":w=h.onerror,h.onerror=function(t,e,n,r,o){return _("error",{column:r,error:o,line:n,msg:t,url:e}),!!w&&w.apply(this,arguments)}
break
case"unhandledrejection":E=h.onunhandledrejection,h.onunhandledrejection=function(t){return _("unhandledrejection",t),!E||E.apply(this,arguments)}
break
default:u.k.warn("unknown instrumentation type:",t)}}(t.type))}function _(t,e){var n,r
if(t&&d[t])try{for(var o=(0,s.XA)(d[t]||[]),i=o.next();!i.done;i=o.next()){var a=i.value
try{a(e)}catch(e){u.k.error("Error while triggering instrumentation handler.\nType: "+t+"\nName: "+(0,p.$)(a)+"\nError: "+e)}}}catch(t){n={error:t}}finally{try{i&&!i.done&&(r=o.return)&&r.call(o)}finally{if(n)throw n.error}}}function g(t){return void 0===t&&(t=[]),"Request"in h&&(0,c.V9)(t[0],Request)&&t[0].method?String(t[0].method).toUpperCase():t[1]&&t[1].method?String(t[1].method).toUpperCase():"GET"}function y(t){return void 0===t&&(t=[]),"string"==typeof t[0]?t[0]:"Request"in h&&(0,c.V9)(t[0],Request)?t[0].url:String(t[0])}function b(t,e){return void 0===e&&(e=!1),function(n){if(n&&i!==n&&!function(t){if("keypress"!==t.type)return!1
try{var e=t.target
if(!e||!e.tagName)return!0
if("INPUT"===e.tagName||"TEXTAREA"===e.tagName||e.isContentEditable)return!1}catch(t){}return!0}(n)){var r="keypress"===n.type?"input":n.type;(void 0===o||function(t,e){if(!t)return!0
if(t.type!==e.type)return!0
try{if(t.target!==e.target)return!0}catch(t){}return!1}(i,n))&&(t({event:n,name:r,global:e}),i=n),clearTimeout(o),o=h.setTimeout((function(){o=void 0}),1e3)}}}var w=null,E=null},8146:(t,e,n)=>{"use strict"
function r(t){switch(Object.prototype.toString.call(t)){case"[object Error]":case"[object Exception]":case"[object DOMException]":return!0
default:return v(t,Error)}}function o(t){return"[object ErrorEvent]"===Object.prototype.toString.call(t)}function i(t){return"[object DOMError]"===Object.prototype.toString.call(t)}function s(t){return"[object DOMException]"===Object.prototype.toString.call(t)}function a(t){return"[object String]"===Object.prototype.toString.call(t)}function c(t){return null===t||"object"!=typeof t&&"function"!=typeof t}function u(t){return"[object Object]"===Object.prototype.toString.call(t)}function l(t){return"undefined"!=typeof Event&&v(t,Event)}function p(t){return"undefined"!=typeof Element&&v(t,Element)}function f(t){return"[object RegExp]"===Object.prototype.toString.call(t)}function h(t){return Boolean(t&&t.then&&"function"==typeof t.then)}function d(t){return u(t)&&"nativeEvent"in t&&"preventDefault"in t&&"stopPropagation"in t}function v(t,e){try{return t instanceof e}catch(t){return!1}}n.d(e,{VZ:()=>r,VW:()=>o,TX:()=>i,fm:()=>s,HD:()=>a,pt:()=>c,PO:()=>u,cO:()=>l,kK:()=>p,Kj:()=>f,J8:()=>h,Cy:()=>d,V9:()=>v})},190:(t,e,n)=>{"use strict"
n.d(e,{C:()=>s,k:()=>c})
var r=n(4387),o=(0,r.R)(),i="Sentry Logger "
function s(t){var e=(0,r.R)()
if(!("console"in e))return t()
var n=e.console,o={};["debug","info","warn","error","log","assert"].forEach((function(t){t in e.console&&n[t].__sentry_original__&&(o[t]=n[t],n[t]=n[t].__sentry_original__)}))
var i=t()
return Object.keys(o).forEach((function(t){n[t]=o[t]})),i}var a=function(){function t(){this._enabled=!1}return t.prototype.disable=function(){this._enabled=!1},t.prototype.enable=function(){this._enabled=!0},t.prototype.log=function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e]
this._enabled&&s((function(){o.console.log(i+"[Log]: "+t.join(" "))}))},t.prototype.warn=function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e]
this._enabled&&s((function(){o.console.warn(i+"[Warn]: "+t.join(" "))}))},t.prototype.error=function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e]
this._enabled&&s((function(){o.console.error(i+"[Error]: "+t.join(" "))}))},t}()
o.__SENTRY__=o.__SENTRY__||{}
var c=o.__SENTRY__.logger||(o.__SENTRY__.logger=new a)},6082:(t,e,n)=>{"use strict"
n.d(e,{_:()=>r})
var r=function(){function t(){this._hasWeakSet="function"==typeof WeakSet,this._inner=this._hasWeakSet?new WeakSet:[]}return t.prototype.memoize=function(t){if(this._hasWeakSet)return!!this._inner.has(t)||(this._inner.add(t),!1)
for(var e=0;e<this._inner.length;e++)if(this._inner[e]===t)return!0
return this._inner.push(t),!1},t.prototype.unmemoize=function(t){if(this._hasWeakSet)this._inner.delete(t)
else for(var e=0;e<this._inner.length;e++)if(this._inner[e]===t){this._inner.splice(e,1)
break}},t}()},6438:(t,e,n)=>{"use strict"
n.d(e,{DM:()=>s,en:()=>a,jH:()=>c,Db:()=>u,EG:()=>l,J4:()=>f,JY:()=>h,go:()=>d,rt:()=>v,YO:()=>m})
var r=n(7480),o=n(4387),i=n(9399)
function s(){var t=(0,o.R)(),e=t.crypto||t.msCrypto
if(void 0!==e&&e.getRandomValues){var n=new Uint16Array(8)
e.getRandomValues(n),n[3]=4095&n[3]|16384,n[4]=16383&n[4]|32768
var r=function(t){for(var e=t.toString(16);e.length<4;)e="0"+e
return e}
return r(n[0])+r(n[1])+r(n[2])+r(n[3])+r(n[4])+r(n[5])+r(n[6])+r(n[7])}return"xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g,(function(t){var e=16*Math.random()|0
return("x"===t?e:3&e|8).toString(16)}))}function a(t){if(!t)return{}
var e=t.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/)
if(!e)return{}
var n=e[6]||"",r=e[8]||""
return{host:e[4],path:e[5],protocol:e[2],relative:e[5]+n+r}}function c(t){if(t.message)return t.message
if(t.exception&&t.exception.values&&t.exception.values[0]){var e=t.exception.values[0]
return e.type&&e.value?e.type+": "+e.value:e.type||e.value||t.event_id||"<unknown>"}return t.event_id||"<unknown>"}function u(t,e,n){t.exception=t.exception||{},t.exception.values=t.exception.values||[],t.exception.values[0]=t.exception.values[0]||{},t.exception.values[0].value=t.exception.values[0].value||e||"",t.exception.values[0].type=t.exception.values[0].type||n||"Error"}function l(t,e){var n
if(t.exception&&t.exception.values){var o=t.exception.values[0],i=o.mechanism
if(o.mechanism=(0,r.pi)((0,r.pi)((0,r.pi)({},{type:"generic",handled:!0}),i),e),e&&"data"in e){var s=(0,r.pi)((0,r.pi)({},null===(n=i)||void 0===n?void 0:n.data),e.data)
o.mechanism.data=s}}}var p=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/
function f(t){var e=t.match(p)||[],n=parseInt(e[1],10),r=parseInt(e[2],10),o=parseInt(e[3],10)
return{buildmetadata:e[5],major:isNaN(n)?void 0:n,minor:isNaN(r)?void 0:r,patch:isNaN(o)?void 0:o,prerelease:e[4]}}function h(t,e){if(!e)return 6e4
var n=parseInt(""+e,10)
if(!isNaN(n))return 1e3*n
var r=Date.parse(""+e)
return isNaN(r)?6e4:r-t}function d(t,e,n){void 0===n&&(n=5)
var r=e.lineno||0,o=t.length,s=Math.max(Math.min(o,r-1),0)
e.pre_context=t.slice(Math.max(0,s-n),s).map((function(t){return(0,i.JM)(t,0)})),e.context_line=(0,i.JM)(t[Math.min(o-1,s)],e.colno||0),e.post_context=t.slice(Math.min(s+1,o),s+1+n).map((function(t){return(0,i.JM)(t,0)}))}function v(t){return t.split(/[\?#]/,1)[0]}function m(t){var e
if(null===(e=t)||void 0===e?void 0:e.__sentry_captured__)return!0
try{Object.defineProperty(t,"__sentry_captured__",{value:!0})}catch(t){}return!1}},8029:(t,e,n)=>{"use strict"
function r(){return"[object process]"===Object.prototype.toString.call("undefined"!=typeof process?process:0)}function o(t,e){return t.require(e)}function i(e){var n
try{n=o(t,e)}catch(t){}try{var r=o(t,"process").cwd
n=o(t,r()+"/node_modules/"+e)}catch(t){}return n}n.d(e,{KV:()=>r,l$:()=>o,$y:()=>i}),t=n.hmd(t)},7927:(t,e,n)=>{"use strict"
n.d(e,{hl:()=>u,_j:()=>l,Qy:()=>f,_p:()=>d,Fv:()=>v,zf:()=>m,Jr:()=>_,mz:()=>g})
var r=n(7480),o=n(7809),i=n(8146),s=n(6082),a=n(7879),c=n(9399)
function u(t,e,n){if(e in t){var r=t[e],o=n(r)
if("function"==typeof o)try{o.prototype=o.prototype||{},Object.defineProperties(o,{__sentry_original__:{enumerable:!1,value:r}})}catch(t){}t[e]=o}}function l(t){return Object.keys(t).map((function(e){return encodeURIComponent(e)+"="+encodeURIComponent(t[e])})).join("&")}function p(t){if((0,i.VZ)(t)){var e=t,n={message:e.message,name:e.name,stack:e.stack}
for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&(n[r]=e[r])
return n}if((0,i.cO)(t)){var s=t,a={}
a.type=s.type
try{a.target=(0,i.kK)(s.target)?(0,o.R)(s.target):Object.prototype.toString.call(s.target)}catch(t){a.target="<unknown>"}try{a.currentTarget=(0,i.kK)(s.currentTarget)?(0,o.R)(s.currentTarget):Object.prototype.toString.call(s.currentTarget)}catch(t){a.currentTarget="<unknown>"}for(var c in"undefined"!=typeof CustomEvent&&(0,i.V9)(t,CustomEvent)&&(a.detail=s.detail),s)Object.prototype.hasOwnProperty.call(s,c)&&(a[c]=s[c])
return a}return t}function f(t,e,n){void 0===e&&(e=3),void 0===n&&(n=102400)
var r,o=v(t,e)
return r=o,function(t){return~-encodeURI(t).split(/%..|./).length}(JSON.stringify(r))>n?f(t,e-1,n):o}function h(t,e){return"domain"===e&&t&&"object"==typeof t&&t._events?"[Domain]":"domainEmitter"===e?"[DomainEmitter]":void 0!==n.g&&t===n.g?"[Global]":"undefined"!=typeof window&&t===window?"[Window]":"undefined"!=typeof document&&t===document?"[Document]":(0,i.Cy)(t)?"[SyntheticEvent]":"number"==typeof t&&t!=t?"[NaN]":void 0===t?"[undefined]":"function"==typeof t?"[Function: "+(0,a.$)(t)+"]":"symbol"==typeof t?"["+String(t)+"]":"bigint"==typeof t?"[BigInt: "+String(t)+"]":t}function d(t,e,n,r){if(void 0===n&&(n=1/0),void 0===r&&(r=new s._),0===n)return function(t){var e=Object.prototype.toString.call(t)
if("string"==typeof t)return t
if("[object Object]"===e)return"[Object]"
if("[object Array]"===e)return"[Array]"
var n=h(t)
return(0,i.pt)(n)?n:e}(e)
if(null!=e&&"function"==typeof e.toJSON)return e.toJSON()
var o=h(e,t)
if((0,i.pt)(o))return o
var a=p(e),c=Array.isArray(e)?[]:{}
if(r.memoize(e))return"[Circular ~]"
for(var u in a)Object.prototype.hasOwnProperty.call(a,u)&&(c[u]=d(u,a[u],n-1,r))
return r.unmemoize(e),c}function v(t,e){try{return JSON.parse(JSON.stringify(t,(function(t,n){return d(t,n,e)})))}catch(t){return"**non-serializable**"}}function m(t,e){void 0===e&&(e=40)
var n=Object.keys(p(t))
if(n.sort(),!n.length)return"[object has no keys]"
if(n[0].length>=e)return(0,c.$G)(n[0],e)
for(var r=n.length;r>0;r--){var o=n.slice(0,r).join(", ")
if(!(o.length>e))return r===n.length?o:(0,c.$G)(o,e)}return""}function _(t){var e,n
if((0,i.PO)(t)){var o=t,s={}
try{for(var a=(0,r.XA)(Object.keys(o)),c=a.next();!c.done;c=a.next()){var u=c.value
void 0!==o[u]&&(s[u]=_(o[u]))}}catch(t){e={error:t}}finally{try{c&&!c.done&&(n=a.return)&&n.call(a)}finally{if(e)throw e.error}}return s}return Array.isArray(t)?t.map(_):t}function g(t){var e
switch(!0){case null==t:e=new String(t)
break
case"symbol"==typeof t||"bigint"==typeof t:e=Object(t)
break
case(0,i.pt)(t):e=new t.constructor(t)
break
default:e=t}return e}},5473:(t,e,n)=>{"use strict"
n.d(e,{D:()=>i})
var r=n(6589),o=n(6612),i=function(){function t(t){this._limit=t,this._buffer=[]}return t.prototype.isReady=function(){return void 0===this._limit||this.length()<this._limit},t.prototype.add=function(t){var e=this
if(!this.isReady())return o.c.reject(new r.b("Not adding Promise due to buffer limit reached."))
var n=t()
return-1===this._buffer.indexOf(n)&&this._buffer.push(n),n.then((function(){return e.remove(n)})).then(null,(function(){return e.remove(n).then(null,(function(){}))})),n},t.prototype.remove=function(t){return this._buffer.splice(this._buffer.indexOf(t),1)[0]},t.prototype.length=function(){return this._buffer.length},t.prototype.drain=function(t){var e=this
return new o.c((function(n){var r=setTimeout((function(){t&&t>0&&n(!1)}),t)
o.c.all(e._buffer).then((function(){clearTimeout(r),n(!0)})).then(null,(function(){n(!0)}))}))},t}()},7879:(t,e,n)=>{"use strict"
n.d(e,{$:()=>o})
var r="<anonymous>"
function o(t){try{return t&&"function"==typeof t&&t.name||r}catch(t){return r}}},9399:(t,e,n)=>{"use strict"
n.d(e,{$G:()=>o,JM:()=>i,nK:()=>s,zC:()=>a,GE:()=>c})
var r=n(8146)
function o(t,e){return void 0===e&&(e=0),"string"!=typeof t||0===e||t.length<=e?t:t.substr(0,e)+"..."}function i(t,e){var n=t,r=n.length
if(r<=150)return n
e>r&&(e=r)
var o=Math.max(e-60,0)
o<5&&(o=0)
var i=Math.min(o+140,r)
return i>r-5&&(i=r),i===r&&(o=Math.max(i-140,0)),n=n.slice(o,i),o>0&&(n="'{snip} "+n),i<r&&(n+=" {snip}"),n}function s(t,e){if(!Array.isArray(t))return""
for(var n=[],r=0;r<t.length;r++){var o=t[r]
try{n.push(String(o))}catch(t){n.push("[value cannot be serialized]")}}return n.join(e)}function a(t,e){return!!(0,r.HD)(t)&&((0,r.Kj)(e)?e.test(t):"string"==typeof e&&-1!==t.indexOf(e))}function c(t){return t.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d")}},2651:(t,e,n)=>{"use strict"
n.d(e,{S$:()=>i,zO:()=>s,fL:()=>a,Ak:()=>c,Du:()=>u,t$:()=>l,zb:()=>p,hv:()=>f,Bf:()=>h})
var r=n(4387),o=n(190)
function i(){try{return new ErrorEvent(""),!0}catch(t){return!1}}function s(){try{return new DOMError(""),!0}catch(t){return!1}}function a(){try{return new DOMException(""),!0}catch(t){return!1}}function c(){if(!("fetch"in(0,r.R)()))return!1
try{return new Headers,new Request(""),new Response,!0}catch(t){return!1}}function u(t){return t&&/^function fetch\(\)\s+\{\s+\[native code\]\s+\}$/.test(t.toString())}function l(){if(!c())return!1
var t=(0,r.R)()
if(u(t.fetch))return!0
var e=!1,n=t.document
if(n&&"function"==typeof n.createElement)try{var i=n.createElement("iframe")
i.hidden=!0,n.head.appendChild(i),i.contentWindow&&i.contentWindow.fetch&&(e=u(i.contentWindow.fetch)),n.head.removeChild(i)}catch(t){o.k.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ",t)}return e}function p(){return"ReportingObserver"in(0,r.R)()}function f(){if(!c())return!1
try{return new Request("_",{referrerPolicy:"origin"}),!0}catch(t){return!1}}function h(){var t=(0,r.R)(),e=t.chrome,n=e&&e.app&&e.app.runtime,o="history"in t&&!!t.history.pushState&&!!t.history.replaceState
return!n&&o}},6612:(t,e,n)=>{"use strict"
n.d(e,{c:()=>o})
var r=n(8146),o=function(){function t(t){var e=this
this._state="PENDING",this._handlers=[],this._resolve=function(t){e._setResult("RESOLVED",t)},this._reject=function(t){e._setResult("REJECTED",t)},this._setResult=function(t,n){"PENDING"===e._state&&((0,r.J8)(n)?n.then(e._resolve,e._reject):(e._state=t,e._value=n,e._executeHandlers()))},this._attachHandler=function(t){e._handlers=e._handlers.concat(t),e._executeHandlers()},this._executeHandlers=function(){if("PENDING"!==e._state){var t=e._handlers.slice()
e._handlers=[],t.forEach((function(t){t.done||("RESOLVED"===e._state&&t.onfulfilled&&t.onfulfilled(e._value),"REJECTED"===e._state&&t.onrejected&&t.onrejected(e._value),t.done=!0)}))}}
try{t(this._resolve,this._reject)}catch(t){this._reject(t)}}return t.resolve=function(e){return new t((function(t){t(e)}))},t.reject=function(e){return new t((function(t,n){n(e)}))},t.all=function(e){return new t((function(n,r){if(Array.isArray(e))if(0!==e.length){var o=e.length,i=[]
e.forEach((function(e,s){t.resolve(e).then((function(t){i[s]=t,0==(o-=1)&&n(i)})).then(null,r)}))}else n([])
else r(new TypeError("Promise.all requires an array as input."))}))},t.prototype.then=function(e,n){var r=this
return new t((function(t,o){r._attachHandler({done:!1,onfulfilled:function(n){if(e)try{return void t(e(n))}catch(t){return void o(t)}else t(n)},onrejected:function(e){if(n)try{return void t(n(e))}catch(t){return void o(t)}else o(e)}})}))},t.prototype.catch=function(t){return this.then((function(t){return t}),t)},t.prototype.finally=function(e){var n=this
return new t((function(t,r){var o,i
return n.then((function(t){i=!1,o=t,e&&e()}),(function(t){i=!0,o=t,e&&e()})).then((function(){i?r(o):t(o)}))}))},t.prototype.toString=function(){return"[object SyncPromise]"},t}()},8505:(t,e,n)=>{"use strict"
n.d(e,{yW:()=>u,ph:()=>l,_I:()=>p,sV:()=>f,mL:()=>i,Z1:()=>h})
var r=n(4387),o=n(8029)
t=n.hmd(t)
var i,s={nowSeconds:function(){return Date.now()/1e3}},a=(0,o.KV)()?function(){try{return(0,o.l$)(t,"perf_hooks").performance}catch(t){return}}():function(){var t=(0,r.R)().performance
if(t&&t.now)return{now:function(){return t.now()},timeOrigin:Date.now()-t.now()}}(),c=void 0===a?s:{nowSeconds:function(){return(a.timeOrigin+a.now())/1e3}},u=s.nowSeconds.bind(s),l=c.nowSeconds.bind(c),p=l,f=void 0!==a,h=function(){var t=(0,r.R)().performance
if(t&&t.now){var e=36e5,n=t.now(),o=Date.now(),s=t.timeOrigin?Math.abs(t.timeOrigin+n-o):e,a=s<e,c=t.timing&&t.timing.navigationStart,u="number"==typeof c?Math.abs(c+n-o):e
return a||u<e?s<=u?(i="timeOrigin",t.timeOrigin):(i="navigationStart",c):(i="dateNow",o)}i="none"}()},1442:function(t,e,n){"use strict"
var r=this&&this.__importDefault||function(t){return t&&t.__esModule?t:{default:t}}
Object.defineProperty(e,"__esModule",{value:!0}),e.Centrifuge=void 0
const o=n(3979),i=n(7939),s=n(3556),a=n(9291),c=n(7280),u=n(5223),l=n(9428),p=n(680),f=n(1077),h=n(9241),d=r(n(8291)),v={protocol:"json",token:null,getToken:null,data:null,debug:!1,name:"js",version:"",fetch:null,readableStream:null,websocket:null,eventsource:null,sockjs:null,sockjsOptions:{},emulationEndpoint:"/emulation",minReconnectDelay:500,maxReconnectDelay:2e4,timeout:5e3,maxServerPingDelay:1e4}
class m extends d.default{constructor(t,e){super(),this._reconnectTimeout=null,this._refreshTimeout=null,this._serverPingTimeout=null,this.state=h.State.Disconnected,this._endpoint=t,this._emulation=!1,this._transports=[],this._currentTransportIndex=0,this._triedAllTransports=!1,this._transportWasOpen=!1,this._transport=null,this._transportClosed=!0,this._encoder=null,this._decoder=null,this._reconnectTimeout=null,this._reconnectAttempts=0,this._client=null,this._session="",this._node="",this._subs={},this._serverSubs={},this._commandId=0,this._commands=[],this._batching=!1,this._refreshRequired=!1,this._refreshTimeout=null,this._callbacks={},this._token=void 0,this._dispatchPromise=Promise.resolve(),this._serverPing=0,this._serverPingTimeout=null,this._sendPong=!1,this._promises={},this._promiseId=0,this._debugEnabled=!1,this._config=Object.assign(Object.assign({},v),e),this._configure(),this._debugEnabled?(this.on("state",(t=>{this._debug("client state",t.oldState,"->",t.newState)})),this.on("error",(t=>{this._debug("client error",t)}))):this.on("error",(function(){Function.prototype()}))}newSubscription(t,e){if(null!==this.getSubscription(t))throw new Error("Subscription to the channel "+t+" already exists")
const n=new o.Subscription(this,t,e)
return this._subs[t]=n,n}getSubscription(t){return this._getSub(t)}removeSubscription(t){t&&(t.state!==h.SubscriptionState.Unsubscribed&&t.unsubscribe(),this._removeSubscription(t))}subscriptions(){return this._subs}ready(t){return this.state===h.State.Disconnected?Promise.reject({code:i.errorCodes.clientDisconnected,message:"client disconnected"}):this.state===h.State.Connected?Promise.resolve():new Promise(((e,n)=>{const r={resolve:e,reject:n}
t&&(r.timeout=setTimeout((function(){n({code:i.errorCodes.timeout,message:"timeout"})}),t)),this._promises[this._nextPromiseId()]=r}))}connect(){this._isConnected()?this._debug("connect called when already connected"):this._isConnecting()?this._debug("connect called when already connecting"):(this._reconnectAttempts=0,this._startConnecting())}disconnect(){this._disconnect(i.disconnectedCodes.disconnectCalled,"disconnect called",!1)}send(t){const e={send:{data:t}},n=this
return this._methodCall().then((function(){return n._transportSendCommands([e])?Promise.resolve():Promise.reject(n._createErrorObject(i.errorCodes.transportWriteError,"transport write error"))}))}rpc(t,e){const n={rpc:{method:t,data:e}},r=this
return this._methodCall().then((function(){return r._callPromise(n,(function(t){return{data:t.rpc.data}}))}))}publish(t,e){const n={publish:{channel:t,data:e}},r=this
return this._methodCall().then((function(){return r._callPromise(n,(function(){return{}}))}))}history(t,e){const n={history:this._getHistoryRequest(t,e)},r=this
return this._methodCall().then((function(){return r._callPromise(n,(function(e){const n=e.history,o=[]
if(n.publications)for(let i=0;i<n.publications.length;i++)o.push(r._getPublicationContext(t,n.publications[i]))
return{publications:o,epoch:n.epoch||"",offset:n.offset||0}}))}))}presence(t){const e={presence:{channel:t}},n=this
return this._methodCall().then((function(){return n._callPromise(e,(function(t){return{clients:t.presence.presence}}))}))}presenceStats(t){const e={presence_stats:{channel:t}},n=this
return this._methodCall().then((function(){return n._callPromise(e,(function(t){const e=t.presence_stats
return{numUsers:e.num_users,numClients:e.num_clients}}))}))}startBatching(){this._batching=!0}stopBatching(){const t=this
Promise.resolve().then((function(){Promise.resolve().then((function(){t._batching=!1,t._flush()}))}))}_debug(){if(this._debugEnabled){for(var t=arguments.length,e=new Array(t),n=0;n<t;n++)e[n]=arguments[n];(0,f.log)("debug",e)}}_setFormat(t){if(!this._formatOverride(t)){if("protobuf"===t)throw new Error("not implemented by JSON-only Centrifuge client, use client with Protobuf support")
this._encoder=new p.JsonEncoder,this._decoder=new p.JsonDecoder}}_formatOverride(t){return!1}_configure(){if(!("Promise"in globalThis))throw new Error("Promise polyfill required")
if(!this._endpoint)throw new Error("endpoint configuration required")
if("json"!==this._config.protocol&&"protobuf"!==this._config.protocol)throw new Error("unsupported protocol "+this._config.protocol)
if(null!==this._config.token&&(this._token=this._config.token),this._setFormat("json"),"protobuf"===this._config.protocol&&this._setFormat("protobuf"),(!0===this._config.debug||"undefined"!=typeof localStorage&&localStorage.getItem("centrifuge.debug"))&&(this._debugEnabled=!0),this._debug("config",this._config),"string"==typeof this._endpoint);else{if(!("object"==typeof this._endpoint&&this._endpoint instanceof Array))throw new Error("unsupported url configuration type: only string or array of objects are supported")
this._transports=this._endpoint,this._emulation=!0
for(const t in this._transports){const e=this._transports[t]
if(!e.endpoint||!e.transport)throw new Error("malformed transport configuration")
const n=e.transport
if(["websocket","http_stream","sse","sockjs","webtransport"].indexOf(n)<0)throw new Error("unsupported transport name: "+n)}}}_setState(t){if(this.state!==t){const e=this.state
return this.state=t,this.emit("state",{newState:t,oldState:e}),!0}return!1}_isDisconnected(){return this.state===h.State.Disconnected}_isConnecting(){return this.state===h.State.Connecting}_isConnected(){return this.state===h.State.Connected}_nextCommandId(){return++this._commandId}_getReconnectDelay(){const t=(0,f.backoff)(this._reconnectAttempts,this._config.minReconnectDelay,this._config.maxReconnectDelay)
return this._reconnectAttempts+=1,t}_clearOutgoingRequests(){for(const t in this._callbacks)if(this._callbacks.hasOwnProperty(t)){const e=this._callbacks[t]
clearTimeout(e.timeout)
const n=e.errback
if(!n)continue
n({error:this._createErrorObject(i.errorCodes.connectionClosed,"connection closed")})}this._callbacks={}}_clearConnectedState(){this._client=null,this._clearServerPingTimeout(),this._clearRefreshTimeout()
for(const t in this._subs){if(!this._subs.hasOwnProperty(t))continue
const e=this._subs[t]
e.state===h.SubscriptionState.Subscribed&&e._setSubscribing(i.subscribingCodes.transportClosed,"transport closed")}for(const t in this._serverSubs)this._serverSubs.hasOwnProperty(t)&&this.emit("subscribing",{channel:t})}_handleWriteError(t){for(const e of t){const t=e.id
if(!(t in this._callbacks))continue
const n=this._callbacks[t]
clearTimeout(this._callbacks[t].timeout),delete this._callbacks[t],(0,n.errback)({error:this._createErrorObject(i.errorCodes.transportWriteError,"transport write error")})}}_transportSendCommands(t){if(!t.length)return!0
if(!this._transport)return!1
try{this._transport.send(this._encoder.encodeCommands(t),this._session,this._node)}catch(e){return this._debug("error writing commands",e),this._handleWriteError(t),!1}return!0}_initializeTransport(){let t
null!==this._config.websocket?t=this._config.websocket:"function"!=typeof globalThis.WebSocket&&"object"!=typeof globalThis.WebSocket||(t=globalThis.WebSocket)
let e=null
null!==this._config.sockjs?e=this._config.sockjs:void 0!==globalThis.SockJS&&(e=globalThis.SockJS)
let n=null
null!==this._config.eventsource?n=this._config.eventsource:void 0!==globalThis.EventSource&&(n=globalThis.EventSource)
let r=null
null!==this._config.fetch?r=this._config.fetch:void 0!==globalThis.fetch&&(r=globalThis.fetch)
let o=null
if(null!==this._config.readableStream?o=this._config.readableStream:void 0!==globalThis.ReadableStream&&(o=globalThis.ReadableStream),this._emulation){this._currentTransportIndex>=this._transports.length&&(this._triedAllTransports=!0,this._currentTransportIndex=0)
let i=0
for(;;){if(i>=this._transports.length)throw new Error("no supported transport found")
const p=this._transports[this._currentTransportIndex],f=p.transport,h=p.endpoint
if("websocket"===f){if(this._debug("trying websocket transport"),this._transport=new a.WebsocketTransport(h,{websocket:t}),!this._transport.supported()){this._debug("websocket transport not available"),this._currentTransportIndex++,i++
continue}}else if("webtransport"===f){if(this._debug("trying webtransport transport"),this._transport=new l.WebtransportTransport(h,{webtransport:globalThis.WebTransport,decoder:this._decoder,encoder:this._encoder}),!this._transport.supported()){this._debug("webtransport transport not available"),this._currentTransportIndex++,i++
continue}}else if("http_stream"===f){if(this._debug("trying http_stream transport"),this._transport=new c.HttpStreamTransport(h,{fetch:r,readableStream:o,emulationEndpoint:this._config.emulationEndpoint,decoder:this._decoder,encoder:this._encoder}),!this._transport.supported()){this._debug("http_stream transport not available"),this._currentTransportIndex++,i++
continue}}else if("sse"===f){if(this._debug("trying sse transport"),this._transport=new u.SseTransport(h,{eventsource:n,fetch:r,emulationEndpoint:this._config.emulationEndpoint}),!this._transport.supported()){this._debug("sse transport not available"),this._currentTransportIndex++,i++
continue}}else{if("sockjs"!==f)throw new Error("unknown transport "+f)
if(this._debug("trying sockjs"),this._transport=new s.SockjsTransport(h,{sockjs:e,sockjsOptions:this._config.sockjsOptions}),!this._transport.supported()){this._debug("sockjs transport not available"),this._currentTransportIndex++,i++
continue}}break}}else{if((0,f.startsWith)(this._endpoint,"http"))throw new Error("Provide explicit transport endpoints configuration in case of using HTTP (i.e. using array of TransportEndpoint instead of a single string), or use ws(s):// scheme in an endpoint if you aimed using WebSocket transport")
if(this._debug("client will use websocket"),this._transport=new a.WebsocketTransport(this._endpoint,{websocket:t}),!this._transport.supported())throw new Error("WebSocket not available")}const p=this
let h,d=!1,v=!0
"sse"===this._transport.name()&&(v=!1)
const m=[]
if(this._transport.emulation()){const t=p._sendConnect(!0)
if(m.push(t),v){const t=p._sendSubscribeCommands(!0,!0)
for(const e in t)m.push(t[e])}}const _=this._encoder.encodeCommands(m)
this._transport.initialize(this._config.protocol,{onOpen:function(){d=!0,h=p._transport.subName(),p._debug(h,"transport open"),p._transportWasOpen=!0,p._transportClosed=!1,p._transport.emulation()||(p.startBatching(),p._sendConnect(!1),v&&p._sendSubscribeCommands(!0,!1),p.stopBatching())},onError:function(t){p._debug("transport level error",t)},onClose:function(t){p._debug(p._transport.name(),"transport closed"),p._transportClosed=!0
let e="connection closed",n=!0,r=0
if(t&&"code"in t&&t.code&&(r=t.code),t&&t.reason)try{const r=JSON.parse(t.reason)
e=r.reason,n=r.reconnect}catch(o){e=t.reason,(r>=3500&&r<4e3||r>=4500&&r<5e3)&&(n=!1)}r<3e3?(1009===r?(r=i.disconnectedCodes.messageSizeLimit,e="message size limit exceeded",n=!1):(r=i.connectingCodes.transportClosed,e="transport closed"),p._emulation&&!p._transportWasOpen&&(p._currentTransportIndex++,p._currentTransportIndex>=p._transports.length&&(p._triedAllTransports=!0,p._currentTransportIndex=0))):p._transportWasOpen=!0
let o=!1
if(!p._emulation||p._transportWasOpen||p._triedAllTransports||(o=!0),p._isConnecting()&&!d&&p.emit("error",{type:"transport",error:{code:i.errorCodes.transportClosed,message:"transport closed"},transport:p._transport.name()}),p._disconnect(r,e,n),p._isConnecting()){let t=p._getReconnectDelay()
o&&(t=0),p._debug("reconnect after "+t+" milliseconds"),p._reconnectTimeout=setTimeout((()=>{p._startReconnecting()}),t)}},onMessage:function(t){p._dataReceived(t)}},_)}_sendConnect(t){const e=this._constructConnectCommand(),n=this
return this._call(e,t).then((t=>{const e=t.reply.connect
n._connectResponse(e),t.next&&t.next()}),(t=>{n._connectError(t.error),t.next&&t.next()})),e}_startReconnecting(){if(!this._isConnecting())return
if(!this._refreshRequired&&(this._token||null===this._config.getToken))return void this._initializeTransport()
const t=this
this._getToken().then((function(e){t._isConnecting()&&(e?(t._token=e,t._debug("connection token refreshed"),t._initializeTransport()):t._failUnauthorized())})).catch((function(e){if(!t._isConnecting())return
t.emit("error",{type:"connectToken",error:{code:i.errorCodes.clientConnectToken,message:void 0!==e?e.toString():""}})
const n=t._getReconnectDelay()
t._debug("error on connection token refresh, reconnect after "+n+" milliseconds",e),t._reconnectTimeout=setTimeout((()=>{t._startReconnecting()}),n)}))}_connectError(t){this.state===h.State.Connecting&&(109===t.code&&(this._refreshRequired=!0),t.code<100||!0===t.temporary||109===t.code?(this.emit("error",{type:"connect",error:t}),this._transport&&!this._transportClosed&&(this._transportClosed=!0,this._transport.close())):this._disconnect(t.code,t.message,!1))}_constructConnectCommand(){const t={}
this._token&&(t.token=this._token),this._config.data&&(t.data=this._config.data),this._config.name&&(t.name=this._config.name),this._config.version&&(t.version=this._config.version)
const e={}
let n=!1
for(const r in this._serverSubs)if(this._serverSubs.hasOwnProperty(r)&&this._serverSubs[r].recoverable){n=!0
const t={recover:!0}
this._serverSubs[r].offset&&(t.offset=this._serverSubs[r].offset),this._serverSubs[r].epoch&&(t.epoch=this._serverSubs[r].epoch),e[r]=t}return n&&(t.subs=e),{connect:t}}_getHistoryRequest(t,e){const n={channel:t}
return void 0!==e&&(e.since&&(n.since={offset:e.since.offset},e.since.epoch&&(n.since.epoch=e.since.epoch)),void 0!==e.limit&&(n.limit=e.limit),!0===e.reverse&&(n.reverse=!0)),n}_methodCall(){return this._isConnected()?Promise.resolve():new Promise(((t,e)=>{const n=setTimeout((function(){e({code:i.errorCodes.timeout,message:"timeout"})}),this._config.timeout)
this._promises[this._nextPromiseId()]={timeout:n,resolve:t,reject:e}}))}_callPromise(t,e){return new Promise(((n,r)=>{this._call(t,!1).then((t=>{n(e(t.reply)),t.next&&t.next()}),(t=>{r(t.error),t.next&&t.next()}))}))}_dataReceived(t){this._serverPing>0&&this._waitServerPing()
const e=this._decoder.decodeReplies(t)
this._dispatchPromise=this._dispatchPromise.then((()=>{let t
this._dispatchPromise=new Promise((e=>{t=e})),this._dispatchSynchronized(e,t)}))}_dispatchSynchronized(t,e){let n=Promise.resolve()
for(const r in t)t.hasOwnProperty(r)&&(n=n.then((()=>this._dispatchReply(t[r]))))
n=n.then((()=>{e()}))}_dispatchReply(t){let e
const n=new Promise((t=>{e=t}))
if(null==t)return this._debug("dispatch: got undefined or null reply"),e(),n
const r=t.id
return r&&r>0?this._handleReply(t,e):t.push?this._handlePush(t.push,e):this._handleServerPing(e),n}_call(t,e){return new Promise(((n,r)=>{t.id=this._nextCommandId(),this._registerCall(t.id,n,r),e||this._addCommand(t)}))}_startConnecting(){this._debug("start connecting"),this._setState(h.State.Connecting)&&this.emit("connecting",{code:i.connectingCodes.connectCalled,reason:"connect called"}),this._client=null,this._startReconnecting()}_disconnect(t,e,n){if(this._isDisconnected())return
const r=this.state,o={code:t,reason:e}
let s=!1
n?s=this._setState(h.State.Connecting):(s=this._setState(h.State.Disconnected),this._rejectPromises({code:i.errorCodes.clientDisconnected,message:"disconnected"})),this._clearOutgoingRequests(),r===h.State.Connecting&&this._clearReconnectTimeout(),r===h.State.Connected&&this._clearConnectedState(),s&&(this._isConnecting()?this.emit("connecting",o):this.emit("disconnected",o)),this._transport&&!this._transportClosed&&(this._transportClosed=!0,this._transport.close())}_failUnauthorized(){this._disconnect(i.disconnectedCodes.unauthorized,"unauthorized",!1)}_getToken(){if(this._debug("get connection token"),!this._config.getToken)throw new Error("provide a function to get connection token")
return this._config.getToken({})}_refresh(){const t=this._client,e=this
this._getToken().then((function(n){if(t!==e._client)return
if(!n)return void e._failUnauthorized()
if(e._token=n,e._debug("connection token refreshed"),!e._isConnected())return
const r={refresh:{token:e._token}}
e._call(r,!1).then((t=>{const n=t.reply.refresh
e._refreshResponse(n),t.next&&t.next()}),(t=>{e._refreshError(t.error),t.next&&t.next()}))})).catch((function(t){e.emit("error",{type:"refreshToken",error:{code:i.errorCodes.clientRefreshToken,message:void 0!==t?t.toString():""}}),e._refreshTimeout=setTimeout((()=>e._refresh()),e._getRefreshRetryDelay())}))}_refreshError(t){t.code<100||!0===t.temporary?(this.emit("error",{type:"refresh",error:t}),this._refreshTimeout=setTimeout((()=>this._refresh()),this._getRefreshRetryDelay())):this._disconnect(t.code,t.message,!1)}_getRefreshRetryDelay(){return(0,f.backoff)(0,5e3,1e4)}_refreshResponse(t){this._refreshTimeout&&(clearTimeout(this._refreshTimeout),this._refreshTimeout=null),t.expires&&(this._client=t.client,this._refreshTimeout=setTimeout((()=>this._refresh()),(0,f.ttlMilliseconds)(t.ttl)))}_removeSubscription(t){null!==t&&delete this._subs[t.channel]}_unsubscribe(t){if(!this._isConnected())return
const e={unsubscribe:{channel:t.channel}},n=this
this._call(e,!1).then((t=>{t.next&&t.next()}),(t=>{t.next&&t.next(),n._disconnect(i.connectingCodes.unsubscribeError,"unsubscribe error",!0)}))}_getSub(t){return this._subs[t]||null}_isServerSub(t){return void 0!==this._serverSubs[t]}_sendSubscribeCommands(t,e){const n=[]
for(const r in this._subs){if(!this._subs.hasOwnProperty(r))continue
const o=this._subs[r]
if(!0!==o._inflight&&o.state===h.SubscriptionState.Subscribing){const r=o._subscribe(t,e)
r&&n.push(r)}}return n}_connectResponse(t){if(this._transportWasOpen=!0,this._reconnectAttempts=0,this._refreshRequired=!1,this._isConnected())return
this._client=t.client,this._setState(h.State.Connected),this._refreshTimeout&&clearTimeout(this._refreshTimeout),t.expires&&(this._refreshTimeout=setTimeout((()=>this._refresh()),(0,f.ttlMilliseconds)(t.ttl))),this._session=t.session,this._node=t.node,this.startBatching(),this._sendSubscribeCommands(!1,!1),this.stopBatching()
const e={client:t.client,transport:this._transport.subName()}
t.data&&(e.data=t.data),this.emit("connected",e),this._resolvePromises(),this._processServerSubs(t.subs||{}),t.ping&&t.ping>0?(this._serverPing=1e3*t.ping,this._sendPong=!0===t.pong,this._waitServerPing()):this._serverPing=0}_processServerSubs(t){for(const e in t){if(!t.hasOwnProperty(e))continue
const n=t[e]
this._serverSubs[e]={offset:n.offset,epoch:n.epoch,recoverable:n.recoverable||!1}
const r=this._getSubscribeContext(e,n)
this.emit("subscribed",r)}for(const e in t){if(!t.hasOwnProperty(e))continue
const n=t[e]
if(n.recovered){const t=n.publications
if(t&&t.length>0)for(const n in t)t.hasOwnProperty(n)&&this._handlePublication(e,t[n])}}for(const e in this._serverSubs)this._serverSubs.hasOwnProperty(e)&&(t[e]||(this.emit("unsubscribed",{channel:e}),delete this._serverSubs[e]))}_clearRefreshTimeout(){null!==this._refreshTimeout&&(clearTimeout(this._refreshTimeout),this._refreshTimeout=null)}_clearReconnectTimeout(){null!==this._reconnectTimeout&&(clearTimeout(this._reconnectTimeout),this._reconnectTimeout=null)}_clearServerPingTimeout(){null!==this._serverPingTimeout&&(clearTimeout(this._serverPingTimeout),this._serverPingTimeout=null)}_waitServerPing(){0!==this._config.maxServerPingDelay&&this._isConnected()&&(this._clearServerPingTimeout(),this._serverPingTimeout=setTimeout((()=>{this._isConnected()&&this._disconnect(i.connectingCodes.noPing,"no ping",!0)}),this._serverPing+this._config.maxServerPingDelay))}_getSubscribeContext(t,e){const n={channel:t,positioned:!1,recoverable:!1,wasRecovering:!1,recovered:!1}
e.recovered&&(n.recovered=!0),e.positioned&&(n.positioned=!0),e.recoverable&&(n.recoverable=!0),e.was_recovering&&(n.wasRecovering=!0)
let r=""
"epoch"in e&&(r=e.epoch)
let o=0
return"offset"in e&&(o=e.offset),(n.positioned||n.recoverable)&&(n.streamPosition={offset:o,epoch:r}),e.data&&(n.data=e.data),n}_handleReply(t,e){const n=t.id
if(!(n in this._callbacks))return void e()
const r=this._callbacks[n]
if(clearTimeout(this._callbacks[n].timeout),delete this._callbacks[n],(0,f.errorExists)(t)){const n=r.errback
if(!n)return void e()
n({error:t.error,next:e})}else{const n=r.callback
if(!n)return
n({reply:t,next:e})}}_handleJoin(t,e){const n=this._getSub(t)
if(n)n._handleJoin(e)
else if(this._isServerSub(t)){const n={channel:t,info:this._getJoinLeaveContext(e.info)}
this.emit("join",n)}}_handleLeave(t,e){const n=this._getSub(t)
if(n)n._handleLeave(e)
else if(this._isServerSub(t)){const n={channel:t,info:this._getJoinLeaveContext(e.info)}
this.emit("leave",n)}}_handleUnsubscribe(t,e){const n=this._getSub(t)
n?e.code<2500?n._setUnsubscribed(e.code,e.reason,!1):n._setSubscribing(e.code,e.reason):this._isServerSub(t)&&(delete this._serverSubs[t],this.emit("unsubscribed",{channel:t}))}_handleSubscribe(t,e){this._serverSubs[t]={offset:e.offset,epoch:e.epoch,recoverable:e.recoverable||!1},this.emit("subscribed",this._getSubscribeContext(t,e))}_handleDisconnect(t){const e=t.code
let n=!0;(e>=3500&&e<4e3||e>=4500&&e<5e3)&&(n=!1),this._disconnect(e,t.reason,n)}_getPublicationContext(t,e){const n={channel:t,data:e.data}
return e.offset&&(n.offset=e.offset),e.info&&(n.info=this._getJoinLeaveContext(e.info)),e.tags&&(n.tags=e.tags),n}_getJoinLeaveContext(t){const e={client:t.client,user:t.user}
return t.conn_info&&(e.connInfo=t.conn_info),t.chan_info&&(e.chanInfo=t.chan_info),e}_handlePublication(t,e){const n=this._getSub(t)
if(n)n._handlePublication(e)
else if(this._isServerSub(t)){const n=this._getPublicationContext(t,e)
this.emit("publication",n),void 0!==e.offset&&(this._serverSubs[t].offset=e.offset)}}_handleMessage(t){this.emit("message",{data:t.data})}_handleServerPing(t){if(this._sendPong){const t={}
this._transportSendCommands([t])}t()}_handlePush(t,e){const n=t.channel
t.pub?this._handlePublication(n,t.pub):t.message?this._handleMessage(t.message):t.join?this._handleJoin(n,t.join):t.leave?this._handleLeave(n,t.leave):t.unsubscribe?this._handleUnsubscribe(n,t.unsubscribe):t.subscribe?this._handleSubscribe(n,t.subscribe):t.disconnect&&this._handleDisconnect(t.disconnect),e()}_flush(){const t=this._commands.slice(0)
this._commands=[],this._transportSendCommands(t)}_createErrorObject(t,e,n){const r={code:t,message:e}
return n&&(r.temporary=!0),r}_registerCall(t,e,n){this._callbacks[t]={callback:e,errback:n,timeout:null},this._callbacks[t].timeout=setTimeout((()=>{delete this._callbacks[t],(0,f.isFunction)(n)&&n({error:this._createErrorObject(i.errorCodes.timeout,"timeout")})}),this._config.timeout)}_addCommand(t){this._batching?this._commands.push(t):this._transportSendCommands([t])}_nextPromiseId(){return++this._promiseId}_resolvePromises(){for(const t in this._promises)this._promises[t].timeout&&clearTimeout(this._promises[t].timeout),this._promises[t].resolve(),delete this._promises[t]}_rejectPromises(t){for(const e in this._promises)this._promises[e].timeout&&clearTimeout(this._promises[e].timeout),this._promises[e].reject(t),delete this._promises[e]}}e.Centrifuge=m,m.SubscriptionState=h.SubscriptionState,m.State=h.State},7939:(t,e)=>{"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.unsubscribedCodes=e.subscribingCodes=e.disconnectedCodes=e.connectingCodes=e.errorCodes=void 0,e.errorCodes={timeout:1,transportClosed:2,clientDisconnected:3,clientClosed:4,clientConnectToken:5,clientRefreshToken:6,subscriptionUnsubscribed:7,subscriptionSubscribeToken:8,subscriptionRefreshToken:9,transportWriteError:10,connectionClosed:11},e.connectingCodes={connectCalled:0,transportClosed:1,noPing:2,subscribeTimeout:3,unsubscribeError:4},e.disconnectedCodes={disconnectCalled:0,unauthorized:1,badProtocol:2,messageSizeLimit:3},e.subscribingCodes={subscribeCalled:0,transportClosed:1},e.unsubscribedCodes={unsubscribeCalled:0,unauthorized:1,clientClosed:2}},6468:function(t,e,n){"use strict"
var r=this&&this.__createBinding||(Object.create?function(t,e,n,r){void 0===r&&(r=n)
var o=Object.getOwnPropertyDescriptor(e,n)
o&&!("get"in o?!e.__esModule:o.writable||o.configurable)||(o={enumerable:!0,get:function(){return e[n]}}),Object.defineProperty(t,r,o)}:function(t,e,n,r){void 0===r&&(r=n),t[r]=e[n]}),o=this&&this.__exportStar||function(t,e){for(var n in t)"default"===n||Object.prototype.hasOwnProperty.call(e,n)||r(e,t,n)}
Object.defineProperty(e,"__esModule",{value:!0}),e.Subscription=e.Centrifuge=void 0
const i=n(1442)
Object.defineProperty(e,"Centrifuge",{enumerable:!0,get:function(){return i.Centrifuge}})
const s=n(3979)
Object.defineProperty(e,"Subscription",{enumerable:!0,get:function(){return s.Subscription}}),o(n(9241),e)},680:(t,e)=>{"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.JsonDecoder=e.JsonEncoder=void 0,e.JsonEncoder=class{encodeCommands(t){return t.map((t=>JSON.stringify(t))).join("\n")}},e.JsonDecoder=class{decodeReplies(t){return t.trim().split("\n").map((t=>JSON.parse(t)))}}},3979:function(t,e,n){"use strict"
var r=this&&this.__importDefault||function(t){return t&&t.__esModule?t:{default:t}}
Object.defineProperty(e,"__esModule",{value:!0}),e.Subscription=void 0
const o=r(n(8291)),i=n(7939),s=n(9241),a=n(1077)
class c extends o.default{constructor(t,e,n){super(),this._resubscribeTimeout=null,this._refreshTimeout=null,this.channel=e,this.state=s.SubscriptionState.Unsubscribed,this._centrifuge=t,this._token=null,this._getToken=null,this._data=null,this._recover=!1,this._offset=null,this._epoch=null,this._recoverable=!1,this._positioned=!1,this._joinLeave=!1,this._minResubscribeDelay=500,this._maxResubscribeDelay=2e4,this._resubscribeTimeout=null,this._resubscribeAttempts=0,this._promises={},this._promiseId=0,this._inflight=!1,this._refreshTimeout=null,this._setOptions(n),this._centrifuge._debugEnabled?(this.on("state",(t=>{this._centrifuge._debug("subscription state",e,t.oldState,"->",t.newState)})),this.on("error",(t=>{this._centrifuge._debug("subscription error",e,t)}))):this.on("error",(function(){Function.prototype()}))}ready(t){return this.state===s.SubscriptionState.Unsubscribed?Promise.reject({code:i.errorCodes.subscriptionUnsubscribed,message:this.state}):this.state===s.SubscriptionState.Subscribed?Promise.resolve():new Promise(((e,n)=>{const r={resolve:e,reject:n}
t&&(r.timeout=setTimeout((function(){n({code:i.errorCodes.timeout,message:"timeout"})}),t)),this._promises[this._nextPromiseId()]=r}))}subscribe(){this._isSubscribed()||(this._resubscribeAttempts=0,this._setSubscribing(i.subscribingCodes.subscribeCalled,"subscribe called"))}unsubscribe(){this._setUnsubscribed(i.unsubscribedCodes.unsubscribeCalled,"unsubscribe called",!0)}publish(t){const e=this
return this._methodCall().then((function(){return e._centrifuge.publish(e.channel,t)}))}presence(){const t=this
return this._methodCall().then((function(){return t._centrifuge.presence(t.channel)}))}presenceStats(){const t=this
return this._methodCall().then((function(){return t._centrifuge.presenceStats(t.channel)}))}history(t){const e=this
return this._methodCall().then((function(){return e._centrifuge.history(e.channel,t)}))}_methodCall(){return this._isSubscribed()?Promise.resolve():this._isUnsubscribed()?Promise.reject({code:i.errorCodes.subscriptionUnsubscribed,message:this.state}):new Promise(((t,e)=>{const n=setTimeout((function(){e({code:i.errorCodes.timeout,message:"timeout"})}),this._centrifuge._config.timeout)
this._promises[this._nextPromiseId()]={timeout:n,resolve:t,reject:e}}))}_nextPromiseId(){return++this._promiseId}_needRecover(){return!0===this._recover}_isUnsubscribed(){return this.state===s.SubscriptionState.Unsubscribed}_isSubscribing(){return this.state===s.SubscriptionState.Subscribing}_isSubscribed(){return this.state===s.SubscriptionState.Subscribed}_setState(t){if(this.state!==t){const e=this.state
return this.state=t,this.emit("state",{newState:t,oldState:e,channel:this.channel}),!0}return!1}_usesToken(){return null!==this._token||null!==this._getToken}_clearSubscribingState(){this._resubscribeAttempts=0,this._clearResubscribeTimeout()}_clearSubscribedState(){this._clearRefreshTimeout()}_setSubscribed(t){if(!this._isSubscribing())return
this._clearSubscribingState(),t.recoverable&&(this._recover=!0,this._offset=t.offset||0,this._epoch=t.epoch||""),this._setState(s.SubscriptionState.Subscribed)
const e=this._centrifuge._getSubscribeContext(this.channel,t)
this.emit("subscribed",e),this._resolvePromises()
const n=t.publications
if(n&&n.length>0)for(const r in n)n.hasOwnProperty(r)&&this._handlePublication(n[r])
!0===t.expires&&(this._refreshTimeout=setTimeout((()=>this._refresh()),(0,a.ttlMilliseconds)(t.ttl)))}_setSubscribing(t,e){this._isSubscribing()||(this._isSubscribed()&&this._clearSubscribedState(),this._setState(s.SubscriptionState.Subscribing)&&this.emit("subscribing",{channel:this.channel,code:t,reason:e}),this._subscribe(!1,!1))}_subscribe(t,e){if(this._centrifuge._debug("subscribing on",this.channel),this._centrifuge.state!==s.State.Connected&&!t)return this._centrifuge._debug("delay subscribe on",this.channel,"till connected"),null
if(this._usesToken()){if(this._token)return this._sendSubscribe(this._token,e)
{if(t)return null
const e=this
return this._getSubscriptionToken().then((function(t){e._isSubscribing()&&(t?(e._token=t,e._sendSubscribe(t,!1)):e._failUnauthorized())})).catch((function(t){e._isSubscribing()&&(e.emit("error",{type:"subscribeToken",channel:e.channel,error:{code:i.errorCodes.subscriptionSubscribeToken,message:void 0!==t?t.toString():""}}),e._scheduleResubscribe())})),null}}return this._sendSubscribe("",e)}_sendSubscribe(t,e){const n={channel:this.channel}
if(t&&(n.token=t),this._data&&(n.data=this._data),this._positioned&&(n.positioned=!0),this._recoverable&&(n.recoverable=!0),this._joinLeave&&(n.join_leave=!0),this._needRecover()){n.recover=!0
const t=this._getOffset()
t&&(n.offset=t)
const e=this._getEpoch()
e&&(n.epoch=e)}const r={subscribe:n}
return this._inflight=!0,this._centrifuge._call(r,e).then((t=>{this._inflight=!1
const e=t.reply.subscribe
this._handleSubscribeResponse(e),t.next&&t.next()}),(t=>{this._inflight=!1,this._handleSubscribeError(t.error),t.next&&t.next()})),r}_handleSubscribeError(t){this._isSubscribing()&&(t.code!==i.errorCodes.timeout?this._subscribeError(t):this._centrifuge._disconnect(i.connectingCodes.subscribeTimeout,"subscribe timeout",!0))}_handleSubscribeResponse(t){this._isSubscribing()&&this._setSubscribed(t)}_setUnsubscribed(t,e,n){this._isUnsubscribed()||(this._isSubscribed()&&(n&&this._centrifuge._unsubscribe(this),this._clearSubscribedState()),this._isSubscribing()&&this._clearSubscribingState(),this._setState(s.SubscriptionState.Unsubscribed)&&this.emit("unsubscribed",{channel:this.channel,code:t,reason:e}),this._rejectPromises({code:i.errorCodes.subscriptionUnsubscribed,message:this.state}))}_handlePublication(t){const e=this._centrifuge._getPublicationContext(this.channel,t)
this.emit("publication",e),t.offset&&(this._offset=t.offset)}_handleJoin(t){const e=this._centrifuge._getJoinLeaveContext(t.info)
this.emit("join",{channel:this.channel,info:e})}_handleLeave(t){const e=this._centrifuge._getJoinLeaveContext(t.info)
this.emit("leave",{channel:this.channel,info:e})}_resolvePromises(){for(const t in this._promises)this._promises[t].timeout&&clearTimeout(this._promises[t].timeout),this._promises[t].resolve(),delete this._promises[t]}_rejectPromises(t){for(const e in this._promises)this._promises[e].timeout&&clearTimeout(this._promises[e].timeout),this._promises[e].reject(t),delete this._promises[e]}_scheduleResubscribe(){const t=this,e=this._getResubscribeDelay()
this._resubscribeTimeout=setTimeout((function(){t._isSubscribing()&&t._subscribe(!1,!1)}),e)}_subscribeError(t){if(this._isSubscribing())if(t.code<100||109===t.code||!0===t.temporary){109===t.code&&(this._token=null)
const e={channel:this.channel,type:"subscribe",error:t}
this._centrifuge.state===s.State.Connected&&this.emit("error",e),this._scheduleResubscribe()}else this._setUnsubscribed(t.code,t.message,!1)}_getResubscribeDelay(){const t=(0,a.backoff)(this._resubscribeAttempts,this._minResubscribeDelay,this._maxResubscribeDelay)
return this._resubscribeAttempts++,t}_setOptions(t){t&&(t.since&&(this._offset=t.since.offset,this._epoch=t.since.epoch,this._recover=!0),t.data&&(this._data=t.data),void 0!==t.minResubscribeDelay&&(this._minResubscribeDelay=t.minResubscribeDelay),void 0!==t.maxResubscribeDelay&&(this._maxResubscribeDelay=t.maxResubscribeDelay),t.token&&(this._token=t.token),t.getToken&&(this._getToken=t.getToken),!0===t.positioned&&(this._positioned=!0),!0===t.recoverable&&(this._recoverable=!0),!0===t.joinLeave&&(this._joinLeave=!0))}_getOffset(){const t=this._offset
return null!==t?t:0}_getEpoch(){const t=this._epoch
return null!==t?t:""}_clearRefreshTimeout(){null!==this._refreshTimeout&&(clearTimeout(this._refreshTimeout),this._refreshTimeout=null)}_clearResubscribeTimeout(){null!==this._resubscribeTimeout&&(clearTimeout(this._resubscribeTimeout),this._resubscribeTimeout=null)}_getSubscriptionToken(){this._centrifuge._debug("get subscription token for channel",this.channel)
const t={channel:this.channel},e=this._getToken
if(null===e)throw new Error("provide a function to get channel subscription token")
return e(t)}_refresh(){this._clearRefreshTimeout()
const t=this
this._getSubscriptionToken().then((function(e){if(!t._isSubscribed())return
if(!e)return void t._failUnauthorized()
t._token=e
const n={sub_refresh:{channel:t.channel,token:e}}
t._centrifuge._call(n).then((e=>{const n=e.reply.sub_refresh
t._refreshResponse(n),e.next&&e.next()}),(e=>{t._refreshError(e.error),e.next&&e.next()}))})).catch((function(e){t.emit("error",{type:"refreshToken",channel:t.channel,error:{code:i.errorCodes.subscriptionRefreshToken,message:void 0!==e?e.toString():""}}),t._refreshTimeout=setTimeout((()=>t._refresh()),t._getRefreshRetryDelay())}))}_refreshResponse(t){this._isSubscribed()&&(this._centrifuge._debug("subscription token refreshed, channel",this.channel),this._clearRefreshTimeout(),!0===t.expires&&(this._refreshTimeout=setTimeout((()=>this._refresh()),(0,a.ttlMilliseconds)(t.ttl))))}_refreshError(t){this._isSubscribed()&&(t.code<100||!0===t.temporary?(this.emit("error",{type:"refresh",channel:this.channel,error:t}),this._refreshTimeout=setTimeout((()=>this._refresh()),this._getRefreshRetryDelay())):this._setUnsubscribed(t.code,t.message,!0))}_getRefreshRetryDelay(){return(0,a.backoff)(0,1e4,2e4)}_failUnauthorized(){this._setUnsubscribed(i.unsubscribedCodes.unauthorized,"unauthorized",!0)}}e.Subscription=c},7280:(t,e)=>{"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.HttpStreamTransport=void 0,e.HttpStreamTransport=class{constructor(t,e){this.endpoint=t,this.options=e,this._abortController=null,this._utf8decoder=new TextDecoder,this._protocol="json"}name(){return"http_stream"}subName(){return"http_stream"}emulation(){return!0}_handleErrors(t){if(!t.ok)throw new Error(t.status)
return t}_fetchEventTarget(t,e,n){const r=new EventTarget
return(0,t.options.fetch)(e,n).then(t._handleErrors).then((e=>{r.dispatchEvent(new Event("open"))
let n="",o=0,i=new Uint8Array
const s=e.body.getReader()
return new t.options.readableStream({start:e=>function a(){return s.read().then((s=>{let{done:c,value:u}=s
if(c)return r.dispatchEvent(new Event("close")),void e.close()
try{if("json"===t._protocol)for(n+=t._utf8decoder.decode(u);o<n.length;)if("\n"===n[o]){const t=n.substring(0,o)
r.dispatchEvent(new MessageEvent("message",{data:t})),n=n.substring(o+1),o=0}else++o
else{const e=new Uint8Array(i.length+u.length)
for(e.set(i),e.set(u,i.length),i=e;;){const e=t.options.decoder.decodeReply(i)
if(!e.ok)break
{const t=i.slice(0,e.pos)
r.dispatchEvent(new MessageEvent("message",{data:t})),i=i.slice(e.pos)}}}}catch(t){return r.dispatchEvent(new Event("error",{detail:t})),r.dispatchEvent(new Event("close")),void e.close()}a()})).catch((function(t){r.dispatchEvent(new Event("error",{detail:t})),r.dispatchEvent(new Event("close")),e.close()}))}()})})).catch((t=>{r.dispatchEvent(new Event("error",{detail:t})),r.dispatchEvent(new Event("close"))})),r}supported(){return null!==this.options.fetch&&null!==this.options.readableStream&&"undefined"!=typeof TextDecoder&&"undefined"!=typeof AbortController&&"undefined"!=typeof EventTarget&&"undefined"!=typeof Event&&"undefined"!=typeof MessageEvent&&"undefined"!=typeof Error}initialize(t,e,n){let r,o
this._protocol=t,this._abortController=new AbortController,"json"===t?(r={Accept:"application/json","Content-Type":"application/json"},o=n):(r={Accept:"application/octet-stream","Content-Type":"application/octet-stream"},o=n)
const i={method:"POST",headers:r,body:o,mode:"cors",credentials:"same-origin",cache:"no-cache",signal:this._abortController.signal},s=this._fetchEventTarget(this,this.endpoint,i)
s.addEventListener("open",(()=>{e.onOpen()})),s.addEventListener("error",(t=>{this._abortController.abort(),e.onError(t)})),s.addEventListener("close",(()=>{this._abortController.abort(),e.onClose({code:4,reason:"connection closed"})})),s.addEventListener("message",(t=>{e.onMessage(t.data)}))}close(){this._abortController.abort()}send(t,e,n){let r,o
const i={session:e,node:n,data:t}
"json"===this._protocol?(r={"Content-Type":"application/json"},o=JSON.stringify(i)):(r={"Content-Type":"application/octet-stream"},o=this.options.encoder.encodeEmulationRequest(i))
const s={method:"POST",headers:r,body:o,mode:"cors",credentials:"same-origin",cache:"no-cache"};(0,this.options.fetch)(this.options.emulationEndpoint,s)}}},3556:(t,e)=>{"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.SockjsTransport=void 0,e.SockjsTransport=class{constructor(t,e){this.endpoint=t,this.options=e,this._transport=null}name(){return"sockjs"}subName(){return"sockjs-"+this._transport.transport}emulation(){return!1}supported(){return null!==this.options.sockjs}initialize(t,e){this._transport=new this.options.sockjs(this.endpoint,null,this.options.sockjsOptions),this._transport.onopen=()=>{e.onOpen()},this._transport.onerror=t=>{e.onError(t)},this._transport.onclose=t=>{e.onClose(t)},this._transport.onmessage=t=>{e.onMessage(t.data)}}close(){this._transport.close()}send(t){this._transport.send(t)}}},5223:(t,e)=>{"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.SseTransport=void 0,e.SseTransport=class{constructor(t,e){this.endpoint=t,this.options=e,this._protocol="json",this._transport=null,this._onClose=null}name(){return"sse"}subName(){return"sse"}emulation(){return!0}supported(){return null!==this.options.eventsource&&null!==this.options.fetch}initialize(t,e,n){let r
r=globalThis&&globalThis.document&&globalThis.document.baseURI?new URL(this.endpoint,globalThis.document.baseURI):new URL(this.endpoint),r.searchParams.append("cf_connect",n)
const o=new this.options.eventsource(r.toString(),{})
this._transport=o,o.onopen=function(){e.onOpen()},o.onerror=function(t){o.close(),e.onError(t),e.onClose({code:4,reason:"connection closed"})},o.onmessage=function(t){e.onMessage(t.data)},this._onClose=function(){e.onClose({code:4,reason:"connection closed"})}}close(){this._transport.close(),null!==this._onClose&&this._onClose()}send(t,e,n){const r={session:e,node:n,data:t},o={method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(r),mode:"cors",credentials:"same-origin",cache:"no-cache"};(0,this.options.fetch)(this.options.emulationEndpoint,o)}}},9291:(t,e)=>{"use strict"
Object.defineProperty(e,"__esModule",{value:!0}),e.WebsocketTransport=void 0,e.WebsocketTransport=class{constructor(t,e){this.endpoint=t,this.options=e,this._transport=null}name(){return"websocket"}subName(){return"websocket"}emulation(){return!1}supported(){return void 0!==this.options.websocket&&null!==this.options.websocket}initialize(t,e){let n=""
"protobuf"===t&&(n="centrifuge-protobuf"),this._transport=""!==n?new this.options.websocket(this.endpoint,n):new this.options.websocket(this.endpoint),"protobuf"===t&&(this._transport.binaryType="arraybuffer"),this._transport.onopen=()=>{e.onOpen()},this._transport.onerror=t=>{e.onError(t)},this._transport.onclose=t=>{e.onClose(t)},this._transport.onmessage=t=>{e.onMessage(t.data)}}close(){this._transport.close()}send(t){this._transport.send(t)}}},9428:function(t,e){"use strict"
var n=this&&this.__awaiter||function(t,e,n,r){return new(n||(n=Promise))((function(o,i){function s(t){try{c(r.next(t))}catch(t){i(t)}}function a(t){try{c(r.throw(t))}catch(t){i(t)}}function c(t){var e
t.done?o(t.value):(e=t.value,e instanceof n?e:new n((function(t){t(e)}))).then(s,a)}c((r=r.apply(t,e||[])).next())}))}
Object.defineProperty(e,"__esModule",{value:!0}),e.WebtransportTransport=void 0,e.WebtransportTransport=class{constructor(t,e){this.endpoint=t,this.options=e,this._transport=null,this._stream=null,this._writer=null,this._utf8decoder=new TextDecoder,this._protocol="json"}name(){return"webtransport"}subName(){return"webtransport"}emulation(){return!1}supported(){return void 0!==this.options.webtransport&&null!==this.options.webtransport}initialize(t,e){return n(this,void 0,void 0,(function*(){let n
n=globalThis&&globalThis.document&&globalThis.document.baseURI?new URL(this.endpoint,globalThis.document.baseURI):new URL(this.endpoint),"protobuf"===t&&n.searchParams.append("cf_protocol","protobuf"),this._protocol=t
const r=new EventTarget
this._transport=new this.options.webtransport(n.toString()),this._transport.closed.then((()=>{e.onClose({code:4,reason:"connection closed"})})).catch((()=>{e.onClose({code:4,reason:"connection closed"})}))
try{yield this._transport.ready}catch(t){return void this.close()}let o
try{o=yield this._transport.createBidirectionalStream()}catch(t){return void this.close()}this._stream=o,this._writer=this._stream.writable.getWriter(),r.addEventListener("close",(()=>{e.onClose({code:4,reason:"connection closed"})})),r.addEventListener("message",(t=>{e.onMessage(t.data)})),this._startReading(r),e.onOpen()}))}_startReading(t){return n(this,void 0,void 0,(function*(){const e=this._stream.readable.getReader()
let n="",r=0,o=new Uint8Array
try{for(;;){const{done:i,value:s}=yield e.read()
if(s.length>0)if("json"===this._protocol)for(n+=this._utf8decoder.decode(s);r<n.length;)if("\n"===n[r]){const e=n.substring(0,r)
t.dispatchEvent(new MessageEvent("message",{data:e})),n=n.substring(r+1),r=0}else++r
else{const e=new Uint8Array(o.length+s.length)
for(e.set(o),e.set(s,o.length),o=e;;){const e=this.options.decoder.decodeReply(o)
if(!e.ok)break
{const n=o.slice(0,e.pos)
t.dispatchEvent(new MessageEvent("message",{data:n})),o=o.slice(e.pos)}}}if(i)break}}catch(e){t.dispatchEvent(new Event("close"))}}))}close(){return n(this,void 0,void 0,(function*(){try{this._writer&&(yield this._writer.close()),this._transport.close()}catch(t){}}))}send(t){return n(this,void 0,void 0,(function*(){let e
e="json"===this._protocol?(new TextEncoder).encode(t+"\n"):t
try{yield this._writer.write(e)}catch(t){this.close()}}))}}},9241:(t,e)=>{"use strict"
var n,r
Object.defineProperty(e,"__esModule",{value:!0}),e.SubscriptionState=e.State=void 0,(r=e.State||(e.State={})).Disconnected="disconnected",r.Connecting="connecting",r.Connected="connected",(n=e.SubscriptionState||(e.SubscriptionState={})).Unsubscribed="unsubscribed",n.Subscribing="subscribing",n.Subscribed="subscribed"},1077:(t,e)=>{"use strict"
function n(t){return null!=t&&"function"==typeof t}Object.defineProperty(e,"__esModule",{value:!0}),e.ttlMilliseconds=e.errorExists=e.backoff=e.log=e.isFunction=e.startsWith=void 0,e.startsWith=function(t,e){return 0===t.lastIndexOf(e,0)},e.isFunction=n,e.log=function(t,e){if(globalThis.console){const r=globalThis.console[t]
n(r)&&r.apply(globalThis.console,e)}},e.backoff=function(t,e,n){t>31&&(t=31)
const r=function(t,e){return Math.floor(Math.random()*(e-0+1)+0)}(0,Math.min(n,e*Math.pow(2,t)))
return Math.min(n,e+r)},e.errorExists=function(t){return"error"in t&&null!==t.error},e.ttlMilliseconds=function(t){return Math.min(1e3*t,2147483647)}},2059:(t,e,n)=>{"use strict"
function r(t,e){var n=t[e]
if(n){var o=n.numbers,i=n.parentLocale
return!o&&i&&(o=r(t,i)),o}}function o(t,e,n,o){void 0===o&&(o={})
var i=Number(t)
if(!t||"number"!=typeof i)return t
var s=r(n,e=function(t){return t instanceof Array?t[0].replace(/_/,"-").toLowerCase():t.replace(/_/,"-").toLowerCase()}(e))
if(!s)return t
var a=1
i<0&&(a=-1,i=Math.abs(i))
var c,u=o.financialFormat,l=void 0!==u&&u,p=o.long,f=void 0!==p&&p,h=o.significantDigits,d=void 0===h?0:h,v=o.threshold,m=void 0===v?.05:v,_=f?s.decimal.long:s.decimal.short
if(!_||i<1e3)return t
for(var g=0,y=0;y<=_.length;y++)if(i<=_[y][0]){var b=_[y][0]
!l&&1-i/b>m?c=_[y-1]:(c=_[y],d&&l||(g=1))
break}var w=c[0],E=c[1],S=E.one||E.other,x=S[0],O=S[1]
return x.match(/[^0]/)?function(t,e){return e.replace(/0*/,t)}(function(t,e,n,r,o){var i=o.significantDigits,s=void 0===i?0:i,a=o.minimumFractionDigits,c=void 0===a?0:a,u=o.maximumFractionDigits,l=void 0===u?2:u
return s?function(t,e,n){if(t&&"number"==typeof t)return t.toLocaleString(e,n)}(function(t,e){var n=Math.pow(10,e)
return Math.round(t*n)/n}(t,s),r,{maximumFractionDigits:l,minimumFractionDigits:c}):function(t,e){if(t<=1)return Math.round(t)
var n=Math.pow(10,e)
return Math.round(t/n)*n}(t,e)*n}(function(t,e,n){return t/e*Math.pow(10,n-1)}(i,w,O),g,a,e,o),x):t}n.r(e),n.d(e,{default:()=>i,compactFormat:()=>o})
const i=o},3682:(t,e,n)=>{"use strict"
function r(t,e){if(e.length<t)throw new TypeError(t+" argument"+t>1?"s":" required, but only "+e.length+" present")}n.d(e,{Z:()=>r})},394:(t,e,n)=>{"use strict"
function r(t){if(null===t||!0===t||!1===t)return NaN
var e=Number(t)
return isNaN(e)?e:e<0?Math.ceil(e):Math.floor(e)}n.d(e,{Z:()=>r})},9021:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(394),o=n(4327),i=n(3682)
function s(t,e){(0,i.Z)(2,arguments)
var n=(0,o.Z)(t),s=(0,r.Z)(e)
return n.setDate(n.getDate()+s),n}},3776:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>a})
var r=n(394),o=n(4327),i=n(3682)
function s(t){(0,i.Z)(1,arguments)
var e=(0,o.Z)(t),n=e.getFullYear(),r=e.getMonth(),s=new Date(0)
return s.setFullYear(n,r+1,0),s.setHours(0,0,0,0),s.getDate()}function a(t,e){(0,i.Z)(2,arguments)
var n=(0,o.Z)(t),a=(0,r.Z)(e),c=n.getMonth()+a,u=new Date(0)
u.setFullYear(n.getFullYear(),c,1),u.setHours(0,0,0,0)
var l=s(u)
return n.setMonth(c,Math.min(l,n.getDate())),n}},3651:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(394),o=n(9021),i=n(3682)
function s(t,e){(0,i.Z)(2,arguments)
var n=(0,r.Z)(e),s=7*n
return(0,o.default)(t,s)}},7605:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(394),o=n(3776),i=n(3682)
function s(t,e){(0,i.Z)(2,arguments)
var n=(0,r.Z)(e)
return(0,o.default)(t,12*n)}},5705:(t,e,n)=>{"use strict"
n.d(e,{Z:()=>i})
var r=n(4327),o=n(3682)
function i(t,e){(0,o.Z)(2,arguments)
var n=(0,r.Z)(t),i=(0,r.Z)(e),s=n.getTime()-i.getTime()
return s<0?-1:s>0?1:s}},4535:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>l})
var r=n(4327)
function o(t){var e=new Date(t.getTime()),n=Math.ceil(e.getTimezoneOffset())
return e.setSeconds(0,0),6e4*n+e.getTime()%6e4}var i=n(9429),s=n(3682),a=864e5
function c(t,e){(0,s.Z)(2,arguments)
var n=(0,i.default)(t),r=(0,i.default)(e),c=n.getTime()-o(n),u=r.getTime()-o(r)
return Math.round((c-u)/a)}var u=n(5705)
function l(t,e){(0,s.Z)(2,arguments)
var n=(0,r.Z)(t),o=(0,r.Z)(e),i=(0,u.Z)(n,o),a=Math.abs(c(n,o))
n.setDate(n.getDate()-i*a)
var l=(0,u.Z)(n,o)===-i,p=i*(a-l)
return 0===p?0:p}},1662:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(4327),o=n(3682)
function i(t,e){(0,o.Z)(2,arguments)
var n=(0,r.Z)(t),i=(0,r.Z)(e)
return n.getTime()-i.getTime()}function s(t,e){(0,o.Z)(2,arguments)
var n=i(t,e)/6e4
return n>0?Math.floor(n):Math.ceil(n)}},834:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>a})
var r=n(4327),o=n(3682)
function i(t,e){(0,o.Z)(2,arguments)
var n=(0,r.Z)(t),i=(0,r.Z)(e),s=n.getFullYear()-i.getFullYear(),a=n.getMonth()-i.getMonth()
return 12*s+a}var s=n(5705)
function a(t,e){(0,o.Z)(2,arguments)
var n=(0,r.Z)(t),a=(0,r.Z)(e),c=(0,s.Z)(n,a),u=Math.abs(i(n,a))
n.setMonth(n.getMonth()-c*u)
var l=(0,s.Z)(n,a)===-c,p=c*(u-l)
return 0===p?0:p}},5040:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>i})
var r=n(4535),o=n(3682)
function i(t,e){(0,o.Z)(2,arguments)
var n=(0,r.default)(t,e)/7
return n>0?Math.floor(n):Math.ceil(n)}},3752:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>i})
var r=n(4327),o=n(3682)
function i(t){(0,o.Z)(1,arguments)
var e=(0,r.Z)(t)
return e.setHours(23,59,59,999),e}},9214:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>a})
var r=n(4327),o=n(394),i=n(3682)
function s(t,e){(0,i.Z)(1,arguments)
var n=e||{},s=n.locale,a=s&&s.options&&s.options.weekStartsOn,c=null==a?0:(0,o.Z)(a),u=null==n.weekStartsOn?c:(0,o.Z)(n.weekStartsOn)
if(!(u>=0&&u<=6))throw new RangeError("weekStartsOn must be between 0 and 6 inclusively")
var l=(0,r.Z)(t),p=l.getDay(),f=6+(p<u?-7:0)-(p-u)
return l.setDate(l.getDate()+f),l.setHours(23,59,59,999),l}function a(t){return(0,i.Z)(1,arguments),s(t,{weekStartsOn:1})}},1905:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>i})
var r=n(4327),o=n(3682)
function i(t){(0,o.Z)(1,arguments)
var e=(0,r.Z)(t),n=e.getMonth()
return e.setFullYear(e.getFullYear(),n+1,0),e.setHours(23,59,59,999),e}},7096:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>i})
var r=n(4327),o=n(3682)
function i(t){return(0,o.Z)(1,arguments),(0,r.Z)(t).getTime()<Date.now()}},443:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>i})
var r=n(9429),o=n(3682)
function i(t,e){(0,o.Z)(2,arguments)
var n=(0,r.default)(t),i=(0,r.default)(e)
return n.getTime()===i.getTime()}},5612:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(4327),o=n(3682)
function i(t){(0,o.Z)(1,arguments)
var e=(0,r.Z)(t)
return e.setSeconds(0,0),e}function s(t,e){(0,o.Z)(2,arguments)
var n=i(t),r=i(e)
return n.getTime()===r.getTime()}},1410:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(394),o=n(4327),i=n(3682)
function s(t,e){(0,i.Z)(2,arguments)
var n=(0,o.Z)(t),s=(0,r.Z)(e)
return n.setHours(s),n}},9429:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>i})
var r=n(4327),o=n(3682)
function i(t){(0,o.Z)(1,arguments)
var e=(0,r.Z)(t)
return e.setHours(0,0,0,0),e}},3340:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(394),o=n(9021),i=n(3682)
function s(t,e){(0,i.Z)(2,arguments)
var n=(0,r.Z)(e)
return(0,o.default)(t,-n)}},8389:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>s})
var r=n(394),o=n(3776),i=n(3682)
function s(t,e){(0,i.Z)(2,arguments)
var n=(0,r.Z)(e)
return(0,o.default)(t,-n)}},4327:(t,e,n)=>{"use strict"
n.d(e,{Z:()=>o})
var r=n(3682)
function o(t){(0,r.Z)(1,arguments)
var e=Object.prototype.toString.call(t)
return t instanceof Date||"object"==typeof t&&"[object Date]"===e?new Date(t.getTime()):"number"==typeof t||"[object Number]"===e?new Date(t):("string"!=typeof t&&"[object String]"!==e||"undefined"==typeof console||(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as arguments. Please use `parseISO` to parse strings. See: https://git.io/fjule"),console.warn((new Error).stack)),new Date(NaN))}},8291:t=>{"use strict"
var e,n="object"==typeof Reflect?Reflect:null,r=n&&"function"==typeof n.apply?n.apply:function(t,e,n){return Function.prototype.apply.call(t,e,n)}
e=n&&"function"==typeof n.ownKeys?n.ownKeys:Object.getOwnPropertySymbols?function(t){return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))}:function(t){return Object.getOwnPropertyNames(t)}
var o=Number.isNaN||function(t){return t!=t}
function i(){i.init.call(this)}t.exports=i,t.exports.once=function(t,e){return new Promise((function(n,r){function o(n){t.removeListener(e,i),r(n)}function i(){"function"==typeof t.removeListener&&t.removeListener("error",o),n([].slice.call(arguments))}v(t,e,i,{once:!0}),"error"!==e&&function(t,e,n){"function"==typeof t.on&&v(t,"error",e,{once:!0})}(t,o)}))},i.EventEmitter=i,i.prototype._events=void 0,i.prototype._eventsCount=0,i.prototype._maxListeners=void 0
var s=10
function a(t){if("function"!=typeof t)throw new TypeError('The "listener" argument must be of type Function. Received type '+typeof t)}function c(t){return void 0===t._maxListeners?i.defaultMaxListeners:t._maxListeners}function u(t,e,n,r){var o,i,s,u
if(a(n),void 0===(i=t._events)?(i=t._events=Object.create(null),t._eventsCount=0):(void 0!==i.newListener&&(t.emit("newListener",e,n.listener?n.listener:n),i=t._events),s=i[e]),void 0===s)s=i[e]=n,++t._eventsCount
else if("function"==typeof s?s=i[e]=r?[n,s]:[s,n]:r?s.unshift(n):s.push(n),(o=c(t))>0&&s.length>o&&!s.warned){s.warned=!0
var l=new Error("Possible EventEmitter memory leak detected. "+s.length+" "+String(e)+" listeners added. Use emitter.setMaxListeners() to increase limit")
l.name="MaxListenersExceededWarning",l.emitter=t,l.type=e,l.count=s.length,u=l,console&&console.warn&&console.warn(u)}return t}function l(){if(!this.fired)return this.target.removeListener(this.type,this.wrapFn),this.fired=!0,0===arguments.length?this.listener.call(this.target):this.listener.apply(this.target,arguments)}function p(t,e,n){var r={fired:!1,wrapFn:void 0,target:t,type:e,listener:n},o=l.bind(r)
return o.listener=n,r.wrapFn=o,o}function f(t,e,n){var r=t._events
if(void 0===r)return[]
var o=r[e]
return void 0===o?[]:"function"==typeof o?n?[o.listener||o]:[o]:n?function(t){for(var e=new Array(t.length),n=0;n<e.length;++n)e[n]=t[n].listener||t[n]
return e}(o):d(o,o.length)}function h(t){var e=this._events
if(void 0!==e){var n=e[t]
if("function"==typeof n)return 1
if(void 0!==n)return n.length}return 0}function d(t,e){for(var n=new Array(e),r=0;r<e;++r)n[r]=t[r]
return n}function v(t,e,n,r){if("function"==typeof t.on)r.once?t.once(e,n):t.on(e,n)
else{if("function"!=typeof t.addEventListener)throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type '+typeof t)
t.addEventListener(e,(function o(i){r.once&&t.removeEventListener(e,o),n(i)}))}}Object.defineProperty(i,"defaultMaxListeners",{enumerable:!0,get:function(){return s},set:function(t){if("number"!=typeof t||t<0||o(t))throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received '+t+".")
s=t}}),i.init=function(){void 0!==this._events&&this._events!==Object.getPrototypeOf(this)._events||(this._events=Object.create(null),this._eventsCount=0),this._maxListeners=this._maxListeners||void 0},i.prototype.setMaxListeners=function(t){if("number"!=typeof t||t<0||o(t))throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received '+t+".")
return this._maxListeners=t,this},i.prototype.getMaxListeners=function(){return c(this)},i.prototype.emit=function(t){for(var e=[],n=1;n<arguments.length;n++)e.push(arguments[n])
var o="error"===t,i=this._events
if(void 0!==i)o=o&&void 0===i.error
else if(!o)return!1
if(o){var s
if(e.length>0&&(s=e[0]),s instanceof Error)throw s
var a=new Error("Unhandled error."+(s?" ("+s.message+")":""))
throw a.context=s,a}var c=i[t]
if(void 0===c)return!1
if("function"==typeof c)r(c,this,e)
else{var u=c.length,l=d(c,u)
for(n=0;n<u;++n)r(l[n],this,e)}return!0},i.prototype.addListener=function(t,e){return u(this,t,e,!1)},i.prototype.on=i.prototype.addListener,i.prototype.prependListener=function(t,e){return u(this,t,e,!0)},i.prototype.once=function(t,e){return a(e),this.on(t,p(this,t,e)),this},i.prototype.prependOnceListener=function(t,e){return a(e),this.prependListener(t,p(this,t,e)),this},i.prototype.removeListener=function(t,e){var n,r,o,i,s
if(a(e),void 0===(r=this._events))return this
if(void 0===(n=r[t]))return this
if(n===e||n.listener===e)0==--this._eventsCount?this._events=Object.create(null):(delete r[t],r.removeListener&&this.emit("removeListener",t,n.listener||e))
else if("function"!=typeof n){for(o=-1,i=n.length-1;i>=0;i--)if(n[i]===e||n[i].listener===e){s=n[i].listener,o=i
break}if(o<0)return this
0===o?n.shift():function(t,e){for(;e+1<t.length;e++)t[e]=t[e+1]
t.pop()}(n,o),1===n.length&&(r[t]=n[0]),void 0!==r.removeListener&&this.emit("removeListener",t,s||e)}return this},i.prototype.off=i.prototype.removeListener,i.prototype.removeAllListeners=function(t){var e,n,r
if(void 0===(n=this._events))return this
if(void 0===n.removeListener)return 0===arguments.length?(this._events=Object.create(null),this._eventsCount=0):void 0!==n[t]&&(0==--this._eventsCount?this._events=Object.create(null):delete n[t]),this
if(0===arguments.length){var o,i=Object.keys(n)
for(r=0;r<i.length;++r)"removeListener"!==(o=i[r])&&this.removeAllListeners(o)
return this.removeAllListeners("removeListener"),this._events=Object.create(null),this._eventsCount=0,this}if("function"==typeof(e=n[t]))this.removeListener(t,e)
else if(void 0!==e)for(r=e.length-1;r>=0;r--)this.removeListener(t,e[r])
return this},i.prototype.listeners=function(t){return f(this,t,!0)},i.prototype.rawListeners=function(t){return f(this,t,!1)},i.listenerCount=function(t,e){return"function"==typeof t.listenerCount?t.listenerCount(e):h.call(t,e)},i.prototype.listenerCount=h,i.prototype.eventNames=function(){return this._eventsCount>0?e(this._events):[]}},3094:t=>{"use strict"
var e=Array.isArray,n=Object.keys,r=Object.prototype.hasOwnProperty
t.exports=function t(o,i){if(o===i)return!0
if(o&&i&&"object"==typeof o&&"object"==typeof i){var s,a,c,u=e(o),l=e(i)
if(u&&l){if((a=o.length)!=i.length)return!1
for(s=a;0!=s--;)if(!t(o[s],i[s]))return!1
return!0}if(u!=l)return!1
var p=o instanceof Date,f=i instanceof Date
if(p!=f)return!1
if(p&&f)return o.getTime()==i.getTime()
var h=o instanceof RegExp,d=i instanceof RegExp
if(h!=d)return!1
if(h&&d)return o.toString()==i.toString()
var v=n(o)
if((a=v.length)!==n(i).length)return!1
for(s=a;0!=s--;)if(!r.call(i,v[s]))return!1
for(s=a;0!=s--;)if(!t(o[c=v[s]],i[c]))return!1
return!0}return o!=o&&i!=i}},5721:t=>{function e(t,e,n,r){var o,i=null==(o=r)||"number"==typeof o||"boolean"==typeof o?r:n(r),s=e.get(i)
return void 0===s&&(s=t.call(this,r),e.set(i,s)),s}function n(t,e,n){var r=Array.prototype.slice.call(arguments,3),o=n(r),i=e.get(o)
return void 0===i&&(i=t.apply(this,r),e.set(o,i)),i}function r(t,e,n,r,o){return n.bind(e,t,r,o)}function o(t,o){return r(t,this,1===t.length?e:n,o.cache.create(),o.serializer)}function i(){return JSON.stringify(arguments)}function s(){this.cache=Object.create(null)}s.prototype.has=function(t){return t in this.cache},s.prototype.get=function(t){return this.cache[t]},s.prototype.set=function(t,e){this.cache[t]=e}
var a={create:function(){return new s}}
t.exports=function(t,e){var n=e&&e.cache?e.cache:a,r=e&&e.serializer?e.serializer:i
return(e&&e.strategy?e.strategy:o)(t,{cache:n,serializer:r})},t.exports.strategies={variadic:function(t,e){return r(t,this,n,e.cache.create(),e.serializer)},monadic:function(t,n){return r(t,this,e,n.cache.create(),n.serializer)}}},6990:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>u})
var r,o=function(){function t(){this.registry=new WeakMap}return t.prototype.elementExists=function(t){return this.registry.has(t)},t.prototype.getElement=function(t){return this.registry.get(t)},t.prototype.addElement=function(t,e){t&&this.registry.set(t,e||{})},t.prototype.removeElement=function(t){this.registry.delete(t)},t.prototype.destroyRegistry=function(){this.registry=new WeakMap},t}(),i=function(){}
!function(t){t.enter="enter",t.exit="exit"}(r||(r={}))
var s,a=function(){function t(){this.registry=new o}return t.prototype.addCallback=function(t,e,n){var o,i,s
t===r.enter?((o={})[r.enter]=n,s=o):((i={})[r.exit]=n,s=i),this.registry.addElement(e,Object.assign({},this.registry.getElement(e),s))},t.prototype.dispatchCallback=function(t,e,n){if(t===r.enter){var o=this.registry.getElement(e).enter;(void 0===o?i:o)(n)}else{var s=this.registry.getElement(e).exit;(void 0===s?i:s)(n)}},t}(),c=(s=function(t,e){return(s=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n])})(t,e)},function(t,e){function n(){this.constructor=t}s(t,e),t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)})
const u=function(t){function e(){var e=t.call(this)||this
return e.elementRegistry=new o,e}return c(e,t),e.prototype.observe=function(t,e){void 0===e&&(e={}),t&&(this.elementRegistry.addElement(t,e),this.setupObserver(t,e))},e.prototype.unobserve=function(t,e){var n=this.findMatchingRootEntry(e)
n&&n.intersectionObserver.unobserve(t)},e.prototype.addEnterCallback=function(t,e){this.addCallback(r.enter,t,e)},e.prototype.addExitCallback=function(t,e){this.addCallback(r.exit,t,e)},e.prototype.dispatchEnterCallback=function(t,e){this.dispatchCallback(r.enter,t,e)},e.prototype.dispatchExitCallback=function(t,e){this.dispatchCallback(r.exit,t,e)},e.prototype.destroy=function(){this.elementRegistry.destroyRegistry()},e.prototype.setupOnIntersection=function(t){var e=this
return function(n){return e.onIntersection(t,n)}},e.prototype.setupObserver=function(t,e){var n,r,o=e.root,i=void 0===o?window:o,s=this.findRootFromRegistry(i)
if(s&&(r=this.determineMatchingElements(e,s)),r){var a=r.elements,c=r.intersectionObserver
a.push(t),c&&c.observe(t)}else{var u={elements:[t],intersectionObserver:c=this.newObserver(t,e),options:e},l=this.stringifyOptions(e)
s?s[l]=u:this.elementRegistry.addElement(i,((n={})[l]=u,n))}},e.prototype.newObserver=function(t,e){var n=e.root,r=e.rootMargin,o=e.threshold,i=new IntersectionObserver(this.setupOnIntersection(e).bind(this),{root:n,rootMargin:r,threshold:o})
return i.observe(t),i},e.prototype.onIntersection=function(t,e){var n=this
e.forEach((function(e){var r=e.isIntersecting,o=e.intersectionRatio,i=t.threshold||0
Array.isArray(i)&&(i=i[i.length-1])
var s=n.findMatchingRootEntry(t)
r||o>i?s&&s.elements.some((function(t){return!(!t||t!==e.target||(n.dispatchEnterCallback(t,e),0))})):s&&s.elements.some((function(t){return!(!t||t!==e.target||(n.dispatchExitCallback(t,e),0))}))}))},e.prototype.findRootFromRegistry=function(t){if(this.elementRegistry)return this.elementRegistry.getElement(t)},e.prototype.findMatchingRootEntry=function(t){var e=t.root,n=void 0===e?window:e,r=this.findRootFromRegistry(n)
if(r)return r[this.stringifyOptions(t)]},e.prototype.determineMatchingElements=function(t,e){var n=this,r=Object.keys(e).filter((function(r){var o=e[r].options
return n.areOptionsSame(t,o)}))[0]
return e[r]},e.prototype.areOptionsSame=function(t,e){if(t===e)return!0
var n=Object.prototype.toString.call(t),r=Object.prototype.toString.call(e)
if(n!==r)return!1
if("[object Object]"!==n&&"[object Object]"!==r)return t===e
if(t&&e&&"object"==typeof t&&"object"==typeof e)for(var o in t)if(Object.prototype.hasOwnProperty.call(t,o)&&!1===this.areOptionsSame(t[o],e[o]))return!1
return!0},e.prototype.stringifyOptions=function(t){var e=t.root
return JSON.stringify(t,(function(t,n){if("root"===t&&e){var r=Array.prototype.slice.call(e.classList).reduce((function(t,e){return t+e}),"")
return e.id+"-"+r}return n}))},e}(a)},3211:function(t,e,n){"use strict"
var r=this&&this.__awaiter||function(t,e,n,r){return new(n||(n=Promise))((function(o,i){function s(t){try{c(r.next(t))}catch(t){i(t)}}function a(t){try{c(r.throw(t))}catch(t){i(t)}}function c(t){t.done?o(t.value):new n((function(e){e(t.value)})).then(s,a)}c((r=r.apply(t,e||[])).next())}))},o=this&&this.__importDefault||function(t){return t&&t.__esModule?t:{default:t}}
Object.defineProperty(e,"__esModule",{value:!0})
const i=o(n(9952))
function s(t){let e,n,o,s=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"maxAge"
const a=()=>r(this,void 0,void 0,(function*(){if(void 0!==e)return
const a=a=>r(this,void 0,void 0,(function*(){o=i.default()
const r=a[1][s]-Date.now()
return r<=0?(t.delete(a[0]),void o.resolve()):(e=a[0],n=setTimeout((()=>{t.delete(a[0]),o&&o.resolve()}),r),"function"==typeof n.unref&&n.unref(),o.promise)}))
try{for(const e of t)yield a(e)}catch(t){}e=void 0})),c=()=>{e=void 0,void 0!==n&&(clearTimeout(n),n=void 0),void 0!==o&&(o.reject(void 0),o=void 0)},u=t.set.bind(t)
return t.set=(n,r)=>{t.has(n)&&t.delete(n)
const o=u(n,r)
return e&&e===n&&c(),a(),o},a(),t}e.default=s,t.exports=s,t.exports.default=s},9952:t=>{"use strict"
t.exports=()=>{const t={}
return t.promise=new Promise(((e,n)=>{t.resolve=e,t.reject=n})),t}},1494:(t,e,n)=>{"use strict"
var r
n.r(e),n.d(e,{default:()=>o})
const o=function(){function t(){this.pool=[],this.flush()}return t.prototype.flush=function(){var t=this
r=window.requestAnimationFrame((function(){var e=t.pool
t.reset(),e.forEach((function(t){t[Object.keys(t)[0]]()})),t.flush()}))},t.prototype.add=function(t,e){var n
return this.pool.push(((n={})[t]=e,n)),e},t.prototype.remove=function(t){this.pool=this.pool.filter((function(e){return!e[t]}))},t.prototype.reset=function(){this.pool=[]},t.prototype.stop=function(){window.cancelAnimationFrame(r)},t}()},8800:(t,e,n)=>{"use strict"
n.r(e),n.d(e,{default:()=>E})
var r=function(){if("undefined"!=typeof Map)return Map
function t(t,e){var n=-1
return t.some((function(t,r){return t[0]===e&&(n=r,!0)})),n}return function(){function e(){this.__entries__=[]}return Object.defineProperty(e.prototype,"size",{get:function(){return this.__entries__.length},enumerable:!0,configurable:!0}),e.prototype.get=function(e){var n=t(this.__entries__,e),r=this.__entries__[n]
return r&&r[1]},e.prototype.set=function(e,n){var r=t(this.__entries__,e)
~r?this.__entries__[r][1]=n:this.__entries__.push([e,n])},e.prototype.delete=function(e){var n=this.__entries__,r=t(n,e)
~r&&n.splice(r,1)},e.prototype.has=function(e){return!!~t(this.__entries__,e)},e.prototype.clear=function(){this.__entries__.splice(0)},e.prototype.forEach=function(t,e){void 0===e&&(e=null)
for(var n=0,r=this.__entries__;n<r.length;n++){var o=r[n]
t.call(e,o[1],o[0])}},e}()}(),o="undefined"!=typeof window&&"undefined"!=typeof document&&window.document===document,i=void 0!==n.g&&n.g.Math===Math?n.g:"undefined"!=typeof self&&self.Math===Math?self:"undefined"!=typeof window&&window.Math===Math?window:Function("return this")(),s="function"==typeof requestAnimationFrame?requestAnimationFrame.bind(i):function(t){return setTimeout((function(){return t(Date.now())}),1e3/60)},a=["top","right","bottom","left","width","height","size","weight"],c="undefined"!=typeof MutationObserver,u=function(){function t(){this.connected_=!1,this.mutationEventsAdded_=!1,this.mutationsObserver_=null,this.observers_=[],this.onTransitionEnd_=this.onTransitionEnd_.bind(this),this.refresh=function(t,e){var n=!1,r=!1,o=0
function i(){n&&(n=!1,t()),r&&c()}function a(){s(i)}function c(){var t=Date.now()
if(n){if(t-o<2)return
r=!0}else n=!0,r=!1,setTimeout(a,20)
o=t}return c}(this.refresh.bind(this))}return t.prototype.addObserver=function(t){~this.observers_.indexOf(t)||this.observers_.push(t),this.connected_||this.connect_()},t.prototype.removeObserver=function(t){var e=this.observers_,n=e.indexOf(t)
~n&&e.splice(n,1),!e.length&&this.connected_&&this.disconnect_()},t.prototype.refresh=function(){this.updateObservers_()&&this.refresh()},t.prototype.updateObservers_=function(){var t=this.observers_.filter((function(t){return t.gatherActive(),t.hasActive()}))
return t.forEach((function(t){return t.broadcastActive()})),t.length>0},t.prototype.connect_=function(){o&&!this.connected_&&(document.addEventListener("transitionend",this.onTransitionEnd_),window.addEventListener("resize",this.refresh),c?(this.mutationsObserver_=new MutationObserver(this.refresh),this.mutationsObserver_.observe(document,{attributes:!0,childList:!0,characterData:!0,subtree:!0})):(document.addEventListener("DOMSubtreeModified",this.refresh),this.mutationEventsAdded_=!0),this.connected_=!0)},t.prototype.disconnect_=function(){o&&this.connected_&&(document.removeEventListener("transitionend",this.onTransitionEnd_),window.removeEventListener("resize",this.refresh),this.mutationsObserver_&&this.mutationsObserver_.disconnect(),this.mutationEventsAdded_&&document.removeEventListener("DOMSubtreeModified",this.refresh),this.mutationsObserver_=null,this.mutationEventsAdded_=!1,this.connected_=!1)},t.prototype.onTransitionEnd_=function(t){var e=t.propertyName,n=void 0===e?"":e
a.some((function(t){return!!~n.indexOf(t)}))&&this.refresh()},t.getInstance=function(){return this.instance_||(this.instance_=new t),this.instance_},t.instance_=null,t}(),l=function(t,e){for(var n=0,r=Object.keys(e);n<r.length;n++){var o=r[n]
Object.defineProperty(t,o,{value:e[o],enumerable:!1,writable:!1,configurable:!0})}return t},p=function(t){return t&&t.ownerDocument&&t.ownerDocument.defaultView||i},f=m(0,0,0,0)
function h(t){return parseFloat(t)||0}function d(t){for(var e=[],n=1;n<arguments.length;n++)e[n-1]=arguments[n]
return e.reduce((function(e,n){return e+h(t["border-"+n+"-width"])}),0)}var v="undefined"!=typeof SVGGraphicsElement?function(t){return t instanceof p(t).SVGGraphicsElement}:function(t){return t instanceof p(t).SVGElement&&"function"==typeof t.getBBox}
function m(t,e,n,r){return{x:t,y:e,width:n,height:r}}var _=function(){function t(t){this.broadcastWidth=0,this.broadcastHeight=0,this.contentRect_=m(0,0,0,0),this.target=t}return t.prototype.isActive=function(){var t=function(t){return o?v(t)?function(t){var e=t.getBBox()
return m(0,0,e.width,e.height)}(t):function(t){var e=t.clientWidth,n=t.clientHeight
if(!e&&!n)return f
var r=p(t).getComputedStyle(t),o=function(t){for(var e={},n=0,r=["top","right","bottom","left"];n<r.length;n++){var o=r[n],i=t["padding-"+o]
e[o]=h(i)}return e}(r),i=o.left+o.right,s=o.top+o.bottom,a=h(r.width),c=h(r.height)
if("border-box"===r.boxSizing&&(Math.round(a+i)!==e&&(a-=d(r,"left","right")+i),Math.round(c+s)!==n&&(c-=d(r,"top","bottom")+s)),!function(t){return t===p(t).document.documentElement}(t)){var u=Math.round(a+i)-e,l=Math.round(c+s)-n
1!==Math.abs(u)&&(a-=u),1!==Math.abs(l)&&(c-=l)}return m(o.left,o.top,a,c)}(t):f}(this.target)
return this.contentRect_=t,t.width!==this.broadcastWidth||t.height!==this.broadcastHeight},t.prototype.broadcastRect=function(){var t=this.contentRect_
return this.broadcastWidth=t.width,this.broadcastHeight=t.height,t},t}(),g=function(t,e){var n,r,o,i,s,a,c,u=(r=(n=e).x,o=n.y,i=n.width,s=n.height,a="undefined"!=typeof DOMRectReadOnly?DOMRectReadOnly:Object,c=Object.create(a.prototype),l(c,{x:r,y:o,width:i,height:s,top:o,right:r+i,bottom:s+o,left:r}),c)
l(this,{target:t,contentRect:u})},y=function(){function t(t,e,n){if(this.activeObservations_=[],this.observations_=new r,"function"!=typeof t)throw new TypeError("The callback provided as parameter 1 is not a function.")
this.callback_=t,this.controller_=e,this.callbackCtx_=n}return t.prototype.observe=function(t){if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.")
if("undefined"!=typeof Element&&Element instanceof Object){if(!(t instanceof p(t).Element))throw new TypeError('parameter 1 is not of type "Element".')
var e=this.observations_
e.has(t)||(e.set(t,new _(t)),this.controller_.addObserver(this),this.controller_.refresh())}},t.prototype.unobserve=function(t){if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.")
if("undefined"!=typeof Element&&Element instanceof Object){if(!(t instanceof p(t).Element))throw new TypeError('parameter 1 is not of type "Element".')
var e=this.observations_
e.has(t)&&(e.delete(t),e.size||this.controller_.removeObserver(this))}},t.prototype.disconnect=function(){this.clearActive(),this.observations_.clear(),this.controller_.removeObserver(this)},t.prototype.gatherActive=function(){var t=this
this.clearActive(),this.observations_.forEach((function(e){e.isActive()&&t.activeObservations_.push(e)}))},t.prototype.broadcastActive=function(){if(this.hasActive()){var t=this.callbackCtx_,e=this.activeObservations_.map((function(t){return new g(t.target,t.broadcastRect())}))
this.callback_.call(t,e,t),this.clearActive()}},t.prototype.clearActive=function(){this.activeObservations_.splice(0)},t.prototype.hasActive=function(){return this.activeObservations_.length>0},t}(),b="undefined"!=typeof WeakMap?new WeakMap:new r,w=function t(e){if(!(this instanceof t))throw new TypeError("Cannot call a class as a function.")
if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.")
var n=u.getInstance(),r=new y(e,n,this)
b.set(this,r)};["observe","unobserve","disconnect"].forEach((function(t){w.prototype[t]=function(){var e
return(e=b.get(this))[t].apply(e,arguments)}}))
const E=void 0!==i.ResizeObserver?i.ResizeObserver:w},6504:(t,e,n)=>{"use strict"
function r(t){return"object"==typeof t&&null!=t&&1===t.nodeType}function o(t,e){return(!e||"hidden"!==t)&&"visible"!==t&&"clip"!==t}function i(t,e){if(t.clientHeight<t.scrollHeight||t.clientWidth<t.scrollWidth){var n=getComputedStyle(t,null)
return o(n.overflowY,e)||o(n.overflowX,e)||function(t){var e=function(t){if(!t.ownerDocument||!t.ownerDocument.defaultView)return null
try{return t.ownerDocument.defaultView.frameElement}catch(t){return null}}(t)
return!!e&&(e.clientHeight<t.scrollHeight||e.clientWidth<t.scrollWidth)}(t)}return!1}function s(t,e,n,r,o,i,s,a){return i<t&&s>e||i>t&&s<e?0:i<=t&&a<=n||s>=e&&a>=n?i-t-r:s>e&&a<n||i<t&&a>n?s-e+o:0}function a(t,e){var n=window,o=e.scrollMode,a=e.block,c=e.inline,u=e.boundary,l=e.skipOverflowHiddenElements,p="function"==typeof u?u:function(t){return t!==u}
if(!r(t))throw new TypeError("Invalid target")
for(var f=document.scrollingElement||document.documentElement,h=[],d=t;r(d)&&p(d);){if((d=d.parentElement)===f){h.push(d)
break}null!=d&&d===document.body&&i(d)&&!i(document.documentElement)||null!=d&&i(d,l)&&h.push(d)}for(var v=n.visualViewport?n.visualViewport.width:innerWidth,m=n.visualViewport?n.visualViewport.height:innerHeight,_=window.scrollX||pageXOffset,g=window.scrollY||pageYOffset,y=t.getBoundingClientRect(),b=y.height,w=y.width,E=y.top,S=y.right,x=y.bottom,O=y.left,k="start"===a||"nearest"===a?E:"end"===a?x:E+b/2,T="center"===c?O+w/2:"end"===c?S:O,C=[],j=0;j<h.length;j++){var R=h[j],P=R.getBoundingClientRect(),D=P.height,A=P.width,L=P.top,M=P.right,I=P.bottom,N=P.left
if("if-needed"===o&&E>=0&&O>=0&&x<=m&&S<=v&&E>=L&&x<=I&&O>=N&&S<=M)return C
var F=getComputedStyle(R),U=parseInt(F.borderLeftWidth,10),W=parseInt(F.borderTopWidth,10),H=parseInt(F.borderRightWidth,10),B=parseInt(F.borderBottomWidth,10),q=0,z=0,Z="offsetWidth"in R?R.offsetWidth-R.clientWidth-U-H:0,V="offsetHeight"in R?R.offsetHeight-R.clientHeight-W-B:0
if(f===R)q="start"===a?k:"end"===a?k-m:"nearest"===a?s(g,g+m,m,W,B,g+k,g+k+b,b):k-m/2,z="start"===c?T:"center"===c?T-v/2:"end"===c?T-v:s(_,_+v,v,U,H,_+T,_+T+w,w),q=Math.max(0,q+g),z=Math.max(0,z+_)
else{q="start"===a?k-L-W:"end"===a?k-I+B+V:"nearest"===a?s(L,I,D,W,B+V,k,k+b,b):k-(L+D/2)+V/2,z="start"===c?T-N-U:"center"===c?T-(N+A/2)+Z/2:"end"===c?T-M+H+Z:s(N,M,A,U,H+Z,T,T+w,w)
var G=R.scrollLeft,J=R.scrollTop
k+=J-(q=Math.max(0,Math.min(J+q,R.scrollHeight-D+V))),T+=G-(z=Math.max(0,Math.min(G+z,R.scrollWidth-A+Z)))}C.push({el:R,top:q,left:z})}return C}function c(t){return t===Object(t)&&0!==Object.keys(t).length}n.r(e),n.d(e,{default:()=>u})
const u=function(t,e){var n=!t.ownerDocument.documentElement.contains(t)
if(c(e)&&"function"==typeof e.behavior)return e.behavior(n?[]:a(t,e))
if(!n){var r=function(t){return!1===t?{block:"end",inline:"nearest"}:c(t)?t:{block:"start",inline:"nearest"}}(e)
return function(t,e){void 0===e&&(e="auto")
var n="scrollBehavior"in document.body.style
t.forEach((function(t){var r=t.el,o=t.top,i=t.left
r.scroll&&n?r.scroll({top:o,left:i,behavior:e}):(r.scrollTop=o,r.scrollLeft=i)}))}(a(t,r),r.behavior)}}},9628:t=>{var e=["Shift","Meta","Alt","Control"],n="object"==typeof navigator&&/Mac|iPod|iPhone|iPad/.test(navigator.platform)?"Meta":"Control"
t.exports=function(t,r,o){var i,s
void 0===o&&(o={})
var a=null!=(i=o.timeout)?i:1e3,c=null!=(s=o.event)?s:"keydown",u=Object.keys(r).map((function(t){return[(e=t,e.trim().split(" ").map((function(t){var e=t.split(/\b\+/),r=e.pop()
return[e=e.map((function(t){return"$mod"===t?n:t})),r]}))),r[t]]
var e})),l=new Map,p=null,f=function(t){t instanceof KeyboardEvent&&(u.forEach((function(n){var r=n[0],o=n[1],i=l.get(r)||r
!function(t,n){return!(n[1].toUpperCase()!==t.key.toUpperCase()&&n[1]!==t.code||n[0].find((function(e){return!t.getModifierState(e)}))||e.find((function(e){return!n[0].includes(e)&&n[1]!==e&&t.getModifierState(e)})))}(t,i[0])?t.getModifierState(t.key)||l.delete(r):i.length>1?l.set(r,i.slice(1)):(l.delete(r),o(t))})),p&&clearTimeout(p),p=setTimeout(l.clear.bind(l),a))}
return t.addEventListener(c,f),function(){t.removeEventListener(c,f)}}},1873:(t,e,n)=>{"use strict"
function r(t){if(null==t)return window
if("[object Window]"!==t.toString()){var e=t.ownerDocument
return e&&e.defaultView||window}return t}function o(t){return t instanceof r(t).Element||t instanceof Element}function i(t){return t instanceof r(t).HTMLElement||t instanceof HTMLElement}function s(t){return"undefined"!=typeof ShadowRoot&&(t instanceof r(t).ShadowRoot||t instanceof ShadowRoot)}n.r(e),n.d(e,{animateFill:()=>ie,createSingleton:()=>ne,default:()=>he,delegate:()=>oe,followCursor:()=>ue,hideAll:()=>te,inlinePositioning:()=>le,roundArrow:()=>ut,sticky:()=>pe})
var a=Math.max,c=Math.min,u=Math.round
function l(t,e){void 0===e&&(e=!1)
var n=t.getBoundingClientRect(),r=1,o=1
if(i(t)&&e){var s=t.offsetHeight,a=t.offsetWidth
a>0&&(r=u(n.width)/a||1),s>0&&(o=u(n.height)/s||1)}return{width:n.width/r,height:n.height/o,top:n.top/o,right:n.right/r,bottom:n.bottom/o,left:n.left/r,x:n.left/r,y:n.top/o}}function p(t){var e=r(t)
return{scrollLeft:e.pageXOffset,scrollTop:e.pageYOffset}}function f(t){return t?(t.nodeName||"").toLowerCase():null}function h(t){return((o(t)?t.ownerDocument:t.document)||window.document).documentElement}function d(t){return l(h(t)).left+p(t).scrollLeft}function v(t){return r(t).getComputedStyle(t)}function m(t){var e=v(t),n=e.overflow,r=e.overflowX,o=e.overflowY
return/auto|scroll|overlay|hidden/.test(n+o+r)}function _(t,e,n){void 0===n&&(n=!1)
var o,s,a=i(e),c=i(e)&&function(t){var e=t.getBoundingClientRect(),n=u(e.width)/t.offsetWidth||1,r=u(e.height)/t.offsetHeight||1
return 1!==n||1!==r}(e),v=h(e),_=l(t,c),g={scrollLeft:0,scrollTop:0},y={x:0,y:0}
return(a||!a&&!n)&&(("body"!==f(e)||m(v))&&(g=(o=e)!==r(o)&&i(o)?{scrollLeft:(s=o).scrollLeft,scrollTop:s.scrollTop}:p(o)),i(e)?((y=l(e,!0)).x+=e.clientLeft,y.y+=e.clientTop):v&&(y.x=d(v))),{x:_.left+g.scrollLeft-y.x,y:_.top+g.scrollTop-y.y,width:_.width,height:_.height}}function g(t){var e=l(t),n=t.offsetWidth,r=t.offsetHeight
return Math.abs(e.width-n)<=1&&(n=e.width),Math.abs(e.height-r)<=1&&(r=e.height),{x:t.offsetLeft,y:t.offsetTop,width:n,height:r}}function y(t){return"html"===f(t)?t:t.assignedSlot||t.parentNode||(s(t)?t.host:null)||h(t)}function b(t){return["html","body","#document"].indexOf(f(t))>=0?t.ownerDocument.body:i(t)&&m(t)?t:b(y(t))}function w(t,e){var n
void 0===e&&(e=[])
var o=b(t),i=o===(null==(n=t.ownerDocument)?void 0:n.body),s=r(o),a=i?[s].concat(s.visualViewport||[],m(o)?o:[]):o,c=e.concat(a)
return i?c:c.concat(w(y(a)))}function E(t){return["table","td","th"].indexOf(f(t))>=0}function S(t){return i(t)&&"fixed"!==v(t).position?t.offsetParent:null}function x(t){for(var e=r(t),n=S(t);n&&E(n)&&"static"===v(n).position;)n=S(n)
return n&&("html"===f(n)||"body"===f(n)&&"static"===v(n).position)?e:n||function(t){var e=-1!==navigator.userAgent.toLowerCase().indexOf("firefox")
if(-1!==navigator.userAgent.indexOf("Trident")&&i(t)&&"fixed"===v(t).position)return null
for(var n=y(t);i(n)&&["html","body"].indexOf(f(n))<0;){var r=v(n)
if("none"!==r.transform||"none"!==r.perspective||"paint"===r.contain||-1!==["transform","perspective"].indexOf(r.willChange)||e&&"filter"===r.willChange||e&&r.filter&&"none"!==r.filter)return n
n=n.parentNode}return null}(t)||e}var O="top",k="bottom",T="right",C="left",j="auto",R=[O,k,T,C],P="start",D="end",A="viewport",L="popper",M=R.reduce((function(t,e){return t.concat([e+"-"+P,e+"-"+D])}),[]),I=[].concat(R,[j]).reduce((function(t,e){return t.concat([e,e+"-"+P,e+"-"+D])}),[]),N=["beforeRead","read","afterRead","beforeMain","main","afterMain","beforeWrite","write","afterWrite"]
function F(t){var e=new Map,n=new Set,r=[]
function o(t){n.add(t.name),[].concat(t.requires||[],t.requiresIfExists||[]).forEach((function(t){if(!n.has(t)){var r=e.get(t)
r&&o(r)}})),r.push(t)}return t.forEach((function(t){e.set(t.name,t)})),t.forEach((function(t){n.has(t.name)||o(t)})),r}var U={placement:"bottom",modifiers:[],strategy:"absolute"}
function W(){for(var t=arguments.length,e=new Array(t),n=0;n<t;n++)e[n]=arguments[n]
return!e.some((function(t){return!(t&&"function"==typeof t.getBoundingClientRect)}))}var H={passive:!0}
function B(t){return t.split("-")[0]}function q(t){return t.split("-")[1]}function z(t){return["top","bottom"].indexOf(t)>=0?"x":"y"}function Z(t){var e,n=t.reference,r=t.element,o=t.placement,i=o?B(o):null,s=o?q(o):null,a=n.x+n.width/2-r.width/2,c=n.y+n.height/2-r.height/2
switch(i){case O:e={x:a,y:n.y-r.height}
break
case k:e={x:a,y:n.y+n.height}
break
case T:e={x:n.x+n.width,y:c}
break
case C:e={x:n.x-r.width,y:c}
break
default:e={x:n.x,y:n.y}}var u=i?z(i):null
if(null!=u){var l="y"===u?"height":"width"
switch(s){case P:e[u]=e[u]-(n[l]/2-r[l]/2)
break
case D:e[u]=e[u]+(n[l]/2-r[l]/2)}}return e}var V={top:"auto",right:"auto",bottom:"auto",left:"auto"}
function G(t){var e,n=t.popper,o=t.popperRect,i=t.placement,s=t.variation,a=t.offsets,c=t.position,l=t.gpuAcceleration,p=t.adaptive,f=t.roundOffsets,d=t.isFixed,m=a.x,_=void 0===m?0:m,g=a.y,y=void 0===g?0:g,b="function"==typeof f?f({x:_,y:y}):{x:_,y:y}
_=b.x,y=b.y
var w=a.hasOwnProperty("x"),E=a.hasOwnProperty("y"),S=C,j=O,R=window
if(p){var P=x(n),A="clientHeight",L="clientWidth"
P===r(n)&&"static"!==v(P=h(n)).position&&"absolute"===c&&(A="scrollHeight",L="scrollWidth"),P=P,(i===O||(i===C||i===T)&&s===D)&&(j=k,y-=(d&&R.visualViewport?R.visualViewport.height:P[A])-o.height,y*=l?1:-1),i!==C&&(i!==O&&i!==k||s!==D)||(S=T,_-=(d&&R.visualViewport?R.visualViewport.width:P[L])-o.width,_*=l?1:-1)}var M,I=Object.assign({position:c},p&&V),N=!0===f?function(t){var e=t.x,n=t.y,r=window.devicePixelRatio||1
return{x:u(e*r)/r||0,y:u(n*r)/r||0}}({x:_,y:y}):{x:_,y:y}
return _=N.x,y=N.y,l?Object.assign({},I,((M={})[j]=E?"0":"",M[S]=w?"0":"",M.transform=(R.devicePixelRatio||1)<=1?"translate("+_+"px, "+y+"px)":"translate3d("+_+"px, "+y+"px, 0)",M)):Object.assign({},I,((e={})[j]=E?y+"px":"",e[S]=w?_+"px":"",e.transform="",e))}const J={name:"applyStyles",enabled:!0,phase:"write",fn:function(t){var e=t.state
Object.keys(e.elements).forEach((function(t){var n=e.styles[t]||{},r=e.attributes[t]||{},o=e.elements[t]
i(o)&&f(o)&&(Object.assign(o.style,n),Object.keys(r).forEach((function(t){var e=r[t]
!1===e?o.removeAttribute(t):o.setAttribute(t,!0===e?"":e)})))}))},effect:function(t){var e=t.state,n={popper:{position:e.options.strategy,left:"0",top:"0",margin:"0"},arrow:{position:"absolute"},reference:{}}
return Object.assign(e.elements.popper.style,n.popper),e.styles=n,e.elements.arrow&&Object.assign(e.elements.arrow.style,n.arrow),function(){Object.keys(e.elements).forEach((function(t){var r=e.elements[t],o=e.attributes[t]||{},s=Object.keys(e.styles.hasOwnProperty(t)?e.styles[t]:n[t]).reduce((function(t,e){return t[e]="",t}),{})
i(r)&&f(r)&&(Object.assign(r.style,s),Object.keys(o).forEach((function(t){r.removeAttribute(t)})))}))}},requires:["computeStyles"]}
var $={left:"right",right:"left",bottom:"top",top:"bottom"}
function Y(t){return t.replace(/left|right|bottom|top/g,(function(t){return $[t]}))}var K={start:"end",end:"start"}
function X(t){return t.replace(/start|end/g,(function(t){return K[t]}))}function Q(t,e){var n=e.getRootNode&&e.getRootNode()
if(t.contains(e))return!0
if(n&&s(n)){var r=e
do{if(r&&t.isSameNode(r))return!0
r=r.parentNode||r.host}while(r)}return!1}function tt(t){return Object.assign({},t,{left:t.x,top:t.y,right:t.x+t.width,bottom:t.y+t.height})}function et(t,e){return e===A?tt(function(t){var e=r(t),n=h(t),o=e.visualViewport,i=n.clientWidth,s=n.clientHeight,a=0,c=0
return o&&(i=o.width,s=o.height,/^((?!chrome|android).)*safari/i.test(navigator.userAgent)||(a=o.offsetLeft,c=o.offsetTop)),{width:i,height:s,x:a+d(t),y:c}}(t)):o(e)?function(t){var e=l(t)
return e.top=e.top+t.clientTop,e.left=e.left+t.clientLeft,e.bottom=e.top+t.clientHeight,e.right=e.left+t.clientWidth,e.width=t.clientWidth,e.height=t.clientHeight,e.x=e.left,e.y=e.top,e}(e):tt(function(t){var e,n=h(t),r=p(t),o=null==(e=t.ownerDocument)?void 0:e.body,i=a(n.scrollWidth,n.clientWidth,o?o.scrollWidth:0,o?o.clientWidth:0),s=a(n.scrollHeight,n.clientHeight,o?o.scrollHeight:0,o?o.clientHeight:0),c=-r.scrollLeft+d(t),u=-r.scrollTop
return"rtl"===v(o||n).direction&&(c+=a(n.clientWidth,o?o.clientWidth:0)-i),{width:i,height:s,x:c,y:u}}(h(t)))}function nt(t){return Object.assign({},{top:0,right:0,bottom:0,left:0},t)}function rt(t,e){return e.reduce((function(e,n){return e[n]=t,e}),{})}function ot(t,e){void 0===e&&(e={})
var n=e,r=n.placement,s=void 0===r?t.placement:r,u=n.boundary,p=void 0===u?"clippingParents":u,d=n.rootBoundary,m=void 0===d?A:d,_=n.elementContext,g=void 0===_?L:_,b=n.altBoundary,E=void 0!==b&&b,S=n.padding,C=void 0===S?0:S,j=nt("number"!=typeof C?C:rt(C,R)),P=g===L?"reference":L,D=t.rects.popper,M=t.elements[E?P:g],I=function(t,e,n){var r="clippingParents"===e?function(t){var e=w(y(t)),n=["absolute","fixed"].indexOf(v(t).position)>=0&&i(t)?x(t):t
return o(n)?e.filter((function(t){return o(t)&&Q(t,n)&&"body"!==f(t)})):[]}(t):[].concat(e),s=[].concat(r,[n]),u=s[0],l=s.reduce((function(e,n){var r=et(t,n)
return e.top=a(r.top,e.top),e.right=c(r.right,e.right),e.bottom=c(r.bottom,e.bottom),e.left=a(r.left,e.left),e}),et(t,u))
return l.width=l.right-l.left,l.height=l.bottom-l.top,l.x=l.left,l.y=l.top,l}(o(M)?M:M.contextElement||h(t.elements.popper),p,m),N=l(t.elements.reference),F=Z({reference:N,element:D,strategy:"absolute",placement:s}),U=tt(Object.assign({},D,F)),W=g===L?U:N,H={top:I.top-W.top+j.top,bottom:W.bottom-I.bottom+j.bottom,left:I.left-W.left+j.left,right:W.right-I.right+j.right},B=t.modifiersData.offset
if(g===L&&B){var q=B[s]
Object.keys(H).forEach((function(t){var e=[T,k].indexOf(t)>=0?1:-1,n=[O,k].indexOf(t)>=0?"y":"x"
H[t]+=q[n]*e}))}return H}function it(t,e,n){return a(t,c(e,n))}function st(t,e,n){return void 0===n&&(n={x:0,y:0}),{top:t.top-e.height-n.y,right:t.right-e.width+n.x,bottom:t.bottom-e.height+n.y,left:t.left-e.width-n.x}}function at(t){return[O,T,k,C].some((function(e){return t[e]>=0}))}var ct=function(t){void 0===t&&(t={})
var e=t,n=e.defaultModifiers,r=void 0===n?[]:n,i=e.defaultOptions,s=void 0===i?U:i
return function(t,e,n){void 0===n&&(n=s)
var i,a,c={placement:"bottom",orderedModifiers:[],options:Object.assign({},U,s),modifiersData:{},elements:{reference:t,popper:e},attributes:{},styles:{}},u=[],l=!1,p={state:c,setOptions:function(n){var i="function"==typeof n?n(c.options):n
f(),c.options=Object.assign({},s,c.options,i),c.scrollParents={reference:o(t)?w(t):t.contextElement?w(t.contextElement):[],popper:w(e)}
var a,l,h=function(t){var e=F(t)
return N.reduce((function(t,n){return t.concat(e.filter((function(t){return t.phase===n})))}),[])}((a=[].concat(r,c.options.modifiers),l=a.reduce((function(t,e){var n=t[e.name]
return t[e.name]=n?Object.assign({},n,e,{options:Object.assign({},n.options,e.options),data:Object.assign({},n.data,e.data)}):e,t}),{}),Object.keys(l).map((function(t){return l[t]}))))
return c.orderedModifiers=h.filter((function(t){return t.enabled})),c.orderedModifiers.forEach((function(t){var e=t.name,n=t.options,r=void 0===n?{}:n,o=t.effect
if("function"==typeof o){var i=o({state:c,name:e,instance:p,options:r})
u.push(i||function(){})}})),p.update()},forceUpdate:function(){if(!l){var t=c.elements,e=t.reference,n=t.popper
if(W(e,n)){c.rects={reference:_(e,x(n),"fixed"===c.options.strategy),popper:g(n)},c.reset=!1,c.placement=c.options.placement,c.orderedModifiers.forEach((function(t){return c.modifiersData[t.name]=Object.assign({},t.data)}))
for(var r=0;r<c.orderedModifiers.length;r++)if(!0!==c.reset){var o=c.orderedModifiers[r],i=o.fn,s=o.options,a=void 0===s?{}:s,u=o.name
"function"==typeof i&&(c=i({state:c,options:a,name:u,instance:p})||c)}else c.reset=!1,r=-1}}},update:(i=function(){return new Promise((function(t){p.forceUpdate(),t(c)}))},function(){return a||(a=new Promise((function(t){Promise.resolve().then((function(){a=void 0,t(i())}))}))),a}),destroy:function(){f(),l=!0}}
if(!W(t,e))return p
function f(){u.forEach((function(t){return t()})),u=[]}return p.setOptions(n).then((function(t){!l&&n.onFirstUpdate&&n.onFirstUpdate(t)})),p}}({defaultModifiers:[{name:"eventListeners",enabled:!0,phase:"write",fn:function(){},effect:function(t){var e=t.state,n=t.instance,o=t.options,i=o.scroll,s=void 0===i||i,a=o.resize,c=void 0===a||a,u=r(e.elements.popper),l=[].concat(e.scrollParents.reference,e.scrollParents.popper)
return s&&l.forEach((function(t){t.addEventListener("scroll",n.update,H)})),c&&u.addEventListener("resize",n.update,H),function(){s&&l.forEach((function(t){t.removeEventListener("scroll",n.update,H)})),c&&u.removeEventListener("resize",n.update,H)}},data:{}},{name:"popperOffsets",enabled:!0,phase:"read",fn:function(t){var e=t.state,n=t.name
e.modifiersData[n]=Z({reference:e.rects.reference,element:e.rects.popper,strategy:"absolute",placement:e.placement})},data:{}},{name:"computeStyles",enabled:!0,phase:"beforeWrite",fn:function(t){var e=t.state,n=t.options,r=n.gpuAcceleration,o=void 0===r||r,i=n.adaptive,s=void 0===i||i,a=n.roundOffsets,c=void 0===a||a,u={placement:B(e.placement),variation:q(e.placement),popper:e.elements.popper,popperRect:e.rects.popper,gpuAcceleration:o,isFixed:"fixed"===e.options.strategy}
null!=e.modifiersData.popperOffsets&&(e.styles.popper=Object.assign({},e.styles.popper,G(Object.assign({},u,{offsets:e.modifiersData.popperOffsets,position:e.options.strategy,adaptive:s,roundOffsets:c})))),null!=e.modifiersData.arrow&&(e.styles.arrow=Object.assign({},e.styles.arrow,G(Object.assign({},u,{offsets:e.modifiersData.arrow,position:"absolute",adaptive:!1,roundOffsets:c})))),e.attributes.popper=Object.assign({},e.attributes.popper,{"data-popper-placement":e.placement})},data:{}},J,{name:"offset",enabled:!0,phase:"main",requires:["popperOffsets"],fn:function(t){var e=t.state,n=t.options,r=t.name,o=n.offset,i=void 0===o?[0,0]:o,s=I.reduce((function(t,n){return t[n]=function(t,e,n){var r=B(t),o=[C,O].indexOf(r)>=0?-1:1,i="function"==typeof n?n(Object.assign({},e,{placement:t})):n,s=i[0],a=i[1]
return s=s||0,a=(a||0)*o,[C,T].indexOf(r)>=0?{x:a,y:s}:{x:s,y:a}}(n,e.rects,i),t}),{}),a=s[e.placement],c=a.x,u=a.y
null!=e.modifiersData.popperOffsets&&(e.modifiersData.popperOffsets.x+=c,e.modifiersData.popperOffsets.y+=u),e.modifiersData[r]=s}},{name:"flip",enabled:!0,phase:"main",fn:function(t){var e=t.state,n=t.options,r=t.name
if(!e.modifiersData[r]._skip){for(var o=n.mainAxis,i=void 0===o||o,s=n.altAxis,a=void 0===s||s,c=n.fallbackPlacements,u=n.padding,l=n.boundary,p=n.rootBoundary,f=n.altBoundary,h=n.flipVariations,d=void 0===h||h,v=n.allowedAutoPlacements,m=e.options.placement,_=B(m),g=c||(_!==m&&d?function(t){if(B(t)===j)return[]
var e=Y(t)
return[X(t),e,X(e)]}(m):[Y(m)]),y=[m].concat(g).reduce((function(t,n){return t.concat(B(n)===j?function(t,e){void 0===e&&(e={})
var n=e,r=n.placement,o=n.boundary,i=n.rootBoundary,s=n.padding,a=n.flipVariations,c=n.allowedAutoPlacements,u=void 0===c?I:c,l=q(r),p=l?a?M:M.filter((function(t){return q(t)===l})):R,f=p.filter((function(t){return u.indexOf(t)>=0}))
0===f.length&&(f=p)
var h=f.reduce((function(e,n){return e[n]=ot(t,{placement:n,boundary:o,rootBoundary:i,padding:s})[B(n)],e}),{})
return Object.keys(h).sort((function(t,e){return h[t]-h[e]}))}(e,{placement:n,boundary:l,rootBoundary:p,padding:u,flipVariations:d,allowedAutoPlacements:v}):n)}),[]),b=e.rects.reference,w=e.rects.popper,E=new Map,S=!0,x=y[0],D=0;D<y.length;D++){var A=y[D],L=B(A),N=q(A)===P,F=[O,k].indexOf(L)>=0,U=F?"width":"height",W=ot(e,{placement:A,boundary:l,rootBoundary:p,altBoundary:f,padding:u}),H=F?N?T:C:N?k:O
b[U]>w[U]&&(H=Y(H))
var z=Y(H),Z=[]
if(i&&Z.push(W[L]<=0),a&&Z.push(W[H]<=0,W[z]<=0),Z.every((function(t){return t}))){x=A,S=!1
break}E.set(A,Z)}if(S)for(var V=function(t){var e=y.find((function(e){var n=E.get(e)
if(n)return n.slice(0,t).every((function(t){return t}))}))
if(e)return x=e,"break"},G=d?3:1;G>0&&"break"!==V(G);G--);e.placement!==x&&(e.modifiersData[r]._skip=!0,e.placement=x,e.reset=!0)}},requiresIfExists:["offset"],data:{_skip:!1}},{name:"preventOverflow",enabled:!0,phase:"main",fn:function(t){var e=t.state,n=t.options,r=t.name,o=n.mainAxis,i=void 0===o||o,s=n.altAxis,u=void 0!==s&&s,l=n.boundary,p=n.rootBoundary,f=n.altBoundary,h=n.padding,d=n.tether,v=void 0===d||d,m=n.tetherOffset,_=void 0===m?0:m,y=ot(e,{boundary:l,rootBoundary:p,padding:h,altBoundary:f}),b=B(e.placement),w=q(e.placement),E=!w,S=z(b),j="x"===S?"y":"x",R=e.modifiersData.popperOffsets,D=e.rects.reference,A=e.rects.popper,L="function"==typeof _?_(Object.assign({},e.rects,{placement:e.placement})):_,M="number"==typeof L?{mainAxis:L,altAxis:L}:Object.assign({mainAxis:0,altAxis:0},L),I=e.modifiersData.offset?e.modifiersData.offset[e.placement]:null,N={x:0,y:0}
if(R){if(i){var F,U="y"===S?O:C,W="y"===S?k:T,H="y"===S?"height":"width",Z=R[S],V=Z+y[U],G=Z-y[W],J=v?-A[H]/2:0,$=w===P?D[H]:A[H],Y=w===P?-A[H]:-D[H],K=e.elements.arrow,X=v&&K?g(K):{width:0,height:0},Q=e.modifiersData["arrow#persistent"]?e.modifiersData["arrow#persistent"].padding:{top:0,right:0,bottom:0,left:0},tt=Q[U],et=Q[W],nt=it(0,D[H],X[H]),rt=E?D[H]/2-J-nt-tt-M.mainAxis:$-nt-tt-M.mainAxis,st=E?-D[H]/2+J+nt+et+M.mainAxis:Y+nt+et+M.mainAxis,at=e.elements.arrow&&x(e.elements.arrow),ct=at?"y"===S?at.clientTop||0:at.clientLeft||0:0,ut=null!=(F=null==I?void 0:I[S])?F:0,lt=Z+st-ut,pt=it(v?c(V,Z+rt-ut-ct):V,Z,v?a(G,lt):G)
R[S]=pt,N[S]=pt-Z}if(u){var ft,ht="x"===S?O:C,dt="x"===S?k:T,vt=R[j],mt="y"===j?"height":"width",_t=vt+y[ht],gt=vt-y[dt],yt=-1!==[O,C].indexOf(b),bt=null!=(ft=null==I?void 0:I[j])?ft:0,wt=yt?_t:vt-D[mt]-A[mt]-bt+M.altAxis,Et=yt?vt+D[mt]+A[mt]-bt-M.altAxis:gt,St=v&&yt?function(t,e,n){var r=it(t,e,n)
return r>n?n:r}(wt,vt,Et):it(v?wt:_t,vt,v?Et:gt)
R[j]=St,N[j]=St-vt}e.modifiersData[r]=N}},requiresIfExists:["offset"]},{name:"arrow",enabled:!0,phase:"main",fn:function(t){var e,n=t.state,r=t.name,o=t.options,i=n.elements.arrow,s=n.modifiersData.popperOffsets,a=B(n.placement),c=z(a),u=[C,T].indexOf(a)>=0?"height":"width"
if(i&&s){var l=function(t,e){return nt("number"!=typeof(t="function"==typeof t?t(Object.assign({},e.rects,{placement:e.placement})):t)?t:rt(t,R))}(o.padding,n),p=g(i),f="y"===c?O:C,h="y"===c?k:T,d=n.rects.reference[u]+n.rects.reference[c]-s[c]-n.rects.popper[u],v=s[c]-n.rects.reference[c],m=x(i),_=m?"y"===c?m.clientHeight||0:m.clientWidth||0:0,y=d/2-v/2,b=l[f],w=_-p[u]-l[h],E=_/2-p[u]/2+y,S=it(b,E,w),j=c
n.modifiersData[r]=((e={})[j]=S,e.centerOffset=S-E,e)}},effect:function(t){var e=t.state,n=t.options.element,r=void 0===n?"[data-popper-arrow]":n
null!=r&&("string"!=typeof r||(r=e.elements.popper.querySelector(r)))&&Q(e.elements.popper,r)&&(e.elements.arrow=r)},requires:["popperOffsets"],requiresIfExists:["preventOverflow"]},{name:"hide",enabled:!0,phase:"main",requiresIfExists:["preventOverflow"],fn:function(t){var e=t.state,n=t.name,r=e.rects.reference,o=e.rects.popper,i=e.modifiersData.preventOverflow,s=ot(e,{elementContext:"reference"}),a=ot(e,{altBoundary:!0}),c=st(s,r),u=st(a,o,i),l=at(c),p=at(u)
e.modifiersData[n]={referenceClippingOffsets:c,popperEscapeOffsets:u,isReferenceHidden:l,hasPopperEscaped:p},e.attributes.popper=Object.assign({},e.attributes.popper,{"data-popper-reference-hidden":l,"data-popper-escaped":p})}}]}),ut='<svg width="16" height="6" xmlns="http://www.w3.org/2000/svg"><path d="M0 6s1.796-.013 4.67-3.615C5.851.9 6.93.006 8 0c1.07-.006 2.148.887 3.343 2.385C14.233 6.005 16 6 16 6H0z"></svg>',lt="tippy-content",pt="tippy-backdrop",ft="tippy-arrow",ht="tippy-svg-arrow",dt={passive:!0,capture:!0},vt=function(){return document.body}
function mt(t,e,n){if(Array.isArray(t)){var r=t[e]
return null==r?Array.isArray(n)?n[e]:n:r}return t}function _t(t,e){var n={}.toString.call(t)
return 0===n.indexOf("[object")&&n.indexOf(e+"]")>-1}function gt(t,e){return"function"==typeof t?t.apply(void 0,e):t}function yt(t,e){return 0===e?t:function(r){clearTimeout(n),n=setTimeout((function(){t(r)}),e)}
var n}function bt(t,e){var n=Object.assign({},t)
return e.forEach((function(t){delete n[t]})),n}function wt(t){return[].concat(t)}function Et(t,e){-1===t.indexOf(e)&&t.push(e)}function St(t){return t.split("-")[0]}function xt(t){return[].slice.call(t)}function Ot(t){return Object.keys(t).reduce((function(e,n){return void 0!==t[n]&&(e[n]=t[n]),e}),{})}function kt(){return document.createElement("div")}function Tt(t){return["Element","Fragment"].some((function(e){return _t(t,e)}))}function Ct(t){return _t(t,"MouseEvent")}function jt(t){return!(!t||!t._tippy||t._tippy.reference!==t)}function Rt(t,e){t.forEach((function(t){t&&(t.style.transitionDuration=e+"ms")}))}function Pt(t,e){t.forEach((function(t){t&&t.setAttribute("data-state",e)}))}function Dt(t){var e,n=wt(t)[0]
return null!=n&&null!=(e=n.ownerDocument)&&e.body?n.ownerDocument:document}function At(t,e,n){var r=e+"EventListener";["transitionend","webkitTransitionEnd"].forEach((function(e){t[r](e,n)}))}function Lt(t,e){for(var n=e;n;){var r
if(t.contains(n))return!0
n=null==n.getRootNode||null==(r=n.getRootNode())?void 0:r.host}return!1}var Mt={isTouch:!1},It=0
function Nt(){Mt.isTouch||(Mt.isTouch=!0,window.performance&&document.addEventListener("mousemove",Ft))}function Ft(){var t=performance.now()
t-It<20&&(Mt.isTouch=!1,document.removeEventListener("mousemove",Ft)),It=t}function Ut(){var t=document.activeElement
if(jt(t)){var e=t._tippy
t.blur&&!e.state.isVisible&&t.blur()}}var Wt=!("undefined"==typeof window||"undefined"==typeof document||!window.msCrypto),Ht=Object.assign({appendTo:vt,aria:{content:"auto",expanded:"auto"},delay:0,duration:[300,250],getReferenceClientRect:null,hideOnClick:!0,ignoreAttributes:!1,interactive:!1,interactiveBorder:2,interactiveDebounce:0,moveTransition:"",offset:[0,10],onAfterUpdate:function(){},onBeforeUpdate:function(){},onCreate:function(){},onDestroy:function(){},onHidden:function(){},onHide:function(){},onMount:function(){},onShow:function(){},onShown:function(){},onTrigger:function(){},onUntrigger:function(){},onClickOutside:function(){},placement:"top",plugins:[],popperOptions:{},render:null,showOnCreate:!1,touch:!0,trigger:"mouseenter focus",triggerTarget:null},{animateFill:!1,followCursor:!1,inlinePositioning:!1,sticky:!1},{allowHTML:!1,animation:"fade",arrow:!0,content:"",inertia:!1,maxWidth:350,role:"tooltip",theme:"",zIndex:9999}),Bt=Object.keys(Ht)
function qt(t){var e=(t.plugins||[]).reduce((function(e,n){var r,o=n.name,i=n.defaultValue
return o&&(e[o]=void 0!==t[o]?t[o]:null!=(r=Ht[o])?r:i),e}),{})
return Object.assign({},t,e)}function zt(t,e){var n=Object.assign({},e,{content:gt(e.content,[t])},e.ignoreAttributes?{}:function(t,e){return(e?Object.keys(qt(Object.assign({},Ht,{plugins:e}))):Bt).reduce((function(e,n){var r=(t.getAttribute("data-tippy-"+n)||"").trim()
if(!r)return e
if("content"===n)e[n]=r
else try{e[n]=JSON.parse(r)}catch(t){e[n]=r}return e}),{})}(t,e.plugins))
return n.aria=Object.assign({},Ht.aria,n.aria),n.aria={expanded:"auto"===n.aria.expanded?e.interactive:n.aria.expanded,content:"auto"===n.aria.content?e.interactive?null:"describedby":n.aria.content},n}function Zt(t,e){t.innerHTML=e}function Vt(t){var e=kt()
return!0===t?e.className=ft:(e.className=ht,Tt(t)?e.appendChild(t):Zt(e,t)),e}function Gt(t,e){Tt(e.content)?(Zt(t,""),t.appendChild(e.content)):"function"!=typeof e.content&&(e.allowHTML?Zt(t,e.content):t.textContent=e.content)}function Jt(t){var e=t.firstElementChild,n=xt(e.children)
return{box:e,content:n.find((function(t){return t.classList.contains(lt)})),arrow:n.find((function(t){return t.classList.contains(ft)||t.classList.contains(ht)})),backdrop:n.find((function(t){return t.classList.contains(pt)}))}}function $t(t){var e=kt(),n=kt()
n.className="tippy-box",n.setAttribute("data-state","hidden"),n.setAttribute("tabindex","-1")
var r=kt()
function o(n,r){var o=Jt(e),i=o.box,s=o.content,a=o.arrow
r.theme?i.setAttribute("data-theme",r.theme):i.removeAttribute("data-theme"),"string"==typeof r.animation?i.setAttribute("data-animation",r.animation):i.removeAttribute("data-animation"),r.inertia?i.setAttribute("data-inertia",""):i.removeAttribute("data-inertia"),i.style.maxWidth="number"==typeof r.maxWidth?r.maxWidth+"px":r.maxWidth,r.role?i.setAttribute("role",r.role):i.removeAttribute("role"),n.content===r.content&&n.allowHTML===r.allowHTML||Gt(s,t.props),r.arrow?a?n.arrow!==r.arrow&&(i.removeChild(a),i.appendChild(Vt(r.arrow))):i.appendChild(Vt(r.arrow)):a&&i.removeChild(a)}return r.className=lt,r.setAttribute("data-state","hidden"),Gt(r,t.props),e.appendChild(n),n.appendChild(r),o(t.props,t.props),{popper:e,onUpdate:o}}$t.$$tippy=!0
var Yt=1,Kt=[],Xt=[]
function Qt(t,e){void 0===e&&(e={})
var n=Ht.plugins.concat(e.plugins||[])
document.addEventListener("touchstart",Nt,dt),window.addEventListener("blur",Ut)
var r,o=Object.assign({},e,{plugins:n}),i=(r=t,Tt(r)?[r]:function(t){return _t(t,"NodeList")}(r)?xt(r):Array.isArray(r)?r:xt(document.querySelectorAll(r))).reduce((function(t,e){var n=e&&function(t,e){var n,r,o,i,s,a,c,u,l=zt(t,Object.assign({},Ht,qt(Ot(e)))),p=!1,f=!1,h=!1,d=!1,v=[],m=yt(G,l.interactiveDebounce),_=Yt++,g=(u=l.plugins).filter((function(t,e){return u.indexOf(t)===e})),y={id:_,reference:t,popper:kt(),popperInstance:null,props:l,state:{isEnabled:!0,isVisible:!1,isDestroyed:!1,isMounted:!1,isShown:!1},plugins:g,clearDelayTimeouts:function(){clearTimeout(n),clearTimeout(r),cancelAnimationFrame(o)},setProps:function(e){if(!y.state.isDestroyed){A("onBeforeUpdate",[y,e]),Z()
var n=y.props,r=zt(t,Object.assign({},n,Ot(e),{ignoreAttributes:!0}))
y.props=r,z(),n.interactiveDebounce!==r.interactiveDebounce&&(I(),m=yt(G,r.interactiveDebounce)),n.triggerTarget&&!r.triggerTarget?wt(n.triggerTarget).forEach((function(t){t.removeAttribute("aria-expanded")})):r.triggerTarget&&t.removeAttribute("aria-expanded"),M(),D(),E&&E(n,r),y.popperInstance&&(K(),Q().forEach((function(t){requestAnimationFrame(t._tippy.popperInstance.forceUpdate)}))),A("onAfterUpdate",[y,e])}},setContent:function(t){y.setProps({content:t})},show:function(){var t=y.state.isVisible,e=y.state.isDestroyed,n=!y.state.isEnabled,r=Mt.isTouch&&!y.props.touch,o=mt(y.props.duration,0,Ht.duration)
if(!(t||e||n||r||C().hasAttribute("disabled")||(A("onShow",[y],!1),!1===y.props.onShow(y)))){if(y.state.isVisible=!0,T()&&(w.style.visibility="visible"),D(),W(),y.state.isMounted||(w.style.transition="none"),T()){var i=R()
Rt([i.box,i.content],0)}var s,c,u
a=function(){var t
if(y.state.isVisible&&!d){if(d=!0,w.offsetHeight,w.style.transition=y.props.moveTransition,T()&&y.props.animation){var e=R(),n=e.box,r=e.content
Rt([n,r],o),Pt([n,r],"visible")}L(),M(),Et(Xt,y),null==(t=y.popperInstance)||t.forceUpdate(),A("onMount",[y]),y.props.animation&&T()&&function(t,e){B(t,(function(){y.state.isShown=!0,A("onShown",[y])}))}(o)}},c=y.props.appendTo,u=C(),(s=y.props.interactive&&c===vt||"parent"===c?u.parentNode:gt(c,[u])).contains(w)||s.appendChild(w),y.state.isMounted=!0,K()}},hide:function(){var t=!y.state.isVisible,e=y.state.isDestroyed,n=!y.state.isEnabled,r=mt(y.props.duration,1,Ht.duration)
if(!(t||e||n)&&(A("onHide",[y],!1),!1!==y.props.onHide(y))){if(y.state.isVisible=!1,y.state.isShown=!1,d=!1,p=!1,T()&&(w.style.visibility="hidden"),I(),H(),D(!0),T()){var o=R(),i=o.box,s=o.content
y.props.animation&&(Rt([i,s],r),Pt([i,s],"hidden"))}L(),M(),y.props.animation?T()&&function(t,e){B(t,(function(){!y.state.isVisible&&w.parentNode&&w.parentNode.contains(w)&&e()}))}(r,y.unmount):y.unmount()}},hideWithInteractivity:function(t){j().addEventListener("mousemove",m),Et(Kt,m),m(t)},enable:function(){y.state.isEnabled=!0},disable:function(){y.hide(),y.state.isEnabled=!1},unmount:function(){y.state.isVisible&&y.hide(),y.state.isMounted&&(X(),Q().forEach((function(t){t._tippy.unmount()})),w.parentNode&&w.parentNode.removeChild(w),Xt=Xt.filter((function(t){return t!==y})),y.state.isMounted=!1,A("onHidden",[y]))},destroy:function(){y.state.isDestroyed||(y.clearDelayTimeouts(),y.unmount(),Z(),delete t._tippy,y.state.isDestroyed=!0,A("onDestroy",[y]))}}
if(!l.render)return y
var b=l.render(y),w=b.popper,E=b.onUpdate
w.setAttribute("data-tippy-root",""),w.id="tippy-"+y.id,y.popper=w,t._tippy=y,w._tippy=y
var S=g.map((function(t){return t.fn(y)})),x=t.hasAttribute("aria-expanded")
return z(),M(),D(),A("onCreate",[y]),l.showOnCreate&&tt(),w.addEventListener("mouseenter",(function(){y.props.interactive&&y.state.isVisible&&y.clearDelayTimeouts()})),w.addEventListener("mouseleave",(function(){y.props.interactive&&y.props.trigger.indexOf("mouseenter")>=0&&j().addEventListener("mousemove",m)})),y
function O(){var t=y.props.touch
return Array.isArray(t)?t:[t,0]}function k(){return"hold"===O()[0]}function T(){var t
return!(null==(t=y.props.render)||!t.$$tippy)}function C(){return c||t}function j(){var t=C().parentNode
return t?Dt(t):document}function R(){return Jt(w)}function P(t){return y.state.isMounted&&!y.state.isVisible||Mt.isTouch||i&&"focus"===i.type?0:mt(y.props.delay,t?0:1,Ht.delay)}function D(t){void 0===t&&(t=!1),w.style.pointerEvents=y.props.interactive&&!t?"":"none",w.style.zIndex=""+y.props.zIndex}function A(t,e,n){var r
void 0===n&&(n=!0),S.forEach((function(n){n[t]&&n[t].apply(n,e)})),n&&(r=y.props)[t].apply(r,e)}function L(){var e=y.props.aria
if(e.content){var n="aria-"+e.content,r=w.id
wt(y.props.triggerTarget||t).forEach((function(t){var e=t.getAttribute(n)
if(y.state.isVisible)t.setAttribute(n,e?e+" "+r:r)
else{var o=e&&e.replace(r,"").trim()
o?t.setAttribute(n,o):t.removeAttribute(n)}}))}}function M(){!x&&y.props.aria.expanded&&wt(y.props.triggerTarget||t).forEach((function(t){y.props.interactive?t.setAttribute("aria-expanded",y.state.isVisible&&t===C()?"true":"false"):t.removeAttribute("aria-expanded")}))}function I(){j().removeEventListener("mousemove",m),Kt=Kt.filter((function(t){return t!==m}))}function N(e){if(!Mt.isTouch||!h&&"mousedown"!==e.type){var n=e.composedPath&&e.composedPath()[0]||e.target
if(!y.props.interactive||!Lt(w,n)){if(wt(y.props.triggerTarget||t).some((function(t){return Lt(t,n)}))){if(Mt.isTouch)return
if(y.state.isVisible&&y.props.trigger.indexOf("click")>=0)return}else A("onClickOutside",[y,e])
!0===y.props.hideOnClick&&(y.clearDelayTimeouts(),y.hide(),f=!0,setTimeout((function(){f=!1})),y.state.isMounted||H())}}}function F(){h=!0}function U(){h=!1}function W(){var t=j()
t.addEventListener("mousedown",N,!0),t.addEventListener("touchend",N,dt),t.addEventListener("touchstart",U,dt),t.addEventListener("touchmove",F,dt)}function H(){var t=j()
t.removeEventListener("mousedown",N,!0),t.removeEventListener("touchend",N,dt),t.removeEventListener("touchstart",U,dt),t.removeEventListener("touchmove",F,dt)}function B(t,e){var n=R().box
function r(t){t.target===n&&(At(n,"remove",r),e())}if(0===t)return e()
At(n,"remove",s),At(n,"add",r),s=r}function q(e,n,r){void 0===r&&(r=!1),wt(y.props.triggerTarget||t).forEach((function(t){t.addEventListener(e,n,r),v.push({node:t,eventType:e,handler:n,options:r})}))}function z(){var t
k()&&(q("touchstart",V,{passive:!0}),q("touchend",J,{passive:!0})),(t=y.props.trigger,t.split(/\s+/).filter(Boolean)).forEach((function(t){if("manual"!==t)switch(q(t,V),t){case"mouseenter":q("mouseleave",J)
break
case"focus":q(Wt?"focusout":"blur",$)
break
case"focusin":q("focusout",$)}}))}function Z(){v.forEach((function(t){var e=t.node,n=t.eventType,r=t.handler,o=t.options
e.removeEventListener(n,r,o)})),v=[]}function V(t){var e,n=!1
if(y.state.isEnabled&&!Y(t)&&!f){var r="focus"===(null==(e=i)?void 0:e.type)
i=t,c=t.currentTarget,M(),!y.state.isVisible&&Ct(t)&&Kt.forEach((function(e){return e(t)})),"click"===t.type&&(y.props.trigger.indexOf("mouseenter")<0||p)&&!1!==y.props.hideOnClick&&y.state.isVisible?n=!0:tt(t),"click"===t.type&&(p=!n),n&&!r&&et(t)}}function G(t){var e=t.target,n=C().contains(e)||w.contains(e)
"mousemove"===t.type&&n||function(t,e){var n=e.clientX,r=e.clientY
return t.every((function(t){var e=t.popperRect,o=t.popperState,i=t.props.interactiveBorder,s=St(o.placement),a=o.modifiersData.offset
if(!a)return!0
var c="bottom"===s?a.top.y:0,u="top"===s?a.bottom.y:0,l="right"===s?a.left.x:0,p="left"===s?a.right.x:0,f=e.top-r+c>i,h=r-e.bottom-u>i,d=e.left-n+l>i,v=n-e.right-p>i
return f||h||d||v}))}(Q().concat(w).map((function(t){var e,n=null==(e=t._tippy.popperInstance)?void 0:e.state
return n?{popperRect:t.getBoundingClientRect(),popperState:n,props:l}:null})).filter(Boolean),t)&&(I(),et(t))}function J(t){Y(t)||y.props.trigger.indexOf("click")>=0&&p||(y.props.interactive?y.hideWithInteractivity(t):et(t))}function $(t){y.props.trigger.indexOf("focusin")<0&&t.target!==C()||y.props.interactive&&t.relatedTarget&&w.contains(t.relatedTarget)||et(t)}function Y(t){return!!Mt.isTouch&&k()!==t.type.indexOf("touch")>=0}function K(){X()
var e=y.props,n=e.popperOptions,r=e.placement,o=e.offset,i=e.getReferenceClientRect,s=e.moveTransition,c=T()?Jt(w).arrow:null,u=i?{getBoundingClientRect:i,contextElement:i.contextElement||C()}:t,l=[{name:"offset",options:{offset:o}},{name:"preventOverflow",options:{padding:{top:2,bottom:2,left:5,right:5}}},{name:"flip",options:{padding:5}},{name:"computeStyles",options:{adaptive:!s}},{name:"$$tippy",enabled:!0,phase:"beforeWrite",requires:["computeStyles"],fn:function(t){var e=t.state
if(T()){var n=R().box;["placement","reference-hidden","escaped"].forEach((function(t){"placement"===t?n.setAttribute("data-placement",e.placement):e.attributes.popper["data-popper-"+t]?n.setAttribute("data-"+t,""):n.removeAttribute("data-"+t)})),e.attributes.popper={}}}}]
T()&&c&&l.push({name:"arrow",options:{element:c,padding:3}}),l.push.apply(l,(null==n?void 0:n.modifiers)||[]),y.popperInstance=ct(u,w,Object.assign({},n,{placement:r,onFirstUpdate:a,modifiers:l}))}function X(){y.popperInstance&&(y.popperInstance.destroy(),y.popperInstance=null)}function Q(){return xt(w.querySelectorAll("[data-tippy-root]"))}function tt(t){y.clearDelayTimeouts(),t&&A("onTrigger",[y,t]),W()
var e=P(!0),r=O(),o=r[0],i=r[1]
Mt.isTouch&&"hold"===o&&i&&(e=i),e?n=setTimeout((function(){y.show()}),e):y.show()}function et(t){if(y.clearDelayTimeouts(),A("onUntrigger",[y,t]),y.state.isVisible){if(!(y.props.trigger.indexOf("mouseenter")>=0&&y.props.trigger.indexOf("click")>=0&&["mouseleave","mousemove"].indexOf(t.type)>=0&&p)){var e=P(!1)
e?r=setTimeout((function(){y.state.isVisible&&y.hide()}),e):o=requestAnimationFrame((function(){y.hide()}))}}else H()}}(e,o)
return n&&t.push(n),t}),[])
return Tt(t)?i[0]:i}Qt.defaultProps=Ht,Qt.setDefaultProps=function(t){Object.keys(t).forEach((function(e){Ht[e]=t[e]}))},Qt.currentInput=Mt
var te=function(t){var e=void 0===t?{}:t,n=e.exclude,r=e.duration
Xt.forEach((function(t){var e=!1
if(n&&(e=jt(n)?t.reference===n:t.popper===n.popper),!e){var o=t.props.duration
t.setProps({duration:r}),t.hide(),t.state.isDestroyed||t.setProps({duration:o})}}))},ee=Object.assign({},J,{effect:function(t){var e=t.state,n={popper:{position:e.options.strategy,left:"0",top:"0",margin:"0"},arrow:{position:"absolute"},reference:{}}
Object.assign(e.elements.popper.style,n.popper),e.styles=n,e.elements.arrow&&Object.assign(e.elements.arrow.style,n.arrow)}}),ne=function(t,e){var n
void 0===e&&(e={})
var r,o=t,i=[],s=[],a=e.overrides,c=[],u=!1
function l(){s=o.map((function(t){return wt(t.props.triggerTarget||t.reference)})).reduce((function(t,e){return t.concat(e)}),[])}function p(){i=o.map((function(t){return t.reference}))}function f(t){o.forEach((function(e){t?e.enable():e.disable()}))}function h(t){return o.map((function(e){var n=e.setProps
return e.setProps=function(o){n(o),e.reference===r&&t.setProps(o)},function(){e.setProps=n}}))}function d(t,e){var n=s.indexOf(e)
if(e!==r){r=e
var c=(a||[]).concat("content").reduce((function(t,e){return t[e]=o[n].props[e],t}),{})
t.setProps(Object.assign({},c,{getReferenceClientRect:"function"==typeof c.getReferenceClientRect?c.getReferenceClientRect:function(){var t
return null==(t=i[n])?void 0:t.getBoundingClientRect()}}))}}f(!1),p(),l()
var v={fn:function(){return{onDestroy:function(){f(!0)},onHidden:function(){r=null},onClickOutside:function(t){t.props.showOnCreate&&!u&&(u=!0,r=null)},onShow:function(t){t.props.showOnCreate&&!u&&(u=!0,d(t,i[0]))},onTrigger:function(t,e){d(t,e.currentTarget)}}}},m=Qt(kt(),Object.assign({},bt(e,["overrides"]),{plugins:[v].concat(e.plugins||[]),triggerTarget:s,popperOptions:Object.assign({},e.popperOptions,{modifiers:[].concat((null==(n=e.popperOptions)?void 0:n.modifiers)||[],[ee])})})),_=m.show
m.show=function(t){if(_(),!r&&null==t)return d(m,i[0])
if(!r||null!=t){if("number"==typeof t)return i[t]&&d(m,i[t])
if(o.indexOf(t)>=0){var e=t.reference
return d(m,e)}return i.indexOf(t)>=0?d(m,t):void 0}},m.showNext=function(){var t=i[0]
if(!r)return m.show(0)
var e=i.indexOf(r)
m.show(i[e+1]||t)},m.showPrevious=function(){var t=i[i.length-1]
if(!r)return m.show(t)
var e=i.indexOf(r),n=i[e-1]||t
m.show(n)}
var g=m.setProps
return m.setProps=function(t){a=t.overrides||a,g(t)},m.setInstances=function(t){f(!0),c.forEach((function(t){return t()})),o=t,f(!1),p(),l(),c=h(m),m.setProps({triggerTarget:s})},c=h(m),m},re={mouseover:"mouseenter",focusin:"focus",click:"click"}
function oe(t,e){var n=[],r=[],o=!1,i=e.target,s=bt(e,["target"]),a=Object.assign({},s,{trigger:"manual",touch:!1}),c=Object.assign({touch:Ht.touch},s,{showOnCreate:!0}),u=Qt(t,a)
function l(t){if(t.target&&!o){var n=t.target.closest(i)
if(n){var s=n.getAttribute("data-tippy-trigger")||e.trigger||Ht.trigger
if(!n._tippy&&!("touchstart"===t.type&&"boolean"==typeof c.touch||"touchstart"!==t.type&&s.indexOf(re[t.type])<0)){var a=Qt(n,c)
a&&(r=r.concat(a))}}}}function p(t,e,r,o){void 0===o&&(o=!1),t.addEventListener(e,r,o),n.push({node:t,eventType:e,handler:r,options:o})}return wt(u).forEach((function(t){var e=t.destroy,i=t.enable,s=t.disable
t.destroy=function(t){void 0===t&&(t=!0),t&&r.forEach((function(t){t.destroy()})),r=[],n.forEach((function(t){var e=t.node,n=t.eventType,r=t.handler,o=t.options
e.removeEventListener(n,r,o)})),n=[],e()},t.enable=function(){i(),r.forEach((function(t){return t.enable()})),o=!1},t.disable=function(){s(),r.forEach((function(t){return t.disable()})),o=!0},function(t){var e=t.reference
p(e,"touchstart",l,dt),p(e,"mouseover",l),p(e,"focusin",l),p(e,"click",l)}(t)})),u}var ie={name:"animateFill",defaultValue:!1,fn:function(t){var e
if(null==(e=t.props.render)||!e.$$tippy)return{}
var n=Jt(t.popper),r=n.box,o=n.content,i=t.props.animateFill?function(){var t=kt()
return t.className=pt,Pt([t],"hidden"),t}():null
return{onCreate:function(){i&&(r.insertBefore(i,r.firstElementChild),r.setAttribute("data-animatefill",""),r.style.overflow="hidden",t.setProps({arrow:!1,animation:"shift-away"}))},onMount:function(){if(i){var t=r.style.transitionDuration,e=Number(t.replace("ms",""))
o.style.transitionDelay=Math.round(e/10)+"ms",i.style.transitionDuration=t,Pt([i],"visible")}},onShow:function(){i&&(i.style.transitionDuration="0ms")},onHide:function(){i&&Pt([i],"hidden")}}}},se={clientX:0,clientY:0},ae=[]
function ce(t){var e=t.clientX,n=t.clientY
se={clientX:e,clientY:n}}var ue={name:"followCursor",defaultValue:!1,fn:function(t){var e=t.reference,n=Dt(t.props.triggerTarget||e),r=!1,o=!1,i=!0,s=t.props
function a(){return"initial"===t.props.followCursor&&t.state.isVisible}function c(){n.addEventListener("mousemove",p)}function u(){n.removeEventListener("mousemove",p)}function l(){r=!0,t.setProps({getReferenceClientRect:null}),r=!1}function p(n){var r=!n.target||e.contains(n.target),o=t.props.followCursor,i=n.clientX,s=n.clientY,a=e.getBoundingClientRect(),c=i-a.left,u=s-a.top
!r&&t.props.interactive||t.setProps({getReferenceClientRect:function(){var t=e.getBoundingClientRect(),n=i,r=s
"initial"===o&&(n=t.left+c,r=t.top+u)
var a="horizontal"===o?t.top:r,l="vertical"===o?t.right:n,p="horizontal"===o?t.bottom:r,f="vertical"===o?t.left:n
return{width:l-f,height:p-a,top:a,right:l,bottom:p,left:f}}})}function f(){t.props.followCursor&&(ae.push({instance:t,doc:n}),function(t){t.addEventListener("mousemove",ce)}(n))}function h(){0===(ae=ae.filter((function(e){return e.instance!==t}))).filter((function(t){return t.doc===n})).length&&function(t){t.removeEventListener("mousemove",ce)}(n)}return{onCreate:f,onDestroy:h,onBeforeUpdate:function(){s=t.props},onAfterUpdate:function(e,n){var i=n.followCursor
r||void 0!==i&&s.followCursor!==i&&(h(),i?(f(),!t.state.isMounted||o||a()||c()):(u(),l()))},onMount:function(){t.props.followCursor&&!o&&(i&&(p(se),i=!1),a()||c())},onTrigger:function(t,e){Ct(e)&&(se={clientX:e.clientX,clientY:e.clientY}),o="focus"===e.type},onHidden:function(){t.props.followCursor&&(l(),u(),i=!0)}}}},le={name:"inlinePositioning",defaultValue:!1,fn:function(t){var e,n=t.reference,r=-1,o=!1,i=[],s={name:"tippyInlinePositioning",enabled:!0,phase:"afterWrite",fn:function(o){var s=o.state
t.props.inlinePositioning&&(-1!==i.indexOf(s.placement)&&(i=[]),e!==s.placement&&-1===i.indexOf(s.placement)&&(i.push(s.placement),t.setProps({getReferenceClientRect:function(){return function(t){return function(t,e,n,r){if(n.length<2||null===t)return e
if(2===n.length&&r>=0&&n[0].left>n[1].right)return n[r]||e
switch(t){case"top":case"bottom":var o=n[0],i=n[n.length-1],s="top"===t,a=o.top,c=i.bottom,u=s?o.left:i.left,l=s?o.right:i.right
return{top:a,bottom:c,left:u,right:l,width:l-u,height:c-a}
case"left":case"right":var p=Math.min.apply(Math,n.map((function(t){return t.left}))),f=Math.max.apply(Math,n.map((function(t){return t.right}))),h=n.filter((function(e){return"left"===t?e.left===p:e.right===f})),d=h[0].top,v=h[h.length-1].bottom
return{top:d,bottom:v,left:p,right:f,width:f-p,height:v-d}
default:return e}}(St(t),n.getBoundingClientRect(),xt(n.getClientRects()),r)}(s.placement)}})),e=s.placement)}}
function a(){var e
o||(e=function(t,e){var n
return{popperOptions:Object.assign({},t.popperOptions,{modifiers:[].concat(((null==(n=t.popperOptions)?void 0:n.modifiers)||[]).filter((function(t){return t.name!==e.name})),[e])})}}(t.props,s),o=!0,t.setProps(e),o=!1)}return{onCreate:a,onAfterUpdate:a,onTrigger:function(e,n){if(Ct(n)){var o=xt(t.reference.getClientRects()),i=o.find((function(t){return t.left-2<=n.clientX&&t.right+2>=n.clientX&&t.top-2<=n.clientY&&t.bottom+2>=n.clientY})),s=o.indexOf(i)
r=s>-1?s:r}},onHidden:function(){r=-1}}}},pe={name:"sticky",defaultValue:!1,fn:function(t){var e=t.reference,n=t.popper
function r(e){return!0===t.props.sticky||t.props.sticky===e}var o=null,i=null
function s(){var a=r("reference")?(t.popperInstance?t.popperInstance.state.elements.reference:e).getBoundingClientRect():null,c=r("popper")?n.getBoundingClientRect():null;(a&&fe(o,a)||c&&fe(i,c))&&t.popperInstance&&t.popperInstance.update(),o=a,i=c,t.state.isMounted&&requestAnimationFrame(s)}return{onMount:function(){t.props.sticky&&s()}}}}
function fe(t,e){return!t||!e||t.top!==e.top||t.right!==e.right||t.bottom!==e.bottom||t.left!==e.left}Qt.setDefaultProps({render:$t})
const he=Qt},7480:(t,e,n)=>{"use strict"
n.d(e,{ZT:()=>o,pi:()=>i,_T:()=>s,XA:()=>a,CR:()=>c,fl:()=>u})
var r=function(t,e){return(r=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n])})(t,e)}
function o(t,e){function n(){this.constructor=t}r(t,e),t.prototype=null===e?Object.create(e):(n.prototype=e.prototype,new n)}var i=function(){return(i=Object.assign||function(t){for(var e,n=1,r=arguments.length;n<r;n++)for(var o in e=arguments[n])Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o])
return t}).apply(this,arguments)}
function s(t,e){var n={}
for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&e.indexOf(r)<0&&(n[r]=t[r])
if(null!=t&&"function"==typeof Object.getOwnPropertySymbols){var o=0
for(r=Object.getOwnPropertySymbols(t);o<r.length;o++)e.indexOf(r[o])<0&&Object.prototype.propertyIsEnumerable.call(t,r[o])&&(n[r[o]]=t[r[o]])}return n}function a(t){var e="function"==typeof Symbol&&Symbol.iterator,n=e&&t[e],r=0
if(n)return n.call(t)
if(t&&"number"==typeof t.length)return{next:function(){return t&&r>=t.length&&(t=void 0),{value:t&&t[r++],done:!t}}}
throw new TypeError(e?"Object is not iterable.":"Symbol.iterator is not defined.")}function c(t,e){var n="function"==typeof Symbol&&t[Symbol.iterator]
if(!n)return t
var r,o,i=n.call(t),s=[]
try{for(;(void 0===e||e-- >0)&&!(r=i.next()).done;)s.push(r.value)}catch(t){o={error:t}}finally{try{r&&!r.done&&(n=i.return)&&n.call(i)}finally{if(o)throw o.error}}return s}function u(){for(var t=[],e=0;e<arguments.length;e++)t=t.concat(c(arguments[e]))
return t}},8367:function(t){var e
e=function(){return function(t){var e={}
function n(r){if(e[r])return e[r].exports
var o=e[r]={exports:{},id:r,loaded:!1}
return t[r].call(o.exports,o,o.exports,n),o.loaded=!0,o.exports}return n.m=t,n.c=e,n.p="",n(0)}([function(t,e){"use strict"
t.exports=function(){if("undefined"==typeof document||"undefined"==typeof window)return{ask:function(){return"initial"},element:function(){return null},ignoreKeys:function(){},specificKeys:function(){},registerOnChange:function(){},unRegisterOnChange:function(){}}
var t=document.documentElement,e=null,n="initial",r=n,o=Date.now(),i="false",s=["button","input","select","textarea"],a=[],c=[16,17,18,91,93],u=[],l={keydown:"keyboard",keyup:"keyboard",mousedown:"mouse",mousemove:"mouse",MSPointerDown:"pointer",MSPointerMove:"pointer",pointerdown:"pointer",pointermove:"pointer",touchstart:"touch",touchend:"touch"},p=!1,f={x:null,y:null},h={2:"touch",3:"touch",4:"mouse"},d=!1
try{var v=Object.defineProperty({},"passive",{get:function(){d=!0}})
window.addEventListener("test",null,v)}catch(t){}var m,_=function(t){var e=t.which,o=l[t.type]
"pointer"===o&&(o=E(t))
var i=!u.length&&-1===c.indexOf(e),a=u.length&&-1!==u.indexOf(e),p="keyboard"===o&&e&&(i||a)||"mouse"===o||"touch"===o
if(S(o)&&(p=!1),p&&n!==o&&(w("input",n=o),g("input")),p&&r!==o){var f=document.activeElement
f&&f.nodeName&&(-1===s.indexOf(f.nodeName.toLowerCase())||"button"===f.nodeName.toLowerCase()&&!T(f,"form"))&&(w("intent",r=o),g("intent"))}},g=function(e){t.setAttribute("data-what"+e,"input"===e?n:r),O(e)},y=function(t){var e=l[t.type]
"pointer"===e&&(e=E(t)),k(t),(!p&&!S(e)||p&&"wheel"===t.type||"mousewheel"===t.type||"DOMMouseScroll"===t.type)&&r!==e&&(w("intent",r=e),g("intent"))},b=function(){e=null,t.removeAttribute("data-whatelement"),t.removeAttribute("data-whatclasses")},w=function(t,e){if(i)try{window.sessionStorage.setItem("what-"+t,e)}catch(t){}},E=function(t){return"number"==typeof t.pointerType?h[t.pointerType]:"pen"===t.pointerType?"touch":t.pointerType},S=function(t){var e=Date.now(),r="mouse"===t&&"touch"===n&&e-o<200
return o=e,r},x=function(){return"onwheel"in document.createElement("div")?"wheel":void 0!==document.onmousewheel?"mousewheel":"DOMMouseScroll"},O=function(t){for(var e=0,o=a.length;e<o;e++)a[e].type===t&&a[e].fn.call(void 0,"input"===t?n:r)},k=function(t){f.x!==t.screenX||f.y!==t.screenY?(p=!1,f.x=t.screenX,f.y=t.screenY):p=!0},T=function(t,e){var n=window.Element.prototype
if(n.matches||(n.matches=n.msMatchesSelector||n.webkitMatchesSelector),n.closest)return t.closest(e)
do{if(t.matches(e))return t
t=t.parentElement||t.parentNode}while(null!==t&&1===t.nodeType)
return null}
return"addEventListener"in window&&Array.prototype.indexOf&&(l[x()]="mouse",m=!!d&&{passive:!0},document.addEventListener("DOMContentLoaded",(function(){if(i=!(t.getAttribute("data-whatpersist")||"false"===document.body.getAttribute("data-whatpersist")))try{window.sessionStorage.getItem("what-input")&&(n=window.sessionStorage.getItem("what-input")),window.sessionStorage.getItem("what-intent")&&(r=window.sessionStorage.getItem("what-intent"))}catch(t){}g("input"),g("intent")})),window.PointerEvent?(window.addEventListener("pointerdown",_),window.addEventListener("pointermove",y)):window.MSPointerEvent?(window.addEventListener("MSPointerDown",_),window.addEventListener("MSPointerMove",y)):(window.addEventListener("mousedown",_),window.addEventListener("mousemove",y),"ontouchstart"in window&&(window.addEventListener("touchstart",_,m),window.addEventListener("touchend",_))),window.addEventListener(x(),y,m),window.addEventListener("keydown",_),window.addEventListener("keyup",_),window.addEventListener("focusin",(function(n){n.target.nodeName?(e=n.target.nodeName.toLowerCase(),t.setAttribute("data-whatelement",e),n.target.classList&&n.target.classList.length&&t.setAttribute("data-whatclasses",n.target.classList.toString().replace(" ",","))):b()})),window.addEventListener("focusout",b)),{ask:function(t){return"intent"===t?r:n},element:function(){return e},ignoreKeys:function(t){c=t},specificKeys:function(t){u=t},registerOnChange:function(t,e){a.push({fn:t,type:e||"input"})},unRegisterOnChange:function(t){var e=function(t){for(var e=0,n=a.length;e<n;e++)if(a[e].fn===t)return e}(t);(e||0===e)&&a.splice(e,1)},clearStorage:function(){window.sessionStorage.clear()}}}()}])},t.exports=e()},3751:(t,e,n)=>{"use strict"
n.r(e)},6509:(t,e,n)=>{"use strict"
function r(t,e){var n=Object.keys(t)
if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(t)
e&&(r=r.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),n.push.apply(n,r)}return n}function o(t){for(var e=1;e<arguments.length;e++){var n=null!=arguments[e]?arguments[e]:{}
e%2?r(n,!0).forEach((function(e){i(t,e,n[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):r(n).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}))}return t}function i(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}n.r(e),n.d(e,{default:()=>m,memClear:()=>g,memDecorator:()=>_})
const s=(t,e,n,r)=>{if("length"===n||"prototype"===n)return
if("arguments"===n||"caller"===n)return
const o=Object.getOwnPropertyDescriptor(t,n),i=Object.getOwnPropertyDescriptor(e,n)
!a(o,i)&&r||Object.defineProperty(t,n,i)},a=function(t,e){return void 0===t||t.configurable||t.writable===e.writable&&t.enumerable===e.enumerable&&t.configurable===e.configurable&&(t.writable||t.value===e.value)},c=(t,e)=>{const n=Object.getPrototypeOf(e)
n!==Object.getPrototypeOf(t)&&Object.setPrototypeOf(t,n)},u=(t,e)=>"/* Wrapped ".concat(t,"*/\n").concat(e),l=Object.getOwnPropertyDescriptor(Function.prototype,"toString"),p=Object.getOwnPropertyDescriptor(Function.prototype.toString,"name"),f=(t,e,n)=>{const r=""===n?"":"with ".concat(n.trim(),"() "),i=u.bind(null,r,e.toString())
Object.defineProperty(i,"name",p),Object.defineProperty(t,"toString",o(o({},l),{},{value:i}))}
function h(t,e){let{ignoreNonConfigurable:n=!1}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}
const{name:r}=t
for(const o of Reflect.ownKeys(e))s(t,e,o,n)
return c(t,e),f(t,e,r),t}var d=n(3211)
const v=new WeakMap
function m(t){let{cacheKey:e,cache:n=new Map,maxAge:r}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}
"number"==typeof r&&d(n)
const o=function(){for(var o=arguments.length,i=new Array(o),s=0;s<o;s++)i[s]=arguments[s]
const a=e?e(i):i[0],c=n.get(a)
if(c)return c.data
const u=t.apply(this,i)
return n.set(a,{data:u,maxAge:r?Date.now()+r:Number.POSITIVE_INFINITY}),u}
return h(o,t,{ignoreNonConfigurable:!0}),v.set(o,n),o}function _(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}
const e=new WeakMap
return(n,r,o)=>{const i=n[r]
if("function"!=typeof i)throw new TypeError("The decorated value must be a function")
delete o.value,delete o.writable,o.get=function(){if(!e.has(this)){const n=m(i,t)
return e.set(this,n),n}return e.get(this)}}}function g(t){const e=v.get(t)
if(!e)throw new TypeError("Can't clear a function that was not memoized!")
if("function"!=typeof e.clear)throw new TypeError("The cache Map can't be cleared!")
e.clear()}}}])
